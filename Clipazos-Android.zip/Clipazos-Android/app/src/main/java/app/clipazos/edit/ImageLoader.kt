package app.clipazos.edit

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import app.clipazos.data.EditSpec

object ImageLoader {
    fun load(ctx: Context, uri: String, maxDim: Int = 1024): Bitmap? = runCatching {
        val u = Uri.parse(uri)
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, opts) }
        var sample = 1
        while (opts.outWidth / sample > maxDim * 2 || opts.outHeight / sample > maxDim * 2) sample *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = sample }
        ctx.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o2) }
    }.getOrNull()

    fun loadAll(ctx: Context, spec: EditSpec): Map<String, Bitmap> =
        spec.images.mapNotNull { im -> load(ctx, im.uri)?.let { im.id to it } }.toMap()
}
