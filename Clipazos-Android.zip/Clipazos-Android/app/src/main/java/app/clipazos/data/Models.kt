package app.clipazos.data

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

val AppJson = Json { ignoreUnknownKeys = true; encodeDefaults = true; isLenient = true }

@Serializable data class Word(val s: Long, val e: Long, val w: String)
@Serializable data class Segment(val s: Long, val e: Long, val text: String, val words: List<Word> = emptyList())
/** energy: volumen (RMS 0..1000) cada 100 ms del audio original, usado para detectar énfasis, risas y reacciones. */
@Serializable data class Transcript(val segments: List<Segment> = emptyList(), val energy: List<Int> = emptyList())
/** Fragmento de subtítulo: tiempos absolutos (ms) dentro del video original. */
@Serializable data class Caption(val s: Long, val e: Long, val words: List<Word>)

enum class ProjectStatus { IMPORTED, ANALYZING, DONE, ERROR }

@Serializable
data class Project(
    val id: String,
    val name: String,
    val uri: String,
    val durationMs: Long,
    val width: Int,
    val height: Int,
    val sizeBytes: Long,
    val createdAt: Long,
    val verified: Boolean = true,
    val note: String? = null,
    val status: ProjectStatus = ProjectStatus.IMPORTED,
    val clipTarget: Int = 5,
    val stage: String = "",
    val progress: Float = 0f,
    val error: String? = null,
    val clipCount: Int = 0,
)

@Serializable data class Cue(val atMs: Long, val emoji: String)
@Serializable data class TrackPoint(val tMs: Long, val x: Float)

@Serializable
data class StickerItem(
    val id: String, val text: String,
    val xFrac: Float = 0.5f, val yFrac: Float = 0.3f, val sizeFrac: Float = 0.16f,
    val startMs: Long = 0, val endMs: Long = 2000,
)

@Serializable
data class ImageItem(
    val id: String, val uri: String,
    val xFrac: Float = 0.5f, val yFrac: Float = 0.3f, val widthFrac: Float = 0.35f,
    val startMs: Long = 0, val endMs: Long = 3000,
)

@Serializable
data class EditSpec(
    val startMs: Long,
    val endMs: Long,
    val aspect: String = "9:16",
    val layout: String = "fill",            // fill | fit
    val speed: Float = 1f,
    val styleId: String = "viral",
    val captionStyleId: String = "hormozi",
    val captionsOn: Boolean = true,
    val captionY: Float = -1f,              // -1 = posición del estilo
    val captionScale: Float = 1f,
    val filterId: String = "none",
    val zoomMode: String = "auto",          // none | auto | manual
    val zoomLevel: Float = 1f,
    val zoomIntensity: Float = 1f,
    val trackFace: Boolean = false,
    val faceTrack: List<TrackPoint> = emptyList(),
    val panX: Float = 0f,
    val removeSilences: Boolean = false,
    val transitionIn: String = "none",      // none | fade | flash | zoom
    val transitionOut: String = "none",     // none | fade
    val progressBar: Boolean = false,
    val vignette: Boolean = false,
    val cinemaBars: Boolean = false,
    val hook: Boolean = true,
    val hookText: String = "",
    val emojisOn: Boolean = true,
    val stickers: List<StickerItem> = emptyList(),
    val images: List<ImageItem> = emptyList(),
    val sfxOn: Boolean = false,
    val musicUri: String? = null,
    val musicName: String? = null,
    val musicVolume: Float = 0.18f,
    val originalVolume: Float = 1f,
    val resolution: String = "1080p",
)

@Serializable
data class Clip(
    val id: String,
    val projectId: String,
    val rank: Int,
    val startMs: Long,
    val endMs: Long,
    val score: Int,
    val title: String,
    val description: String,
    val category: String,
    val captions: List<Caption>,
    val cues: List<Cue> = emptyList(),
    val edit: EditSpec,
    val exportedUri: String? = null,
)

@Serializable
data class ExportRecord(
    val id: String, val clipId: String, val projectId: String,
    val title: String, val uri: String, val createdAt: Long, val label: String,
)
