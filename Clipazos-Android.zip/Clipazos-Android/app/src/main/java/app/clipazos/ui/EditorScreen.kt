package app.clipazos.ui

import android.graphics.Bitmap
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.net.Uri
import android.provider.OpenableColumns
import android.view.LayoutInflater
import android.view.TextureView
import android.view.View
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.runtime.mutableIntStateOf
import androidx.media3.common.Effect
import app.clipazos.edit.Layouts
import app.clipazos.media.Repair
import app.clipazos.export.MultiBoxEffect
import android.content.Context
import android.media.MediaMetadataRetriever
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.Face
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.navigation.NavHostController
import app.clipazos.R
import app.clipazos.clipazos
import app.clipazos.data.Caption
import app.clipazos.data.Clip
import app.clipazos.data.EditSpec
import app.clipazos.data.ImageItem
import app.clipazos.data.Project
import app.clipazos.data.StickerItem
import app.clipazos.edit.CaptionBuilder
import app.clipazos.edit.CaptionStyle
import app.clipazos.edit.CaptionStyles
import app.clipazos.edit.EditStyles
import app.clipazos.edit.FaceTracker
import app.clipazos.edit.FilterPreset
import app.clipazos.edit.Filters
import app.clipazos.edit.ImageLoader
import app.clipazos.edit.OverlayPainter
import app.clipazos.edit.Piece
import app.clipazos.edit.Reframe
import app.clipazos.edit.TimeMap
import app.clipazos.util.ExportSize
import app.clipazos.util.TimeFmt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

private enum class Tab(val label: String) { STYLE("Estilos"), BOXES("Recuadros"), CAPS("Subtítulos"), FX("Efectos"), FORMAT("Formato"), AUDIO("Audio"), STICKERS("Stickers"), PRO("Pro") }

@Composable
fun EditorScreen(nav: NavHostController, clipId: String) {
    val app = LocalContext.current.clipazos
    val initial = remember(clipId) { app.store.clip(clipId) }
    val project = remember(initial) { initial?.let { app.store.project(it.projectId) } }
    if (initial == null || project == null) { LaunchedEffect(Unit) { nav.popBackStack() }; return }
    EditorContent(nav, initial, project)
}

private fun previewMatrix(f: FilterPreset): ColorMatrix {
    val m = ColorMatrix()
    m.setSaturation(if (f.gray) 0f else f.sat)
    val c = 1f + f.contrast
    val t = 255f * (1f - c) / 2f + 255f * f.bright
    m.postConcat(ColorMatrix(floatArrayOf(c * f.r, 0f, 0f, 0f, t, 0f, c * f.g, 0f, 0f, t, 0f, 0f, c * f.b, 0f, t, 0f, 0f, 0f, 1f, 0f)))
    return m
}

private fun applyFilter(pv: PlayerView, id: String) {
    val tv = pv.videoSurfaceView as? TextureView ?: return
    if (id == "none") { tv.setLayerType(View.LAYER_TYPE_NONE, null); return }
    val paint = android.graphics.Paint().apply { colorFilter = ColorMatrixColorFilter(previewMatrix(Filters.get(id))) }
    tv.setLayerType(View.LAYER_TYPE_HARDWARE, paint)
}

@Composable
private fun EditorContent(nav: NavHostController, initial: Clip, project0: Project) {
    var project by remember { mutableStateOf(project0) }
    val ctx = LocalContext.current
    val app = ctx.clipazos
    val scope = rememberCoroutineScope()
    var clip by remember { mutableStateOf(initial) }
    val latest by rememberUpdatedState(clip)
    val spec = clip.edit
    var tab by remember { mutableStateOf(Tab.STYLE) }
    var safeZones by remember { mutableStateOf(false) }
    var showExport by remember { mutableStateOf(false) }
    var trackProgress by remember { mutableStateOf<Float?>(null) }
    var toast by remember { mutableStateOf<String?>(null) }

    fun save() { app.store.updateClip(latest.copy(exportedUri = app.store.clip(latest.id)?.exportedUri ?: latest.exportedUri)) }
    LaunchedEffect(clip) { delay(350); save() }
    DisposableEffect(Unit) { onDispose { save() } }
    fun edit(f: (EditSpec) -> EditSpec) { clip = clip.copy(edit = f(clip.edit)) }

    val tm = remember(spec.startMs, spec.endMs, spec.removeSilences, spec.speed, clip.captions) {
        TimeMap.build(spec.startMs, spec.endMs, clip.captions.flatMap { it.words }, spec.removeSilences, spec.speed)
    }
    val player = rememberClipPlayer(project, tm)
    fun currentOut(): Long = tm.outFor(player.currentMediaItemIndex, player.currentPosition)

    fun runTrack() {
        if (trackProgress != null) return
        scope.launch {
            trackProgress = 0f
            try {
                val pts = FaceTracker.track(ctx, Uri.parse(project.uri), spec.startMs, spec.endMs, project.width, project.height) { trackProgress = it }
                edit { it.copy(trackFace = true, faceTrack = pts) }
            } catch (e: Exception) { toast = "No se pudo analizar rostros: ${e.message}" }
            trackProgress = null
        }
    }

    Backdrop {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.Rounded.ArrowBack, "Volver", tint = Pal.Text) }
                Text(clip.title, color = Pal.Text, fontWeight = FontWeight.Bold, maxLines = 1, modifier = Modifier.weight(1f))
                GradientButton("EXPORTAR", { save(); showExport = true }, height = 40.dp)
            }
            PreviewArea(player, project, clip, tm, safeZones, Modifier.weight(1.05f).fillMaxWidth(), onRepaired = { project = it })
            LazyRow(Modifier.padding(vertical = 8.dp, horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(Tab.values().toList()) { t ->
                    val sel = t == tab
                    Box(Modifier.clip(RoundedCornerShape(50)).background(if (sel) Pal.Blue else Pal.Surface2).clickable { tab = t }.padding(horizontal = 14.dp, vertical = 8.dp)) {
                        Text(t.label, color = if (sel) Color.White else Pal.Muted, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    }
                }
            }
            Column(Modifier.weight(0.95f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 20.dp)) {
                toast?.let { Text(it, color = Pal.Warn, fontSize = 13.sp, modifier = Modifier.clickable { toast = null }.padding(bottom = 6.dp)) }
                when (tab) {
                    Tab.STYLE -> StylePanel(clip, ::edit)
                    Tab.BOXES -> BoxesPanel(clip, project, spec, ::edit)
                    Tab.CAPS -> CapsPanel(clip, project, ::edit) { clip = clip.copy(captions = it) }
                    Tab.FX -> FxPanel(spec, trackProgress, { runTrack() }, ::edit)
                    Tab.FORMAT -> FormatPanel(clip, project, spec, tm, ::edit)
                    Tab.AUDIO -> AudioPanel(spec, ::edit)
                    Tab.STICKERS -> StickersPanel(spec, tm.outDurationMs, ::currentOut, ::edit)
                    Tab.PRO -> ProPanel(clip, spec, tm, safeZones, { safeZones = it }, ::edit)
                }
            }
        }
        if (showExport) ExportDialog(listOf(clip.id)) { showExport = false; app.store.clip(clip.id)?.let { clip = it } }
        ExportProgressHost()
    }
}

@Composable
internal fun rememberClipPlayer(project: Project, tm: TimeMap): ExoPlayer {
    val ctx = LocalContext.current
    val player = remember { ExoPlayer.Builder(ctx).build().apply { repeatMode = Player.REPEAT_MODE_ALL; playWhenReady = true } }
    DisposableEffect(Unit) { onDispose { player.release() } }
    LaunchedEffect(tm.pieces, project.uri) {
        val uri = Uri.parse(project.uri)
        player.setMediaItems(tm.pieces.map { p ->
            MediaItem.Builder().setUri(uri)
                .setClippingConfiguration(MediaItem.ClippingConfiguration.Builder().setStartPositionMs(p.srcStart).setEndPositionMs(p.srcEnd).build()).build()
        })
        player.prepare()
    }
    LaunchedEffect(tm.speed) { player.setPlaybackSpeed(tm.speed) }
    return player
}

@Composable
internal fun PreviewArea(player: ExoPlayer, project: Project, clip: Clip, tm: TimeMap, safeZones: Boolean, modifier: Modifier, onRepaired: (Project) -> Unit = {}) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var repairPct by remember { mutableStateOf<Float?>(null) }
    var repairErr by remember { mutableStateOf<String?>(null) }
    val spec = clip.edit
    val (ow, oh) = ExportSize.of(spec.aspect, "720p")
    val tA = ow.toFloat() / oh
    val sA = project.width.toFloat() / project.height
    val images by produceState<Map<String, Bitmap>>(emptyMap(), spec.images) { value = withContext(Dispatchers.IO) { ImageLoader.loadAll(ctx, spec) } }
    val painter = remember(spec, clip.captions, clip.cues, tm, images) {
        OverlayPainter(spec, clip.captions, tm, clip.cues, spec.hookText.ifBlank { clip.title }, images)
    }
    val reframe = remember(spec, tm, clip.captions) { Reframe(spec, tm, project.width, project.height, ow, oh, clip.captions) }
    var outMs by remember { mutableLongStateOf(0L) }
    var playing by remember { mutableStateOf(player.isPlaying) }
    LaunchedEffect(player, tm) { while (true) { androidx.compose.runtime.withFrameNanos { }; outMs = tm.outFor(player.currentMediaItemIndex, player.currentPosition) } }
    var error by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(true) }
    DisposableEffect(player) {
        val l = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onPlayerError(e: PlaybackException) { error = "${e.errorCodeName}: ${e.message ?: ""} ${e.cause?.message ?: ""}".trim() }
            override fun onPlaybackStateChanged(state: Int) {
                loading = state == Player.STATE_BUFFERING || state == Player.STATE_IDLE
                if (state == Player.STATE_READY) error = null
            }
        }
        player.addListener(l); onDispose { player.removeListener(l) }
    }
    val outDur = tm.outDurationMs.coerceAtLeast(1)
    val multi = spec.boxLayout != "none"
    var effectsOn by remember { mutableStateOf(false) }
    LaunchedEffect(player, spec.boxLayout, spec.boxes, spec.boxSplit, spec.boxSplit2, spec.pipSize, spec.pipCorner, spec.pipRound, spec.aspect) {
        runCatching {
            if (multi) {
                effectsOn = true
                val dst = Layouts.dest(spec, ow, oh, sA)
                val boxes = Layouts.boxesOf(spec)
                val rounds = Layouts.rounds(spec)
                val modes = Layouts.modes(spec)
                player.setVideoEffects(listOf<Effect>(MultiBoxEffect(dst, { w, h -> dst.indices.map { Layouts.srcRect(boxes[it], dst[it], w, h, ow, oh) } }, rounds, modes, ow, oh)))
            } else if (effectsOn) { effectsOn = false; player.setVideoEffects(emptyList()) }
        }
    }
    Column(modifier) {
        BoxWithConstraints(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            val bw = if (maxWidth / maxHeight > tA) maxHeight * tA else maxWidth
            val bh = bw / tA
            val density = LocalDensity.current
            val cwPx = with(density) { bw.toPx() }
            val chPx = with(density) { bh.toPx() }
            val fill = spec.layout == "fill" && !multi
            val vw: Float; val vh: Float
            if (multi) { vw = cwPx; vh = chPx }
            else if (fill) { if (tA <= sA) { vw = chPx * sA; vh = chPx } else { vw = cwPx; vh = cwPx / sA } }
            else { if (tA >= sA) { vw = chPx * sA; vh = chPx } else { vw = cwPx; vh = cwPx / sA } }
            Box(Modifier.size(bw, bh).clip(RoundedCornerShape(14.dp)).background(Color.Black).clipToBounds(), contentAlignment = Alignment.Center) {
                AndroidView(
                    factory = { c -> (LayoutInflater.from(c).inflate(R.layout.player_texture, null) as PlayerView).also { it.player = player } },
                    modifier = Modifier.requiredSize(with(density) { vw.toDp() }, with(density) { vh.toDp() }).graphicsLayer {
                        if (fill) {
                            val (z, cx, cy) = reframe.params(outMs)
                            scaleX = z; scaleY = z
                            translationX = -cx * z * vw / 2f; translationY = cy * z * vh / 2f
                        }
                    },
                    update = { pv -> applyFilter(pv, spec.filterId) },
                )
                Canvas(Modifier.fillMaxSize()) {
                    drawIntoCanvas { c -> painter.draw(c.nativeCanvas, size.width.toInt(), size.height.toInt(), outMs, safeZones) }
                }
                val err = error
                if (err != null) {
                    Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().background(Color(0xF2000000)).padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("El video no se puede reproducir tal como está", color = Pal.Danger, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text(err, color = Pal.Muted, fontSize = 10.sp, maxLines = 3)
                        val rp = repairPct
                        if (rp != null) Text("Reparando… ${(rp * 100).toInt()} %", color = Pal.Cyan, fontSize = 12.sp)
                        else GradientButton("REPARAR EL VIDEO", {
                            repairErr = null; repairPct = 0f
                            scope.launch {
                                try {
                                    val np = Repair.fix(ctx, ctx.clipazos.store, project) { repairPct = it }
                                    error = null
                                    onRepaired(np)
                                } catch (e: Exception) { repairErr = e.message }
                                repairPct = null
                            }
                        }, Modifier.fillMaxWidth(), height = 40.dp)
                        repairErr?.let { Text(it, color = Pal.Danger, fontSize = 11.sp) }
                    }
                } else if (loading) {
                    Text("Cargando…", color = Pal.Muted, fontSize = 12.sp, modifier = Modifier.align(Alignment.Center))
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { if (player.isPlaying) player.pause() else player.play() }) {
                Icon(if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, "Reproducir", tint = Pal.Cyan)
            }
            Slider(
                value = (outMs.toFloat() / outDur).coerceIn(0f, 1f),
                onValueChange = { f -> val ms = (f * outDur).toLong(); outMs = ms; val (i, pos) = tm.locate(ms); player.seekTo(i, pos) },
                modifier = Modifier.weight(1f),
                colors = SliderDefaults.colors(thumbColor = Pal.Cyan, activeTrackColor = Pal.Blue, inactiveTrackColor = Pal.Surface2),
            )
            Text("${TimeFmt.format(outMs)}/${TimeFmt.format(outDur)}", color = Pal.Muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun StylePanel(clip: Clip, edit: ((EditSpec) -> EditSpec) -> Unit) {
    val rec = EditStyles.forCategory(clip.category)
    Text("El análisis detectó un momento ${categoryLabel(clip.category)}. Estilo recomendado: ${EditStyles.get(rec).name}.", color = Pal.Muted, fontSize = 13.sp)
    Spacer(Modifier.height(8.dp))
    GradientButton("Auto-editar con un toque", { edit { EditStyles.get(rec).apply(it) } }, Modifier.fillMaxWidth(), icon = Icons.Rounded.AutoAwesome, height = 48.dp)
    Label("ESTILOS DE EDICIÓN (aplican subtítulos, zoom, filtro y efectos juntos)")
    EditStyles.all.chunked(2).forEach { row ->
        Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            row.forEach { st ->
                val sel = clip.edit.styleId == st.id
                Panel(Modifier.weight(1f).then(if (sel) Modifier.border(2.dp, Pal.Cyan, RoundedCornerShape(20.dp)) else Modifier), onClick = { edit { st.apply(it) } }) {
                    Column(Modifier.padding(12.dp)) {
                        Text("${st.emoji} ${st.name}", color = Pal.Text, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(st.desc, color = Pal.Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp))
                    }
                }
            }
            if (row.size == 1) Spacer(Modifier.weight(1f))
        }
    }
}

@Composable
private fun StyleThumb(st: CaptionStyle, selected: Boolean, onClick: () -> Unit) {
    val bmp = remember(st.id) {
        val b = Bitmap.createBitmap(300, 300, Bitmap.Config.ARGB_8888)
        val s = EditSpec(0, 1000, captionStyleId = st.id, captionY = 0.5f, hook = false)
        OverlayPainter(s, emptyList(), TimeMap(listOf(Piece(0, 1000)), 1f), emptyList(), "", emptyMap())
            .drawSample(android.graphics.Canvas(b), 300, 300, "ASÍ SE VE")
        b.asImageBitmap()
    }
    Column(Modifier.width(96.dp).clickable(onClick = onClick), horizontalAlignment = Alignment.CenterHorizontally) {
        Image(bmp, st.name, Modifier.size(96.dp).clip(RoundedCornerShape(14.dp)).then(if (selected) Modifier.border(2.dp, Pal.Cyan, RoundedCornerShape(14.dp)) else Modifier))
        Text(st.name, color = if (selected) Pal.Cyan else Pal.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
    }
}

@Composable
private fun CapsPanel(clip: Clip, project: Project, edit: ((EditSpec) -> EditSpec) -> Unit, setCaps: (List<Caption>) -> Unit) {
    val spec = clip.edit
    val st = CaptionStyles.get(spec.captionStyleId)
    SwitchRow("Subtítulos automáticos", spec.captionsOn, { v -> edit { it.copy(captionsOn = v) } }, "Transcritos en tu celular con tiempos por palabra")
    Label("ESTILO")
    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        items(CaptionStyles.all) { s -> StyleThumb(s, s.id == spec.captionStyleId) { edit { it.copy(captionStyleId = s.id, captionY = -1f) } } }
    }
    Spacer(Modifier.height(8.dp))
    SliderRow("Tamaño", spec.captionScale, 0.6f..1.6f, { v -> edit { it.copy(captionScale = v) } }, "${(spec.captionScale * 100).toInt()}%")
    val y = if (spec.captionY < 0) st.yFrac else spec.captionY
    SliderRow("Posición vertical", y, 0.15f..0.9f, { v -> edit { it.copy(captionY = v) } }, "${(y * 100).toInt()}%")
    SliderRow("Sincronización (si salen adelantados o atrasados)", spec.captionOffsetMs.toFloat(), -1500f..1500f, { v -> edit { it.copy(captionOffsetMs = (v / 50f).toInt() * 50L) } }, "${spec.captionOffsetMs} ms")
    var wpl by remember(spec.captionWords) { mutableStateOf(spec.captionWords.toFloat()) }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text("Palabras por subtítulo", color = Pal.Muted, fontSize = 13.sp)
        Text("${wpl.toInt()}", color = Pal.Cyan, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
    Slider(value = wpl, onValueChange = { wpl = it }, valueRange = 1f..7f, steps = 5,
        onValueChangeFinished = { edit { it.copy(captionWords = wpl.toInt()) }; setCaps(CaptionBuilder.rechunk(clip.captions, wpl.toInt())) },
        colors = SliderDefaults.colors(thumbColor = Pal.Cyan, activeTrackColor = Pal.Blue, inactiveTrackColor = Pal.Surface2))
    Label("CORREGIR TEXTO (la sincronización se conserva)")
    val visible = clip.captions.withIndex().filter { it.value.e > spec.startMs && it.value.s < spec.endMs }.take(120)
    if (visible.isEmpty()) Text("No hay subtítulos en este tramo.", color = Pal.Muted)
    visible.forEach { (idx, c) ->
        var txt by remember(c.s, idx) { mutableStateOf(CaptionBuilder.text(c)) }
        Row(Modifier.fillMaxWidth().padding(bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(TimeFmt.format(c.s), color = Pal.Cyan, fontSize = 12.sp, modifier = Modifier.width(46.dp))
            OutlinedTextField(value = txt, onValueChange = { n ->
                txt = n
                setCaps(clip.captions.mapIndexed { i, cc -> if (i == idx) CaptionBuilder.retext(cc, n) else cc })
            }, modifier = Modifier.weight(1f), textStyle = androidx.compose.ui.text.TextStyle(fontSize = 14.sp, color = Pal.Text))
            IconButton(onClick = { setCaps(clip.captions.filterIndexed { i, _ -> i != idx }) }) { Icon(Icons.Rounded.Delete, "Quitar", tint = Pal.Muted) }
        }
    }
}

@Composable
private fun FxPanel(spec: EditSpec, trackProgress: Float?, onTrack: () -> Unit, edit: ((EditSpec) -> EditSpec) -> Unit) {
    if (spec.boxLayout != "none") Text("Con varios recuadros activos, el zoom y el reencuadre se controlan desde la pestaña Recuadros.", color = Pal.Warn, fontSize = 12.sp)
    Label("ZOOM")
    Chips(listOf("none" to "Sin zoom", "auto" to "Automático", "manual" to "Manual"), spec.zoomMode, { v -> edit { it.copy(zoomMode = v) } })
    if (spec.zoomMode == "auto") SliderRow("Intensidad del zoom (golpe en cada frase)", spec.zoomIntensity, 0f..2f, { v -> edit { it.copy(zoomIntensity = v) } }, "${(spec.zoomIntensity * 100).toInt()}%")
    if (spec.zoomMode == "manual") SliderRow("Zoom", spec.zoomLevel, 1f..2.5f, { v -> edit { it.copy(zoomLevel = v) } }, String.format("%.2fx", spec.zoomLevel))
    Label("REENCUADRE")
    SwitchRow("Seguir al rostro principal", spec.trackFace && spec.faceTrack.isNotEmpty(), { on ->
        if (on) { if (spec.faceTrack.isEmpty()) onTrack() else edit { it.copy(trackFace = true) } } else edit { it.copy(trackFace = false) }
    }, "Analiza el video en tu celular. Sigue al rostro más grande (no distingue quién habla).")
    trackProgress?.let { Text("Analizando rostros… ${(it * 100).toInt()}%", color = Pal.Cyan, fontSize = 13.sp) }
    if (!spec.trackFace || spec.faceTrack.isEmpty()) SliderRow("Posición horizontal manual", spec.panX, -1f..1f, { v -> edit { it.copy(panX = v) } }, "${(spec.panX * 100).toInt()}")
    Label("FILTROS")
    Chips(Filters.all.map { it.id to it.name }, spec.filterId, { v -> edit { it.copy(filterId = v) } })
    Label("TRANSICIÓN DE ENTRADA")
    Chips(listOf("none" to "Ninguna", "fade" to "Fundido", "flash" to "Flash", "zoom" to "Zoom"), spec.transitionIn, { v -> edit { it.copy(transitionIn = v) } })
    Label("TRANSICIÓN DE SALIDA")
    Chips(listOf("none" to "Ninguna", "fade" to "Fundido"), spec.transitionOut, { v -> edit { it.copy(transitionOut = v) } })
    Spacer(Modifier.height(6.dp))
    SwitchRow("Barra de progreso", spec.progressBar, { v -> edit { it.copy(progressBar = v) } }, "Aumenta la retención")
    SwitchRow("Viñeta", spec.vignette, { v -> edit { it.copy(vignette = v) } })
    SwitchRow("Barras de cine", spec.cinemaBars, { v -> edit { it.copy(cinemaBars = v) } })
    SwitchRow("Emojis automáticos (según las palabras del clip)", spec.emojisOn, { v -> edit { it.copy(emojisOn = v) } })
}

@Composable
private fun FormatPanel(clip: Clip, project: Project, spec: EditSpec, tm: TimeMap, edit: ((EditSpec) -> EditSpec) -> Unit) {
    val lo = (clip.startMs - 40_000).coerceAtLeast(0).toFloat()
    val hi = (clip.endMs + 40_000).coerceAtMost(project.durationMs).toFloat()
    var r by remember(spec.startMs, spec.endMs) { mutableStateOf(spec.startMs.toFloat()..spec.endMs.toFloat()) }
    Label("RECORTE (podés extender ±40 s respecto a lo elegido)")
    RangeSlider(value = r, onValueChange = { if (it.endInclusive - it.start >= 5000f) r = it }, valueRange = lo..hi,
        onValueChangeFinished = { edit { it.copy(startMs = r.start.toLong(), endMs = r.endInclusive.toLong()) } },
        colors = SliderDefaults.colors(thumbColor = Pal.Cyan, activeTrackColor = Pal.Blue, inactiveTrackColor = Pal.Surface2))
    Text("Inicio ${TimeFmt.format(r.start.toLong())} · Fin ${TimeFmt.format(r.endInclusive.toLong())} · Dura ${TimeFmt.format(tm.outDurationMs)}", color = Pal.Muted, fontSize = 13.sp)
    Label("FORMATO")
    Chips(listOf("9:16" to "Vertical 9:16", "16:9" to "Horizontal 16:9", "1:1" to "Cuadrado 1:1"), spec.aspect, { v -> edit { it.copy(aspect = v) } })
    Label("ENCUADRE")
    Chips(listOf("fill" to "Rellenar (recorta)", "fit" to "Ajustar (barras negras)"), spec.layout, { v -> edit { it.copy(layout = v) } })
    Label("VELOCIDAD")
    Chips(listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f).map { it to "${it}x" }, spec.speed, { v -> edit { it.copy(speed = v) } })
    Spacer(Modifier.height(6.dp))
    SwitchRow("Quitar silencios (saltos de edición)", spec.removeSilences, { v -> edit { it.copy(removeSilences = v) } }, "Corta las pausas largas usando los tiempos reales de las palabras")
    SwitchRow("Gancho: título en los primeros 3 s", spec.hook, { v -> edit { it.copy(hook = v) } })
    if (spec.hook) OutlinedTextField(value = spec.hookText, onValueChange = { v -> edit { it.copy(hookText = v) } }, modifier = Modifier.fillMaxWidth(),
        label = { Text("Texto del gancho (vacío = título automático)") }, textStyle = androidx.compose.ui.text.TextStyle(color = Pal.Text))
}

@Composable
private fun AudioPanel(spec: EditSpec, edit: ((EditSpec) -> EditSpec) -> Unit) {
    val ctx = LocalContext.current
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { ctx.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            var name = "Música"
            runCatching { ctx.contentResolver.query(uri, null, null, null, null)?.use { c -> if (c.moveToFirst()) { val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (i >= 0) name = c.getString(i) } } }
            edit { it.copy(musicUri = uri.toString(), musicName = name) }
        }
    }
    Label("MÚSICA DE FONDO (de tu celular; se repite hasta cubrir el clip)")
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        GhostButton(if (spec.musicUri == null) "Elegir música" else "Cambiar", { pick.launch(arrayOf("audio/*")) }, icon = Icons.Rounded.MusicNote)
        if (spec.musicUri != null) GhostButton("Quitar", { edit { it.copy(musicUri = null, musicName = null) } }, danger = true)
    }
    spec.musicName?.let { Text(it, color = Pal.Muted, fontSize = 13.sp, maxLines = 1) }
    if (spec.musicUri != null) SliderRow("Volumen de la música", spec.musicVolume, 0f..1f, { v -> edit { it.copy(musicVolume = v) } }, "${(spec.musicVolume * 100).toInt()}%")
    SliderRow("Volumen de la voz original", spec.originalVolume, 0f..1.5f, { v -> edit { it.copy(originalVolume = v) } }, "${(spec.originalVolume * 100).toInt()}%")
    Spacer(Modifier.height(6.dp))
    SwitchRow("Efectos de sonido automáticos", spec.sfxOn, { v -> edit { it.copy(sfxOn = v) } }, "Whoosh en los golpes de zoom y la entrada, pop en cada emoji")
}

private val EMOJIS = listOf("🔥", "😂", "😮", "💀", "👀", "🤯", "❤️", "👏", "💯", "🚀", "⚡", "😱", "🙌", "🤣", "😎", "👑")

@Composable
private fun StickersPanel(spec: EditSpec, outDur: Long, now: () -> Long, edit: ((EditSpec) -> EditSpec) -> Unit) {
    val ctx = LocalContext.current
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { ctx.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            val t = now()
            edit { it.copy(images = it.images + ImageItem(UUID.randomUUID().toString(), uri.toString(), startMs = t, endMs = (t + 3000).coerceAtMost(outDur))) }
        }
    }
    Label("EMOJIS Y STICKERS (se agregan en el momento actual del video)")
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(EMOJIS) { e ->
            Box(Modifier.size(52.dp).clip(RoundedCornerShape(14.dp)).background(Pal.Surface2).clickable {
                val t = now()
                edit { it.copy(stickers = it.stickers + StickerItem(UUID.randomUUID().toString(), e, startMs = t, endMs = (t + 2000).coerceAtMost(outDur))) }
            }, contentAlignment = Alignment.Center) { Text(e, fontSize = 26.sp) }
        }
    }
    Spacer(Modifier.height(8.dp))
    GhostButton("Agregar imagen", { pick.launch(arrayOf("image/*")) }, icon = Icons.Rounded.Image)
    spec.stickers.forEach { s ->
        Panel(Modifier.fillMaxWidth().padding(top = 8.dp)) {
            Column(Modifier.padding(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("${s.text}  desde ${TimeFmt.format(s.startMs)}", color = Pal.Text, modifier = Modifier.weight(1f))
                    IconButton(onClick = { edit { it.copy(stickers = it.stickers.filter { x -> x.id != s.id }) } }) { Icon(Icons.Rounded.Delete, "Quitar", tint = Pal.Muted) }
                }
                SliderRow("Horizontal", s.xFrac, 0.05f..0.95f, { v -> edit { sp -> sp.copy(stickers = sp.stickers.map { if (it.id == s.id) it.copy(xFrac = v) else it }) } })
                SliderRow("Vertical", s.yFrac, 0.05f..0.95f, { v -> edit { sp -> sp.copy(stickers = sp.stickers.map { if (it.id == s.id) it.copy(yFrac = v) else it }) } })
                SliderRow("Tamaño", s.sizeFrac, 0.05f..0.5f, { v -> edit { sp -> sp.copy(stickers = sp.stickers.map { if (it.id == s.id) it.copy(sizeFrac = v) else it }) } })
            }
        }
    }
    spec.images.forEach { im ->
        Panel(Modifier.fillMaxWidth().padding(top = 8.dp)) {
            Column(Modifier.padding(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Imagen desde ${TimeFmt.format(im.startMs)}", color = Pal.Text, modifier = Modifier.weight(1f))
                    IconButton(onClick = { edit { it.copy(images = it.images.filter { x -> x.id != im.id }) } }) { Icon(Icons.Rounded.Delete, "Quitar", tint = Pal.Muted) }
                }
                SliderRow("Horizontal", im.xFrac, 0.05f..0.95f, { v -> edit { sp -> sp.copy(images = sp.images.map { if (it.id == im.id) it.copy(xFrac = v) else it }) } })
                SliderRow("Vertical", im.yFrac, 0.05f..0.95f, { v -> edit { sp -> sp.copy(images = sp.images.map { if (it.id == im.id) it.copy(yFrac = v) else it }) } })
                SliderRow("Tamaño", im.widthFrac, 0.1f..0.9f, { v -> edit { sp -> sp.copy(images = sp.images.map { if (it.id == im.id) it.copy(widthFrac = v) else it }) } })
            }
        }
    }
}

@Composable
private fun ProPanel(clip: Clip, spec: EditSpec, tm: TimeMap, safe: Boolean, setSafe: (Boolean) -> Unit, edit: ((EditSpec) -> EditSpec) -> Unit) {
    val dur = tm.outDurationMs
    val firstWord = clip.captions.firstOrNull { it.e > spec.startMs }?.s
    val capY = if (spec.captionY < 0) CaptionStyles.get(spec.captionStyleId).yFrac else spec.captionY
    val checks = listOf(
        Triple(dur in 30_000..80_000, "Duración entre 30 s y 1:20", "Ahora dura ${TimeFmt.format(dur)}. Ajustalo en Formato › Recorte."),
        Triple(spec.hook && (spec.hookText.isNotBlank() || clip.title.isNotBlank()), "Gancho en los primeros 3 s", "Activalo en Formato: el título aparece arriba al inicio."),
        Triple(spec.captionsOn, "Subtítulos activados", "La mayoría mira sin sonido."),
        Triple(!(spec.aspect == "9:16" && capY > 0.78f), "Subtítulos fuera de la zona de botones", "Subilos: la app tapa la parte baja en 9:16."),
        Triple(spec.zoomMode != "none" || spec.removeSilences, "Ritmo visual (zoom o sin silencios)", "Probá zoom automático o quitar silencios."),
        Triple(firstWord != null && firstWord - spec.startMs < 1500, "Arranca hablando rápido", "Recortá el inicio para empezar en la primera frase."),
        Triple(spec.musicUri == null || spec.musicVolume <= 0.25f, "La música no tapa la voz", "Bajá la música a 10–20%."),
        Triple(spec.resolution != "720p" || spec.aspect != "9:16", "Calidad adecuada", "Para vertical exportá en 1080p."),
    )
    val pct = checks.count { it.first } * 100 / checks.size
    Row(verticalAlignment = Alignment.CenterVertically) {
        ScoreBadge(pct)
        Spacer(Modifier.width(12.dp))
        Column { Text("Checklist viral", color = Pal.Text, fontWeight = FontWeight.Bold); Text("Reglas de buena práctica; no garantizan resultados.", color = Pal.Muted, fontSize = 12.sp) }
    }
    Spacer(Modifier.height(8.dp))
    checks.forEach { (ok, title, tip) ->
        Row(Modifier.padding(vertical = 3.dp)) {
            Text(if (ok) "✅" else "⚠️", fontSize = 16.sp); Spacer(Modifier.width(8.dp))
            Column { Text(title, color = Pal.Text, fontSize = 14.sp, fontWeight = FontWeight.Medium); if (!ok) Text(tip, color = Pal.Warn, fontSize = 12.sp) }
        }
    }
    Spacer(Modifier.height(8.dp))
    SwitchRow("Mostrar zonas seguras en la vista previa", safe, setSafe, "Las áreas rojas las tapa la interfaz de TikTok/Reels/Shorts")
    Spacer(Modifier.height(8.dp))
    GradientButton("Aplicar estilo recomendado", { edit { EditStyles.get(EditStyles.forCategory(clip.category)).apply(it) } }, Modifier.fillMaxWidth(), icon = Icons.Rounded.AutoAwesome, height = 48.dp)
}


private fun loadFrame(ctx: Context, uri: String, atMs: Long, width: Int): Bitmap? = runCatching {
    val r = MediaMetadataRetriever()
    try {
        r.setDataSource(ctx, Uri.parse(uri))
        r.getFrameAtTime(atMs * 1000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)?.let { b ->
            Bitmap.createScaledBitmap(b, width, (b.height * width.toFloat() / b.width).toInt().coerceAtLeast(1), true)
        }
    } finally { r.release() }
}.getOrNull()

private fun positionName(layout: String, i: Int): String = when (layout) {
    "stack2" -> listOf("arriba", "abajo")
    "stack3" -> listOf("arriba", "medio", "abajo")
    "three" -> listOf("arriba", "abajo izq.", "abajo der.")
    "grid4" -> listOf("arriba izq.", "arriba der.", "abajo izq.", "abajo der.")
    "side2" -> listOf("izquierda", "derecha")
    "pip" -> listOf("fondo", "cámara")
    else -> emptyList()
}.getOrElse(i) { "" }

@Composable
private fun PresetIcon(id: String) {
    val sp = Layouts.applyPreset(EditSpec(0, 1000), id)
    val dst = Layouts.dest(sp, 540, 960, 16f / 9f)
    val colors = listOf(Pal.Cyan, Pal.Violet, Pal.Turq, Pal.Warn)
    Canvas(Modifier.width(34.dp).height(60.dp)) {
        if (id == "fill") drawRoundRect(color = colors[0], cornerRadius = CornerRadius(8f, 8f))
        else dst.forEachIndexed { i, d ->
            drawRoundRect(
                color = colors[i % 4].copy(alpha = if (id == "fit" && i == 0) 0.25f else 0.9f),
                topLeft = Offset(d[0] * size.width + 2.5f, d[1] * size.height + 2.5f),
                size = androidx.compose.ui.geometry.Size(d[2] * size.width - 5f, d[3] * size.height - 5f),
                cornerRadius = CornerRadius(if (id == "pip" && i == 1) 100f else 6f),
            )
        }
    }
}

@Composable
private fun BoxesPanel(clip: Clip, project: Project, spec: EditSpec, edit: ((EditSpec) -> EditSpec) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val (ow, oh) = ExportSize.of(spec.aspect, "720p")
    val sAsp = project.width.toFloat() / project.height
    var sel by remember { mutableIntStateOf(0) }
    var msg by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val frame by produceState<Bitmap?>(null, project.id, clip.id) { value = withContext(Dispatchers.IO) { loadFrame(ctx, project.uri, (clip.startMs + clip.endMs) / 2, 640) } }

    // Busca rostros en el video y los asigna a los recuadros (la cámara en Gameplay/Pantalla, o una persona por recuadro).
    fun detect(onlyIndex: Int?) {
        if (busy) return
        busy = true; msg = null
        scope.launch {
            try {
                val faces = FaceTracker.detectFaces(ctx, Uri.parse(project.uri), (clip.startMs + clip.endMs) / 2, project.width, project.height)
                if (faces.isEmpty()) msg = "No encontré rostros en este momento del video. Arrastrá el marco a mano sobre la imagen."
                else edit { s ->
                    val dst = Layouts.dest(s, ow, oh, sAsp)
                    val bl = Layouts.boxesOf(s).toMutableList()
                    val big = faces.maxByOrNull { it[2] * it[3] }!!
                    val camIdx = when (s.boxPreset) { "gameplay" -> 0; "screen", "pip" -> 1; else -> -1 }
                    if (onlyIndex != null) bl[onlyIndex] = Layouts.fitFace(big, dst[onlyIndex], project.width, project.height, ow, oh)
                    else if (camIdx >= 0) bl[camIdx] = Layouts.fitFace(big, dst[camIdx], project.width, project.height, ow, oh)
                    else faces.take(bl.size).forEachIndexed { i, f -> bl[i] = Layouts.fitFace(f, dst[i], project.width, project.height, ow, oh) }
                    s.copy(boxes = bl)
                }
            } catch (e: Exception) { msg = "No se pudo buscar rostros: ${e.message}" }
            busy = false
        }
    }

    Label("DISEÑO (como en Opus Clip)")
    Layouts.presets.chunked(2).forEach { row ->
        Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            row.forEach { p ->
                val on = Layouts.currentPreset(spec) == p.id
                Panel(Modifier.weight(1f).then(if (on) Modifier.border(2.dp, Pal.Cyan, RoundedCornerShape(20.dp)) else Modifier), onClick = {
                    edit { Layouts.applyPreset(it, p.id) }
                    sel = 0
                    if (p.id !in setOf("fill", "fit")) detect(null)
                }) {
                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        PresetIcon(p.id)
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(p.name, color = Pal.Text, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(p.desc, color = Pal.Muted, fontSize = 11.sp)
                        }
                    }
                }
            }
            if (row.size == 1) Spacer(Modifier.weight(1f))
        }
    }
    if (busy) Text("Buscando rostros en el video…", color = Pal.Cyan, fontSize = 13.sp)
    msg?.let { Text(it, color = Pal.Warn, fontSize = 12.sp) }

    if (spec.boxLayout == "none") {
        Text("Rellenar recorta el video para llenar la pantalla. En Efectos podés activar el seguimiento de rostro. Elegí otro diseño para mostrar, por ejemplo, el juego y tu cámara a la vez.", color = Pal.Muted, fontSize = 13.sp)
        return
    }
    if (spec.boxLayout == "fitblur") {
        Text("Se ve el video completo, centrado, con el mismo video desenfocado de fondo.", color = Pal.Muted, fontSize = 13.sp)
        return
    }

    val boxes = Layouts.boxesOf(spec)
    val dst = Layouts.dest(spec, ow, oh, sAsp)
    val n = boxes.size
    val cur = if (sel >= n) 0 else sel
    val colors = listOf(Pal.Cyan, Pal.Violet, Pal.Turq, Pal.Warn)

    Label("ORDEN: tocá un recuadro para editarlo y usá las flechas para cambiar cuál va primero")
    boxes.forEachIndexed { i, _ ->
        val on = i == cur
        Row(
            Modifier.fillMaxWidth().padding(bottom = 6.dp).clip(RoundedCornerShape(14.dp))
                .background(if (on) Pal.Surface2 else Pal.Surface)
                .then(if (on) Modifier.border(2.dp, colors[i % 4], RoundedCornerShape(14.dp)) else Modifier)
                .clickable { sel = i }.padding(horizontal = 12.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(Modifier.size(14.dp).clip(CircleShape).background(colors[i % 4]))
            Spacer(Modifier.width(10.dp))
            Text("Recuadro ${i + 1} · ${positionName(spec.boxLayout, i)}", color = Pal.Text, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            IconButton(enabled = i > 0, onClick = { edit { s -> s.copy(boxes = Layouts.swap(Layouts.boxesOf(s), i, i - 1)) }; sel = i - 1 }) {
                Icon(Icons.Rounded.ArrowUpward, "Subir", tint = if (i > 0) Pal.Cyan else Pal.Surface2)
            }
            IconButton(enabled = i < n - 1, onClick = { edit { s -> s.copy(boxes = Layouts.swap(Layouts.boxesOf(s), i, i + 1)) }; sel = i + 1 }) {
                Icon(Icons.Rounded.ArrowDownward, "Bajar", tint = if (i < n - 1) Pal.Cyan else Pal.Surface2)
            }
        }
    }

    Label("QUÉ MUESTRA EL RECUADRO ${cur + 1}")
    Box(Modifier.fillMaxWidth().aspectRatio(sAsp).clip(RoundedCornerShape(12.dp)).background(Color.Black)) {
        frame?.let { Image(it.asImageBitmap(), "Video original", Modifier.fillMaxSize()) }
        Canvas(Modifier.fillMaxSize().pointerInput(cur, spec.boxLayout) {
            detectDragGestures { change, drag ->
                change.consume()
                edit { s ->
                    val bl = Layouts.boxesOf(s).toMutableList()
                    val b = bl[cur]
                    bl[cur] = b.copy(cx = (b.cx + drag.x / size.width).coerceIn(0f, 1f), cy = (b.cy + drag.y / size.height).coerceIn(0f, 1f))
                    s.copy(boxes = bl)
                }
            }
        }) {
            boxes.forEachIndexed { i, b ->
                val r = Layouts.srcRect(b, dst[i], project.width, project.height, ow, oh)
                drawRect(
                    color = colors[i % 4], topLeft = Offset(r[0] * size.width, r[1] * size.height),
                    size = androidx.compose.ui.geometry.Size(r[2] * size.width, r[3] * size.height),
                    style = Stroke(width = if (i == cur) 6f else 3f),
                )
            }
        }
    }
    Text("Arrastrá el marco del recuadro ${cur + 1} sobre la imagen (cada color es un recuadro).", color = Pal.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp, bottom = 6.dp))
    GhostButton(if (busy) "Buscando…" else "Buscar mi cámara (rostro) en el recuadro ${cur + 1}", { detect(cur) }, icon = Icons.Rounded.Face)
    SliderRow("Zoom del recuadro ${cur + 1}", boxes[cur].zoom, 1f..8f, { v ->
        edit { s -> val bl = Layouts.boxesOf(s).toMutableList(); bl[cur] = bl[cur].copy(zoom = v); s.copy(boxes = bl) }
    }, String.format("%.1fx", boxes[cur].zoom))

    Label("TAMAÑO DE CADA ZONA")
    when (spec.boxLayout) {
        "stack2" -> SliderRow("Alto del recuadro 1", spec.boxSplit, 0.15f..0.85f, { v -> edit { it.copy(boxSplit = v) } }, "${(spec.boxSplit * 100).toInt()}%")
        "side2" -> SliderRow("Ancho del recuadro 1", spec.boxSplit, 0.15f..0.85f, { v -> edit { it.copy(boxSplit = v) } }, "${(spec.boxSplit * 100).toInt()}%")
        "stack3" -> {
            SliderRow("Alto del recuadro 1", spec.boxSplit, 0.15f..0.7f, { v -> edit { it.copy(boxSplit = v) } }, "${(spec.boxSplit * 100).toInt()}%")
            SliderRow("Alto del recuadro 2", spec.boxSplit2, 0.15f..0.7f, { v -> edit { it.copy(boxSplit2 = v) } }, "${(spec.boxSplit2 * 100).toInt()}%")
        }
        "three" -> {
            SliderRow("Alto de la fila de arriba", spec.boxSplit, 0.15f..0.85f, { v -> edit { it.copy(boxSplit = v) } }, "${(spec.boxSplit * 100).toInt()}%")
            SliderRow("Ancho del recuadro 2", spec.boxSplit2, 0.2f..0.8f, { v -> edit { it.copy(boxSplit2 = v) } }, "${(spec.boxSplit2 * 100).toInt()}%")
        }
        "grid4" -> {
            SliderRow("Ancho de la columna izquierda", spec.boxSplit, 0.2f..0.8f, { v -> edit { it.copy(boxSplit = v) } }, "${(spec.boxSplit * 100).toInt()}%")
            SliderRow("Alto de la fila de arriba", spec.boxSplit2, 0.2f..0.8f, { v -> edit { it.copy(boxSplit2 = v) } }, "${(spec.boxSplit2 * 100).toInt()}%")
        }
        "pip" -> {
            SliderRow("Tamaño de la cámara", spec.pipSize, 0.2f..0.6f, { v -> edit { it.copy(pipSize = v) } }, "${(spec.pipSize * 100).toInt()}%")
            Label("POSICIÓN DE LA CÁMARA")
            Chips(listOf("tl" to "Arriba izq.", "tr" to "Arriba der.", "bl" to "Abajo izq.", "br" to "Abajo der."), spec.pipCorner, { v -> edit { it.copy(pipCorner = v) } })
            SwitchRow("Cámara redonda", spec.pipRound, { v -> edit { it.copy(pipRound = v) } })
        }
    }
    Spacer(Modifier.height(6.dp))
    Text("Los subtítulos, filtros y efectos se aplican encima de todos los recuadros.", color = Pal.Muted, fontSize = 12.sp)
}
