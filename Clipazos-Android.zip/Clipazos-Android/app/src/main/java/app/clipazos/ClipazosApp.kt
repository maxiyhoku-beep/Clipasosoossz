package app.clipazos

import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import app.clipazos.data.Store
import app.clipazos.work.Notifs

class Prefs(ctx: Context) {
    private val sp: SharedPreferences = ctx.getSharedPreferences("clipazos", Context.MODE_PRIVATE)
    var defaultRes: String
        get() = sp.getString("res", "1080p") ?: "1080p"
        set(v) { sp.edit().putString("res", v).apply() }
    var defaultAspect: String
        get() = sp.getString("aspect", "9:16") ?: "9:16"
        set(v) { sp.edit().putString("aspect", v).apply() }
}

class ClipazosApp : Application() {
    lateinit var store: Store
    lateinit var prefs: Prefs

    override fun onCreate() {
        super.onCreate()
        store = Store(this)
        prefs = Prefs(this)
        Notifs.createChannels(this)
    }
}

val Context.clipazos: ClipazosApp get() = applicationContext as ClipazosApp
