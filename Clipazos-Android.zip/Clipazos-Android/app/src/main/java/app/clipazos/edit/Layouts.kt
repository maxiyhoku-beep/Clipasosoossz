package app.clipazos.edit

import app.clipazos.data.BoxSpec
import app.clipazos.data.EditSpec
import kotlin.math.min

/**
 * Disposiciones de varios recuadros basadas en las de Opus Clip: Fill, Fit (fondo desenfocado), Split, Three, Four,
 * Screenshare (pantalla arriba + cámara abajo) y Gameplay (cámara 30 % arriba + juego 70 % abajo), más cámara redonda,
 * lado a lado y 3 filas. En todas se puede cambiar el orden, el tamaño de cada zona y qué parte del video muestra cada recuadro.
 */
object Layouts {
    data class Preset(val id: String, val name: String, val desc: String)

    val presets = listOf(
        Preset("fill", "Rellenar", "Recorta para llenar la pantalla"),
        Preset("fit", "Ajustar", "Video completo con fondo desenfocado"),
        Preset("split", "Dividido", "2 personas: una arriba, otra abajo"),
        Preset("three", "Tres", "1 arriba y 2 abajo"),
        Preset("four", "Cuatro", "4 recuadros en cuadrícula"),
        Preset("screen", "Pantalla + cámara", "Pantalla arriba, cámara abajo"),
        Preset("gameplay", "Gameplay", "Cámara 30 % arriba, juego 70 % abajo"),
        Preset("pip", "Cámara redonda", "Cámara en una esquina"),
        Preset("side", "Lado a lado", "2 recuadros horizontales"),
        Preset("rows3", "3 filas", "3 recuadros apilados"),
    )

    fun applyPreset(s: EditSpec, id: String): EditSpec = when (id) {
        "fill" -> s.copy(boxPreset = id, boxLayout = "none", boxes = emptyList(), layout = "fill")
        "fit" -> s.copy(boxPreset = id, boxLayout = "fitblur", boxes = emptyList())
        "split" -> s.copy(boxPreset = id, boxLayout = "stack2", boxSplit = 0.5f, boxes = listOf(BoxSpec(0.27f, 0.5f, 1.7f), BoxSpec(0.73f, 0.5f, 1.7f)))
        "three" -> s.copy(boxPreset = id, boxLayout = "three", boxSplit = 0.5f, boxSplit2 = 0.5f,
            boxes = listOf(BoxSpec(0.5f, 0.5f, 1.6f), BoxSpec(0.2f, 0.5f, 2.2f), BoxSpec(0.8f, 0.5f, 2.2f)))
        "four" -> s.copy(boxPreset = id, boxLayout = "grid4", boxSplit = 0.5f, boxSplit2 = 0.5f,
            boxes = listOf(BoxSpec(0.25f, 0.25f, 2f), BoxSpec(0.75f, 0.25f, 2f), BoxSpec(0.25f, 0.75f, 2f), BoxSpec(0.75f, 0.75f, 2f)))
        "screen" -> s.copy(boxPreset = id, boxLayout = "stack2", boxSplit = 0.5f, boxes = listOf(BoxSpec(0.5f, 0.5f, 1f), BoxSpec(0.85f, 0.82f, 3.2f)))
        "gameplay" -> s.copy(boxPreset = id, boxLayout = "stack2", boxSplit = 0.3f, boxes = listOf(BoxSpec(0.85f, 0.82f, 3.2f), BoxSpec(0.5f, 0.5f, 1f)))
        "pip" -> s.copy(boxPreset = id, boxLayout = "pip", boxes = listOf(BoxSpec(0.5f, 0.5f, 1f), BoxSpec(0.85f, 0.82f, 3.2f)))
        "side" -> s.copy(boxPreset = id, boxLayout = "side2", boxSplit = 0.5f, boxes = listOf(BoxSpec(0.3f, 0.5f, 1f), BoxSpec(0.7f, 0.5f, 1f)))
        "rows3" -> s.copy(boxPreset = id, boxLayout = "stack3", boxSplit = 0.34f, boxSplit2 = 0.33f,
            boxes = listOf(BoxSpec(0.5f, 0.5f, 1.6f), BoxSpec(0.5f, 0.5f, 1.6f), BoxSpec(0.5f, 0.5f, 1.6f)))
        else -> s
    }

    /** Preset resaltado en la lista. */
    fun currentPreset(s: EditSpec): String = if (s.boxLayout == "none") "fill" else s.boxPreset

    fun count(layout: String): Int = when (layout) { "stack2", "side2", "pip", "fitblur" -> 2; "three", "stack3" -> 3; "grid4" -> 4; else -> 1 }

    fun defaultBoxes(layout: String): List<BoxSpec> = when (layout) {
        "stack2", "pip" -> listOf(BoxSpec(0.5f, 0.5f, 1f), BoxSpec(0.85f, 0.82f, 3.2f))
        "side2" -> listOf(BoxSpec(0.3f, 0.5f, 1f), BoxSpec(0.7f, 0.5f, 1f))
        "three" -> listOf(BoxSpec(0.5f, 0.5f, 1.6f), BoxSpec(0.2f, 0.5f, 2.2f), BoxSpec(0.8f, 0.5f, 2.2f))
        "stack3" -> List(3) { BoxSpec(0.5f, 0.5f, 1.6f) }
        "grid4" -> listOf(BoxSpec(0.25f, 0.25f, 2f), BoxSpec(0.75f, 0.25f, 2f), BoxSpec(0.25f, 0.75f, 2f), BoxSpec(0.75f, 0.75f, 2f))
        "fitblur" -> listOf(BoxSpec(), BoxSpec())
        else -> listOf(BoxSpec())
    }

    fun boxesOf(spec: EditSpec): List<BoxSpec> =
        if (spec.boxes.size >= count(spec.boxLayout)) spec.boxes.take(count(spec.boxLayout)) else defaultBoxes(spec.boxLayout)

    /** x, y, ancho, alto de cada recuadro en fracciones de la pantalla de salida (origen arriba-izquierda), en orden de aparición. */
    fun dest(spec: EditSpec, outW: Int, outH: Int, srcAspect: Float): List<FloatArray> {
        val s = spec.boxSplit.coerceIn(0.15f, 0.85f)
        return when (spec.boxLayout) {
            "stack2" -> listOf(floatArrayOf(0f, 0f, 1f, s), floatArrayOf(0f, s, 1f, 1f - s))
            "side2" -> listOf(floatArrayOf(0f, 0f, s, 1f), floatArrayOf(s, 0f, 1f - s, 1f))
            "stack3" -> {
                val r1 = spec.boxSplit.coerceIn(0.15f, 0.7f)
                val r2 = spec.boxSplit2.coerceIn(0.15f, 0.85f - r1)
                listOf(floatArrayOf(0f, 0f, 1f, r1), floatArrayOf(0f, r1, 1f, r2), floatArrayOf(0f, r1 + r2, 1f, 1f - r1 - r2))
            }
            "three" -> {
                val x = spec.boxSplit2.coerceIn(0.2f, 0.8f)
                listOf(floatArrayOf(0f, 0f, 1f, s), floatArrayOf(0f, s, x, 1f - s), floatArrayOf(x, s, 1f - x, 1f - s))
            }
            "grid4" -> {
                val x = s
                val y = spec.boxSplit2.coerceIn(0.2f, 0.8f)
                listOf(floatArrayOf(0f, 0f, x, y), floatArrayOf(x, 0f, 1f - x, y), floatArrayOf(0f, y, x, 1f - y), floatArrayOf(x, y, 1f - x, 1f - y))
            }
            "pip" -> {
                val p = spec.pipSize.coerceIn(0.15f, 0.6f)
                val h = p * outW / outH
                val x = if (spec.pipCorner.endsWith("l")) 0.04f else 1f - p - 0.04f
                val y = if (spec.pipCorner.startsWith("t")) 0.05f else 1f - h - 0.12f
                listOf(floatArrayOf(0f, 0f, 1f, 1f), floatArrayOf(x, y, p, h))
            }
            "fitblur" -> {
                val oa = outW.toFloat() / outH
                if (srcAspect >= oa) {
                    val h = oa / srcAspect
                    listOf(floatArrayOf(0f, 0f, 1f, 1f), floatArrayOf(0f, (1f - h) / 2f, 1f, h))
                } else {
                    val w = srcAspect / oa
                    listOf(floatArrayOf(0f, 0f, 1f, 1f), floatArrayOf((1f - w) / 2f, 0f, w, 1f))
                }
            }
            else -> listOf(floatArrayOf(0f, 0f, 1f, 1f))
        }
    }

    fun rounds(spec: EditSpec): List<Float> =
        if (spec.boxLayout == "pip") listOf(0f, if (spec.pipRound) 0.5f else 0.12f) else List(count(spec.boxLayout)) { 0f }

    /** 1 = fondo desenfocado (solo el recuadro de fondo del modo "Ajustar"). */
    fun modes(spec: EditSpec): List<Float> = if (spec.boxLayout == "fitblur") listOf(1f, 0f) else List(count(spec.boxLayout)) { 0f }

    /** Zona del video original (x, y, ancho, alto en fracciones, origen arriba-izquierda) que se muestra en un recuadro sin deformarse. */
    fun srcRect(b: BoxSpec, d: FloatArray, srcW: Int, srcH: Int, outW: Int, outH: Int): FloatArray {
        val ad = (d[2] * outW) / (d[3] * outH)
        val asrc = srcW.toFloat() / srcH
        var rw: Float
        var rh: Float
        if (ad <= asrc) { rw = ad / asrc; rh = 1f } else { rw = 1f; rh = asrc / ad }
        val z = b.zoom.coerceIn(1f, 8f)
        rw /= z; rh /= z
        val x = (b.cx - rw / 2f).coerceIn(0f, 1f - rw)
        val y = (b.cy - rh / 2f).coerceIn(0f, 1f - rh)
        return floatArrayOf(x, y, rw, rh)
    }

    /** Ajusta un recuadro para que un rostro (x, y, ancho, alto en fracciones del video) quede centrado y ocupe ~45 % del recuadro. */
    fun fitFace(face: FloatArray, d: FloatArray, srcW: Int, srcH: Int, outW: Int, outH: Int): BoxSpec {
        val base = srcRect(BoxSpec(), d, srcW, srcH, outW, outH)
        val zH = base[3] * 0.45f / face[3].coerceAtLeast(0.01f)
        val zW = base[2] * 0.45f / face[2].coerceAtLeast(0.01f)
        return BoxSpec(face[0] + face[2] / 2f, face[1] + face[3] / 2f, min(zH, zW).coerceIn(1f, 8f))
    }

    /** Intercambia el contenido de dos posiciones (para cambiar qué va arriba/abajo). */
    fun swap(boxes: List<BoxSpec>, a: Int, b: Int): List<BoxSpec> {
        if (a !in boxes.indices || b !in boxes.indices) return boxes
        val l = boxes.toMutableList()
        val t = l[a]; l[a] = l[b]; l[b] = t
        return l
    }
}
