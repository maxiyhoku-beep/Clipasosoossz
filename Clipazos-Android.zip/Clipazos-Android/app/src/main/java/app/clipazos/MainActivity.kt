package app.clipazos

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.core.content.ContextCompat
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import app.clipazos.ui.ClipazosTheme
import app.clipazos.ui.EditorScreen
import app.clipazos.ui.MainScreen
import app.clipazos.ui.ProjectScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        setContent { ClipazosTheme { AppNav() } }
    }
}

@Composable
fun AppNav() {
    val nav = rememberNavController()
    NavHost(
        navController = nav, startDestination = "main",
        enterTransition = { fadeIn(tween(220)) }, exitTransition = { fadeOut(tween(160)) },
        popEnterTransition = { fadeIn(tween(220)) }, popExitTransition = { fadeOut(tween(160)) },
    ) {
        composable("main") { MainScreen(nav) }
        composable("project/{id}", arguments = listOf(navArgument("id") { type = NavType.StringType })) { e ->
            ProjectScreen(nav, e.arguments?.getString("id").orEmpty())
        }
        composable("editor/{id}", arguments = listOf(navArgument("id") { type = NavType.StringType })) { e ->
            EditorScreen(nav, e.arguments?.getString("id").orEmpty())
        }
    }
}
