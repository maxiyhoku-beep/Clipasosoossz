# Clipazos (Android)

Editor inteligente de videos largos que funciona 100 % en el celular: sin internet, sin claves, sin servidor y gratis.

- Transcripción: Vosk (reconocimiento de voz neuronal de código abierto) con el modelo de español incluido en el APK.
- Elección de momentos: señales reales de audio y texto (volumen, picos, velocidad, emoción, risas, preguntas, pausas, cambios de tema).
- Edición y exportación: Media3 (recorte, zoom, filtros, subtítulos incrustados, MP4 sin marca de agua).

Compilación: sube `Clipazos-Android.zip` a un repositorio de GitHub con `.github/workflows/build.yml`; el workflow extrae el ZIP, descarga el modelo de voz, corre las pruebas y compila el APK (artefacto `Clipazos-APK`).
