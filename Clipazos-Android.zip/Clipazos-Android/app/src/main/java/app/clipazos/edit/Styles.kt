package app.clipazos.edit

import android.graphics.Typeface
import app.clipazos.data.EditSpec

enum class CapAnim { NONE, POP, BOUNCE, SHAKE, FADE, TYPE }
enum class HighlightMode { NONE, CURRENT, PROGRESSIVE }

data class CaptionStyle(
    val id: String, val name: String,
    val family: String, val bold: Boolean = true, val italic: Boolean = false,
    val sizeEm: Float = 1f, val color: Int = 0xFFFFFFFF.toInt(), val highlight: Int = 0xFFFFE600.toInt(),
    val stroke: Int = 0xFF000000.toInt(), val strokeEm: Float = 0.12f,
    val shadowColor: Int = 0x99000000.toInt(), val shadowEm: Float = 0.06f,
    val box: Int = 0, val uppercase: Boolean = true,
    val anim: CapAnim = CapAnim.POP, val mode: HighlightMode = HighlightMode.CURRENT,
    val yFrac: Float = 0.68f, val maxWords: Int = 3, val emphasize: Boolean = false,
) {
    val typeface: Typeface by lazy {
        Typeface.create(Typeface.create(family, Typeface.NORMAL),
            when { bold && italic -> Typeface.BOLD_ITALIC; bold -> Typeface.BOLD; italic -> Typeface.ITALIC; else -> Typeface.NORMAL })
    }
}

object CaptionStyles {
    val all = listOf(
        CaptionStyle("hormozi", "Impacto", "sans-serif-black", sizeEm = 1.05f, highlight = 0xFFFFE600.toInt(), strokeEm = 0.14f, anim = CapAnim.POP),
        CaptionStyle("mrbeast", "Viral XL", "sans-serif-black", sizeEm = 1.2f, highlight = 0xFF39FF14.toInt(), strokeEm = 0.18f, anim = CapAnim.BOUNCE, maxWords = 2),
        CaptionStyle("karaoke", "Karaoke", "sans-serif-black", sizeEm = 1.0f, highlight = 0xFF22D3EE.toInt(), stroke = 0xFF0B1B4D.toInt(), strokeEm = 0.14f, mode = HighlightMode.PROGRESSIVE, anim = CapAnim.POP, maxWords = 4),
        CaptionStyle("neon", "Neón", "sans-serif-medium", sizeEm = 1.0f, color = 0xFFE0F7FF.toInt(), highlight = 0xFFFF4DFF.toInt(), strokeEm = 0f, shadowColor = 0xFF22D3EE.toInt(), shadowEm = 0.32f, anim = CapAnim.FADE),
        CaptionStyle("fuego", "Fuego", "sans-serif-black", sizeEm = 1.1f, highlight = 0xFFFF6A00.toInt(), stroke = 0xFF5A1000.toInt(), strokeEm = 0.16f, anim = CapAnim.SHAKE, maxWords = 2),
        CaptionStyle("gamer", "Gamer", "monospace", sizeEm = 0.95f, color = 0xFF39FF14.toInt(), highlight = 0xFFFFFFFF.toInt(), strokeEm = 0.12f, anim = CapAnim.TYPE, maxWords = 4),
        CaptionStyle("box", "Caja", "sans-serif-black", sizeEm = 0.9f, box = 0xDD000000.toInt(), strokeEm = 0f, shadowEm = 0f, anim = CapAnim.POP, maxWords = 3),
        CaptionStyle("pod", "Podcast", "sans-serif-condensed", sizeEm = 1.0f, box = 0xE67C3AED.toInt(), highlight = 0xFF14E3C6.toInt(), strokeEm = 0f, shadowEm = 0f, uppercase = false, anim = CapAnim.FADE, maxWords = 5, yFrac = 0.72f),
        CaptionStyle("news", "Noticias", "sans-serif-medium", sizeEm = 0.8f, box = 0xEB2D6BFF.toInt(), strokeEm = 0f, shadowEm = 0f, uppercase = false, mode = HighlightMode.NONE, anim = CapAnim.FADE, maxWords = 7, yFrac = 0.8f),
        CaptionStyle("cine", "Cine", "serif", bold = false, italic = true, sizeEm = 0.85f, strokeEm = 0f, shadowEm = 0.08f, uppercase = false, mode = HighlightMode.NONE, anim = CapAnim.FADE, maxWords = 6, yFrac = 0.82f),
        CaptionStyle("minimal", "Minimal", "sans-serif-medium", bold = false, sizeEm = 0.75f, highlight = 0xFF7DD3FC.toInt(), strokeEm = 0f, shadowEm = 0.09f, uppercase = false, anim = CapAnim.NONE, maxWords = 5, yFrac = 0.78f),
    )
    fun get(id: String) = all.firstOrNull { it.id == id } ?: all[0]
}

data class FilterPreset(
    val id: String, val name: String,
    val sat: Float = 1f, val contrast: Float = 0f, val r: Float = 1f, val g: Float = 1f, val b: Float = 1f,
    val bright: Float = 0f, val gray: Boolean = false,
)

object Filters {
    val all = listOf(
        FilterPreset("none", "Original"),
        FilterPreset("vivid", "Vívido", sat = 1.35f, contrast = 0.15f),
        FilterPreset("pop", "Pop", sat = 1.6f, contrast = 0.2f, bright = 0.05f),
        FilterPreset("cine", "Cine", sat = 0.85f, contrast = 0.2f, r = 1.05f, b = 0.95f),
        FilterPreset("warm", "Cálido", sat = 1.05f, r = 1.1f, b = 0.9f),
        FilterPreset("cool", "Frío", r = 0.92f, b = 1.1f),
        FilterPreset("fade", "Desvaído", sat = 0.8f, contrast = -0.15f, bright = 0.06f),
        FilterPreset("bw", "B/N", gray = true),
        FilterPreset("noir", "Noir", gray = true, contrast = 0.4f),
    )
    fun get(id: String) = all.firstOrNull { it.id == id } ?: all[0]
}

data class EditStyle(val id: String, val name: String, val emoji: String, val desc: String, val apply: (EditSpec) -> EditSpec)

object EditStyles {
    val all = listOf(
        EditStyle("viral", "Dinámico viral", "🔥", "Zoom rápido, sin silencios, emojis y sonidos") {
            it.copy(styleId = "viral", captionStyleId = "hormozi", filterId = "vivid", zoomMode = "auto", zoomIntensity = 1.5f,
                removeSilences = true, transitionIn = "zoom", transitionOut = "none", progressBar = true, vignette = false,
                cinemaBars = false, hook = true, emojisOn = true, sfxOn = true)
        },
        EditStyle("streamer", "Streamer", "🎮", "Energía alta, flash de entrada y emojis") {
            it.copy(styleId = "streamer", captionStyleId = "mrbeast", filterId = "pop", zoomMode = "auto", zoomIntensity = 1.3f,
                removeSilences = false, transitionIn = "flash", transitionOut = "none", progressBar = true, vignette = false,
                cinemaBars = false, hook = true, emojisOn = true, sfxOn = true)
        },
        EditStyle("podcast", "Podcast", "🎙️", "Limpio, subtítulos en caja y zoom suave") {
            it.copy(styleId = "podcast", captionStyleId = "pod", filterId = "none", zoomMode = "auto", zoomIntensity = 0.6f,
                removeSilences = true, transitionIn = "fade", transitionOut = "fade", progressBar = false, vignette = false,
                cinemaBars = false, hook = true, emojisOn = false, sfxOn = false)
        },
        EditStyle("gaming", "Gaming", "👾", "Neón, viñeta y barra de progreso") {
            it.copy(styleId = "gaming", captionStyleId = "gamer", filterId = "pop", zoomMode = "auto", zoomIntensity = 1.2f,
                removeSilences = false, transitionIn = "flash", transitionOut = "none", progressBar = true, vignette = true,
                cinemaBars = false, hook = true, emojisOn = true, sfxOn = true)
        },
        EditStyle("news", "Informativo", "📰", "Serio y claro, subtítulos en caja azul") {
            it.copy(styleId = "news", captionStyleId = "news", filterId = "none", zoomMode = "none", zoomIntensity = 0f,
                removeSilences = false, transitionIn = "fade", transitionOut = "fade", progressBar = true, vignette = false,
                cinemaBars = false, hook = true, emojisOn = false, sfxOn = false)
        },
        EditStyle("cine", "Cinematográfico", "🎬", "Barras de cine, viñeta y color de película") {
            it.copy(styleId = "cine", captionStyleId = "cine", filterId = "cine", zoomMode = "auto", zoomIntensity = 0.4f,
                removeSilences = false, transitionIn = "fade", transitionOut = "fade", progressBar = false, vignette = true,
                cinemaBars = true, hook = false, emojisOn = false, sfxOn = false)
        },
        EditStyle("minimal", "Minimalista", "◻️", "Sin efectos: solo subtítulos discretos") {
            it.copy(styleId = "minimal", captionStyleId = "minimal", filterId = "none", zoomMode = "none", zoomIntensity = 0f,
                removeSilences = false, transitionIn = "none", transitionOut = "none", progressBar = false, vignette = false,
                cinemaBars = false, hook = false, emojisOn = false, sfxOn = false)
        },
    )
    fun get(id: String) = all.firstOrNull { it.id == id } ?: all[0]

    /** Estilo recomendado según la categoría que detectó la IA. */
    fun forCategory(cat: String): String = when (cat) {
        "divertido", "reaccion", "inesperado" -> "viral"
        "discusion" -> "streamer"
        "historia", "emocionante" -> "cine"
        "frase" -> "podcast"
        else -> "viral"
    }
}
