package app.clipazos.media

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import app.clipazos.data.Project
import app.clipazos.data.ProjectStatus
import app.clipazos.data.Store
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.nio.ByteBuffer
import kotlin.math.max
import kotlin.math.min

/**
 * Convierte el video a un MP4 normal (con índice) SIN recodificar: copia las muestras de video y audio tal cual.
 * Arregla grabaciones de pantalla / gameplay "fragmentadas" o sin índice, donde el reproductor no puede saltar a un punto
 * del medio ("Illegal clipping: not seekable to start") y por eso fallan la vista previa y la exportación.
 */
object Remux {
    suspend fun toSeekableMp4(ctx: Context, src: Uri, dest: File, totalBytes: Long, onProgress: (Float) -> Unit) = withContext(Dispatchers.IO) {
        dest.parentFile?.mkdirs()
        val tmp = File(dest.parentFile, dest.name + ".part")
        tmp.delete()
        val ex = MediaExtractor()
        var muxer: MediaMuxer? = null
        var started = false
        try {
            ex.setDataSource(ctx, src, null)
            var vIdx = -1
            var aIdx = -1
            for (i in 0 until ex.trackCount) {
                val m = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
                if (m.startsWith("video/") && vIdx < 0) vIdx = i else if (m.startsWith("audio/") && aIdx < 0) aIdx = i
            }
            if (vIdx < 0) throw IllegalStateException("El archivo no tiene pista de video.")

            var rotation = 0
            runCatching {
                val r = MediaMetadataRetriever()
                try { r.setDataSource(ctx, src); rotation = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0 } finally { r.release() }
            }
            val mux = MediaMuxer(tmp.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            muxer = mux
            if (rotation != 0) mux.setOrientationHint(rotation)

            val map = HashMap<Int, Int>()
            val mimes = HashMap<Int, String>()
            var maxSize = 8 shl 20
            for (i in listOf(vIdx, aIdx).filter { it >= 0 }) {
                val f = ex.getTrackFormat(i)
                map[i] = try { mux.addTrack(f) } catch (e: Exception) {
                    throw IllegalStateException("El códec (${f.getString(MediaFormat.KEY_MIME)}) no se puede convertir en este celular.")
                }
                ex.selectTrack(i)
                mimes[i] = f.getString(MediaFormat.KEY_MIME) ?: ""
                if (f.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) maxSize = max(maxSize, f.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE))
            }
            mux.start(); started = true

            val buf = ByteBuffer.allocate(max(maxSize, 12 shl 20))
            val info = MediaCodec.BufferInfo()
            var base = -1L
            var written = 0L
            var lastReport = 0L
            var samples = 0
            var scratch = ByteArray(1 shl 20)
            var firstVideo = true
            while (true) {
                val ti = ex.sampleTrackIndex
                if (ti < 0) break
                val dst = map[ti]
                if (dst == null) { if (!ex.advance()) break else continue }
                buf.clear()
                val size = ex.readSampleData(buf, 0)
                if (size < 0) break
                val t = ex.sampleTime
                if (base < 0) base = max(0L, t)
                // Los fotogramas clave se detectan en el propio flujo H.264/H.265 (IDR/IRAP): algunas grabaciones marcan TODAS las
                // muestras como clave, y así el reproductor empieza a decodificar en cualquier cuadro y se ven colores rotos.
                var flags = ex.sampleFlags and MediaCodec.BUFFER_FLAG_KEY_FRAME
                val mime = mimes[ti] ?: ""
                if (ti == vIdx && (mime.contains("avc") || mime.contains("hevc"))) {
                    if (scratch.size < size) scratch = ByteArray(size + (1 shl 16))
                    val dup = buf.duplicate()
                    dup.position(0); dup.limit(size); dup.get(scratch, 0, size)
                    val k = Nal.isKeyFrame(mime, scratch, size)
                    flags = if (k == null) flags else if (k) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                    if (firstVideo) { flags = MediaCodec.BUFFER_FLAG_KEY_FRAME; firstVideo = false }
                }
                info.set(0, size, max(0L, t - base), flags)
                mux.writeSampleData(dst, buf, info)
                samples++
                written += size
                if (written - lastReport > 8_000_000L) {
                    lastReport = written
                    onProgress(if (totalBytes > 0) (written.toFloat() / totalBytes).coerceIn(0f, 0.99f) else 0f)
                    ensureActive()
                }
                if (!ex.advance()) break
            }
            if (samples == 0) throw IllegalStateException("No se pudieron leer datos del video.")
            mux.stop(); started = false
            mux.release(); muxer = null
            if (dest.exists()) dest.delete()
            if (!tmp.renameTo(dest)) throw IllegalStateException("No se pudo guardar el video convertido.")
            onProgress(1f)
        } catch (e: Throwable) {
            tmp.delete()
            throw e
        } finally {
            runCatching { if (started) muxer?.stop() }
            runCatching { muxer?.release() }
            runCatching { ex.release() }
        }
    }
}

/** Comprueba, con el mismo reproductor que usa la app, si se puede saltar a un punto del medio del video. */
object SeekCheck {
    suspend fun isSeekable(ctx: Context, uri: Uri, durationMs: Long): Boolean = withContext(Dispatchers.Main) {
        val player = ExoPlayer.Builder(ctx).build()
        val result = CompletableDeferred<Boolean>()
        val l = object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) { result.complete(false) }
            override fun onPlaybackStateChanged(playbackState: Int) { if (playbackState == Player.STATE_READY) result.complete(true) }
        }
        try {
            player.addListener(l)
            player.volume = 0f
            player.playWhenReady = false
            val start = (durationMs / 2).coerceAtLeast(0L)
            player.setMediaItem(
                MediaItem.Builder().setUri(uri)
                    .setClippingConfiguration(MediaItem.ClippingConfiguration.Builder().setStartPositionMs(start).setEndPositionMs(min(durationMs, start + 2000L)).build())
                    .build()
            )
            player.prepare()
            withTimeoutOrNull(12_000L) { result.await() } ?: true
        } finally {
            player.release()
        }
    }
}

object Repair {
    /** Convierte el video del proyecto a un MP4 compatible y actualiza el proyecto. Devuelve el proyecto corregido. */
    suspend fun fix(ctx: Context, store: Store, p: Project, onProgress: (Float) -> Unit): Project {
        if (p.sizeBytes > 0 && MediaCopy.freeBytes(ctx.filesDir) < p.sizeBytes + 200_000_000L)
            throw IllegalStateException("No hay espacio libre suficiente para reparar el video.")
        val dest = File(store.dir(p.id), "video_${System.currentTimeMillis()}.mp4")
        Remux.toSeekableMp4(ctx, Uri.parse(p.uri), dest, p.sizeBytes, onProgress)
        val info = VideoProbe.probe(ctx, Uri.fromFile(dest))
        if (p.uri.startsWith("file:")) runCatching { File(Uri.parse(p.uri).path!!).delete() }
        val np = p.copy(
            uri = Uri.fromFile(dest).toString(), durationMs = info.durationMs, width = info.width, height = info.height,
            verified = info.verified, seekable = true,
            status = if (p.status == ProjectStatus.DONE) ProjectStatus.IMPORTED else p.status, stage = "", progress = 0f,
            note = if (p.status == ProjectStatus.DONE) "Video reparado. Volvé a analizar para regenerar los clips y subtítulos con los tiempos correctos."
            else "Video convertido a MP4 compatible (sin recodificar).",
        )
        store.saveProject(np)
        return np
    }
}

/** Detección de fotogramas clave (IDR/IRAP) leyendo las unidades NAL de una muestra de video H.264 / H.265. */
object Nal {
    fun headers(data: ByteArray, size: Int): List<Int> {
        // 1) con prefijo de longitud (formato MP4: AVCC / HVCC)
        for (ls in intArrayOf(4, 3, 2, 1)) {
            val out = ArrayList<Int>()
            var p = 0
            var ok = true
            while (p + ls < size) {
                var len = 0
                for (k in 0 until ls) len = (len shl 8) or (data[p + k].toInt() and 0xFF)
                p += ls
                if (len <= 0 || p + len > size) { ok = false; break }
                out += (data[p].toInt() and 0xFF)
                p += len
            }
            if (ok && p == size && out.isNotEmpty()) return out
        }
        // 2) con códigos de inicio (Annex B)
        val out = ArrayList<Int>()
        var i = 0
        while (i + 3 < size) {
            val z0 = data[i].toInt() == 0 && data[i + 1].toInt() == 0
            if (z0 && data[i + 2].toInt() == 1) { if (i + 3 < size) out += (data[i + 3].toInt() and 0xFF); i += 3 }
            else if (z0 && data[i + 2].toInt() == 0 && data[i + 3].toInt() == 1) { if (i + 4 < size) out += (data[i + 4].toInt() and 0xFF); i += 4 }
            else i++
        }
        return out
    }

    /** true = fotograma clave, false = no lo es, null = no se pudo saber. */
    fun isKeyFrame(mime: String, data: ByteArray, size: Int): Boolean? {
        val h = headers(data, size)
        if (h.isEmpty()) return null
        return when {
            mime.contains("avc") -> h.any { (it and 0x1F) == 5 }
            mime.contains("hevc") -> h.any { ((it shr 1) and 0x3F) in 16..21 }
            else -> null
        }
    }
}
