package app.clipazos.edit

import app.clipazos.data.Word

data class Piece(val srcStart: Long, val srcEnd: Long) { val len: Long get() = srcEnd - srcStart }

/**
 * Relación entre el tiempo de SALIDA (lo que ve el espectador) y el tiempo del video ORIGINAL,
 * teniendo en cuenta recortes de silencios (saltos) y la velocidad.
 */
class TimeMap(val pieces: List<Piece>, val speed: Float) {
    val accBefore: List<Long>
    val totalSrcMs: Long
    init {
        var a = 0L
        val l = ArrayList<Long>(pieces.size)
        for (p in pieces) { l += a; a += p.len }
        accBefore = l
        totalSrcMs = a
    }
    val outDurationMs: Long get() = (totalSrcMs / speed).toLong()

    private fun indexForSrcOffset(s: Long): Int {
        var idx = 0
        for (i in pieces.indices) if (accBefore[i] <= s) idx = i else break
        return idx
    }

    fun sourceAt(outMs: Long): Long {
        if (pieces.isEmpty()) return 0
        val s = (outMs * speed).toLong().coerceIn(0, totalSrcMs)
        val i = indexForSrcOffset(s)
        return pieces[i].srcStart + (s - accBefore[i]).coerceAtMost(pieces[i].len)
    }

    /** Tiempo de salida de un instante del original, o null si cae en una parte eliminada. */
    fun outputAt(srcMs: Long): Long? {
        for (i in pieces.indices) {
            val p = pieces[i]
            if (srcMs >= p.srcStart && srcMs < p.srcEnd) return ((accBefore[i] + (srcMs - p.srcStart)) / speed).toLong()
        }
        return null
    }

    /** (índice de pieza, posición dentro de la pieza en ms) para un tiempo de salida. */
    fun locate(outMs: Long): Pair<Int, Long> {
        if (pieces.isEmpty()) return 0 to 0L
        val s = (outMs * speed).toLong().coerceIn(0, totalSrcMs)
        val i = indexForSrcOffset(s)
        return i to (s - accBefore[i]).coerceIn(0, pieces[i].len)
    }

    /** Tiempo de salida a partir de (pieza, posición dentro de la pieza). */
    fun outFor(index: Int, posMs: Long): Long {
        if (pieces.isEmpty()) return 0
        val i = index.coerceIn(0, pieces.lastIndex)
        return ((accBefore[i] + posMs) / speed).toLong()
    }

    companion object {
        fun build(startMs: Long, endMs: Long, words: List<Word>, removeSilences: Boolean, speed: Float): TimeMap {
            val single = listOf(Piece(startMs, endMs))
            if (!removeSilences) return TimeMap(single, speed)
            val ws = words.filter { it.s >= startMs && it.e <= endMs }.sortedBy { it.s }
            if (ws.size < 2) return TimeMap(single, speed)
            var threshold = 750L
            while (true) {
                val pieces = cut(startMs, endMs, ws, threshold)
                if (pieces.size <= 40 || threshold > 4000) return TimeMap(pieces, speed)
                threshold += 250
            }
        }

        private fun cut(startMs: Long, endMs: Long, ws: List<Word>, gapMs: Long): List<Piece> {
            val pad = 200L
            val out = ArrayList<Piece>()
            var cursor = startMs
            if (ws.first().s - startMs > gapMs) cursor = ws.first().s - pad
            for (i in 1 until ws.size) {
                val gap = ws[i].s - ws[i - 1].e
                if (gap > gapMs) {
                    val cutStart = ws[i - 1].e + pad
                    val cutEnd = ws[i].s - pad
                    if (cutEnd - cutStart >= 300) {
                        out += Piece(cursor, cutStart)
                        cursor = cutEnd
                    }
                }
            }
            var end = endMs
            if (endMs - ws.last().e > gapMs) end = ws.last().e + 300
            out += Piece(cursor, end.coerceAtLeast(cursor + 100))
            return out
        }
    }
}
