package app.clipazos.ai

import android.content.Context
import android.net.Uri
import app.clipazos.data.AppJson
import app.clipazos.data.PartResult
import app.clipazos.data.Segment
import app.clipazos.data.Transcript
import app.clipazos.data.Word
import app.clipazos.media.PcmDecoder
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import org.vosk.LibVosk
import org.vosk.LogLevel
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Reconocimiento de voz en español 100 % dentro del celular (Vosk / Kaldi, modelo incluido en el APK).
 * Sin internet, sin claves, sin costo. El audio se divide en tramos de 4 min que se transcriben EN PARALELO
 * (varios núcleos del celular) y cada tramo terminado se guarda para poder retomar si se interrumpe.
 * También mide el volumen del audio cada 100 ms.
 */
class SpeechEngine(private val ctx: Context) {
    companion object { const val PART_MS = 240_000L }

    fun modelDir(): File {
        val dir = File(ctx.filesDir, "vosk/model-es-small-0.42")
        val ok = File(dir, ".ok")
        if (ok.exists()) return dir
        val root = "model-es"
        if (ctx.assets.list(root).isNullOrEmpty())
            throw IllegalStateException("Falta el motor de voz dentro de la app. Volvé a compilar con el workflow completo (descarga el modelo de voz).")
        dir.deleteRecursively(); dir.mkdirs()
        copyAssets(root, dir)
        ok.writeText("1")
        return dir
    }

    private fun copyAssets(path: String, dst: File) {
        val list = ctx.assets.list(path)
        if (list.isNullOrEmpty()) {
            ctx.assets.open(path).use { i -> dst.outputStream().use { o -> i.copyTo(o) } }
        } else {
            dst.mkdirs()
            for (n in list) copyAssets("$path/$n", File(dst, n))
        }
    }

    /** onProgress(fracción 0..1, hilos en uso). */
    suspend fun transcribe(uri: Uri, durationMs: Long, partsDir: File, onProgress: (Float, Int) -> Unit): Transcript = coroutineScope {
        val dir = modelDir()
        partsDir.mkdirs()
        val n = ceil(durationMs / PART_MS.toDouble()).toInt().coerceAtLeast(1)
        val workers = min(n, (Runtime.getRuntime().availableProcessors() - 1).coerceIn(2, 4))
        val fracs = DoubleArray(n)
        fun report() { onProgress((fracs.sum() / n).toFloat(), workers) }
        val results = arrayOfNulls<PartResult>(n)

        LibVosk.setLogLevel(LogLevel.WARNINGS)
        val pool = Executors.newFixedThreadPool(workers)
        val dispatcher = pool.asCoroutineDispatcher()
        try {
            Model(dir.absolutePath).use { model ->
                (0 until n).map { i ->
                    async(dispatcher) {
                        val f = File(partsDir, "p$i.json")
                        val cached = runCatching { AppJson.decodeFromString<PartResult>(f.readText()) }.getOrNull()
                        if (cached != null) {
                            results[i] = cached
                        } else {
                            val job = currentCoroutineContext()[Job]
                            val r = runPart(model, uri, i * PART_MS, min(durationMs, (i + 1) * PART_MS), i == n - 1, durationMs, { job?.isActive == false }) { fr ->
                                synchronized(fracs) { fracs[i] = fr.toDouble(); report() }
                            }
                            ensureActive()
                            f.writeText(AppJson.encodeToString(r))
                            results[i] = r
                        }
                        synchronized(fracs) { fracs[i] = 1.0; report() }
                    }
                }.awaitAll()
            }
        } finally {
            dispatcher.close()
            pool.shutdown()
        }
        val parts = results.filterNotNull()
        val words = parts.flatMap { it.words }.sortedBy { it.s }
        val energy = ArrayList<Int>()
        for (p in parts) energy += p.energy
        Transcript(buildSegments(words), energy)
    }

    private fun runPart(
        model: Model, uri: Uri, start: Long, end: Long, last: Boolean, durationMs: Long,
        cancelled: () -> Boolean, onFrac: (Float) -> Unit,
    ): PartResult {
        val ds = max(0L, start - 2000L)                       // 2 s de contexto antes del tramo
        val de = if (last) Long.MAX_VALUE else min(durationMs, end + 3000L)   // 3 s después para terminar palabras cortadas
        val words = ArrayList<Word>()
        val energy = ArrayList<Int>()
        val span = (min(de, durationMs) - ds).coerceAtLeast(1L)
        Recognizer(model, PcmDecoder.OUT_RATE.toFloat()).use { rec ->
            rec.setWords(true)
            var fed = 0L
            var sumSq = 0.0
            var inWin = 0
            val bytes = ByteArray(PcmDecoder.OUT_RATE * 2)
            PcmDecoder.decode(ctx, uri, ds, de, cancelled) { buf, n ->
                for (i in 0 until n) {
                    val v = buf[i].toInt()
                    sumSq += v.toDouble() * v
                    if (++inWin == 1600) {
                        energy += (sqrt(sumSq / 1600) / 32768.0 * 1000.0).toInt().coerceIn(0, 1000)
                        sumSq = 0.0; inWin = 0
                    }
                    bytes[2 * i] = (v and 0xFF).toByte()
                    bytes[2 * i + 1] = (v shr 8).toByte()
                }
                if (rec.acceptWaveForm(bytes, n * 2)) parseWords(rec.result, ds, words)
                fed += n
                onFrac((fed * 1000L / PcmDecoder.OUT_RATE).toFloat() / span)
                !cancelled()
            }
            if (!cancelled()) parseWords(rec.finalResult, ds, words)
        }
        // Cada tramo se queda solo con SU zona (así no se duplican palabras en los solapes).
        val keepEnd = if (last) Long.MAX_VALUE else end
        val mine = words.filter { it.s >= start && it.s < keepEnd }
        val e0 = ((start - ds) / 100).toInt()
        val e1 = if (last) energy.size else min(energy.size, ((end - ds) / 100).toInt())
        val mineEnergy = if (e0 < e1) energy.subList(e0, e1).toList() else emptyList()
        return PartResult(mine, mineEnergy)
    }

    private fun parseWords(json: String, baseMs: Long, out: MutableList<Word>) {
        val obj: JsonObject = runCatching { AppJson.parseToJsonElement(json).jsonObject }.getOrNull() ?: return
        val arr: JsonArray = obj["result"]?.jsonArray ?: return
        for (e in arr) {
            val o = e.jsonObject
            val w = o["word"]?.jsonPrimitive?.content?.trim().orEmpty()
            val s = o["start"]?.jsonPrimitive?.doubleOrNull ?: continue
            val en = o["end"]?.jsonPrimitive?.doubleOrNull ?: continue
            if (w.isNotEmpty()) out += Word(baseMs + (s * 1000).toLong(), baseMs + (en * 1000).toLong(), w)
        }
    }

    /** Agrupa las palabras en frases: nueva frase tras una pausa de 0,6 s; las muy largas se parten en la pausa mayor. */
    private fun buildSegments(words: List<Word>): List<Segment> {
        val out = ArrayList<Segment>()
        var cur = ArrayList<Word>()
        fun flush() {
            if (cur.isEmpty()) return
            for (part in splitLong(cur)) {
                val fixed = part.mapIndexed { i, w -> if (i == 0) w.copy(w = w.w.replaceFirstChar { it.uppercase() }) else w }
                out += Segment(fixed.first().s, fixed.last().e, fixed.joinToString(" ") { it.w }, fixed)
            }
            cur = ArrayList()
        }
        for (w in words) {
            if (cur.isNotEmpty() && w.s - cur.last().e >= 600) flush()
            cur += w
        }
        flush()
        return out
    }

    private fun splitLong(words: List<Word>): List<List<Word>> {
        if (words.size < 8 || words.last().e - words.first().s <= 14_000) return listOf(words)
        val lo = words.size / 5
        val hi = words.size * 4 / 5
        var best = -1
        var gap = -1L
        for (i in max(lo, 1) until min(hi, words.size)) {
            val g = words[i].s - words[i - 1].e
            if (g > gap) { gap = g; best = i }
        }
        if (best <= 0) return listOf(words)
        return splitLong(words.subList(0, best)) + splitLong(words.subList(best, words.size))
    }
}
