package app.clipazos.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import app.clipazos.clipazos
import app.clipazos.export.ExportPlan
import app.clipazos.export.ExportService
import app.clipazos.export.ExportState

/** Elegir formato y calidad, y lanzar la exportación (individual o múltiple). */
@Composable
fun ExportDialog(clipIds: List<String>, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val app = ctx.clipazos
    var aspect by remember { mutableStateOf(app.prefs.defaultAspect) }
    var res by remember { mutableStateOf(app.prefs.defaultRes) }
    val ok4k = remember { ExportPlan.supports(2160, 3840) || ExportPlan.supports(3840, 2160) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Pal.Surface,
        title = { Text(if (clipIds.size == 1) "Exportar clip" else "Exportar ${clipIds.size} clips", color = Pal.Text) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Label("FORMATO")
                Chips(listOf("9:16" to "Vertical 9:16", "16:9" to "Horizontal 16:9", "1:1" to "Cuadrado 1:1"), aspect, { aspect = it })
                Label("CALIDAD (MP4, sin marca de agua)")
                Chips(buildList { add("720p" to "720p"); add("1080p" to "1080p"); if (ok4k) add("4K" to "4K") }, res, { res = it })
                if (!ok4k) Text("4K no está disponible: este celular no lo soporta al codificar.", color = Pal.Muted)
                Spacer(Modifier.height(6.dp))
                Text("Se guardan en Películas/Clipazos de tu galería.", color = Pal.Muted)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                app.prefs.defaultAspect = aspect; app.prefs.defaultRes = res
                clipIds.forEach { id -> app.store.clip(id)?.let { app.store.updateClip(it.copy(edit = it.edit.copy(aspect = aspect, resolution = res))) } }
                ExportService.start(ctx, clipIds)
                onDismiss()
            }) { Text("EXPORTAR", color = Pal.Cyan) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar", color = Pal.Muted) } },
    )
}

/** Barra de progreso global de exportación (se muestra mientras el servicio trabaja). */
@Composable
fun ExportProgressHost() {
    val ctx = LocalContext.current
    val ui by ExportState.flow.collectAsState()
    var dismissed by remember { mutableStateOf(false) }
    if (ui.active) dismissed = false
    if (ui.active) {
        AlertDialog(
            onDismissRequest = {}, containerColor = Pal.Surface,
            title = { Text("Exportando ${ui.index}/${ui.total}", color = Pal.Text) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(ui.title, color = Pal.Muted, maxLines = 2)
                    LinearProgressIndicator(progress = { ui.progress.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth(), color = Pal.Cyan, trackColor = Pal.Surface2)
                    Text("${(ui.progress * 100).toInt()} %  ·  podés salir de la app, sigue en segundo plano", color = Pal.Muted)
                }
            },
            confirmButton = { TextButton(onClick = { ExportService.cancel(ctx) }) { Text("CANCELAR", color = Pal.Danger) } },
        )
    } else if (ui.finished && !dismissed) {
        AlertDialog(
            onDismissRequest = { dismissed = true }, containerColor = Pal.Surface,
            title = { Text(if (ui.cancelled) "Exportación cancelada" else if (ui.savedCount > 0) "¡Listo!" else "No se pudo exportar", color = Pal.Text) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (ui.savedCount > 0) Text("${ui.savedCount} clip(s) guardados en Películas/Clipazos. Los ves en la pestaña Historial.", color = Pal.Text)
                    ui.errors.forEach { Text("• $it", color = Pal.Danger) }
                }
            },
            confirmButton = { TextButton(onClick = { dismissed = true }) { Text("OK", color = Pal.Cyan) } },
        )
    }
}
