package app.clipazos.ui

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Help
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import app.clipazos.clipazos
import app.clipazos.data.Project
import app.clipazos.data.ProjectStatus
import app.clipazos.media.ProbeException
import app.clipazos.media.VideoProbe
import app.clipazos.util.TimeFmt
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date
import java.util.UUID

@Composable
fun MainScreen(nav: NavHostController) {
    val ctx = LocalContext.current
    val app = ctx.clipazos
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            busy = true
            scope.launch {
                try {
                    val info = VideoProbe.probe(ctx, uri)
                    val p = Project(
                        id = UUID.randomUUID().toString(), name = info.name.substringBeforeLast('.'), uri = uri.toString(),
                        durationMs = info.durationMs, width = info.width, height = info.height, sizeBytes = info.sizeBytes,
                        createdAt = System.currentTimeMillis(), verified = info.verified, note = info.note,
                    )
                    app.store.saveProject(p)
                    nav.navigate("project/${p.id}")
                } catch (e: ProbeException) {
                    err = e.message
                } catch (e: Exception) {
                    err = "No se pudo leer el video: ${e.message}"
                } finally { busy = false }
            }
        }
    }
    val upload = { picker.launch(arrayOf("video/*")) }

    Backdrop {
        Column(Modifier.fillMaxSize()) {
            Box(Modifier.weight(1f)) {
                when (tab) {
                    0 -> HomeTab(nav, upload)
                    1 -> HistoryTab()
                    2 -> HelpTab()
                    else -> SettingsTab()
                }
            }
            NavigationBar(containerColor = Color(0xF20B1128)) {
                listOf(Icons.Rounded.Home to "Inicio", Icons.Rounded.History to "Historial", Icons.Rounded.Help to "Ayuda", Icons.Rounded.Settings to "Ajustes")
                    .forEachIndexed { i, (ic, label) ->
                        NavigationBarItem(
                            selected = tab == i, onClick = { tab = i }, icon = { Icon(ic, label) }, label = { Text(label) },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = Color.White, selectedTextColor = Pal.Cyan, indicatorColor = Pal.Blue, unselectedIconColor = Pal.Muted, unselectedTextColor = Pal.Muted),
                        )
                    }
            }
        }
        if (busy) AlertDialog(
            onDismissRequest = {}, containerColor = Pal.Surface,
            title = { Text("Leyendo el video…", color = Pal.Text) },
            text = { Row(verticalAlignment = Alignment.CenterVertically) { CircularProgressIndicator(color = Pal.Cyan); Spacer(Modifier.width(16.dp)); Text("Midiendo la duración real del archivo", color = Pal.Muted) } },
            confirmButton = {},
        )
        err?.let { AlertDialog(onDismissRequest = { err = null }, containerColor = Pal.Surface, title = { Text("No se pudo importar", color = Pal.Text) }, text = { Text(it, color = Pal.Muted) }, confirmButton = { TextButton(onClick = { err = null }) { Text("OK", color = Pal.Cyan) } }) }
        ExportProgressHost()
    }
}

@Composable
private fun HomeTab(nav: NavHostController, upload: () -> Unit) {
    val app = LocalContext.current.clipazos
    val projects by app.store.projects.collectAsState()
    var delete by remember { mutableStateOf<Project?>(null) }
    LazyColumn(Modifier.fillMaxSize().statusBarsPadding(), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Logo() }
        item {
            Text("Convertí videos largos en clips virales", color = Pal.Text, fontSize = 26.sp, fontWeight = FontWeight.Black, lineHeight = 30.sp)
            Text("Subí un video: se transcribe en tu celular, se eligen los mejores momentos y quedan listos con subtítulos. Sin internet y gratis.", color = Pal.Muted, modifier = Modifier.padding(top = 6.dp))
        }
        item { GradientButton("SUBIR VIDEO", upload, Modifier.fillMaxWidth(), icon = Icons.Rounded.Add, height = 62.dp) }
        if (projects.isEmpty()) {
            item {
                Panel(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Rounded.VideoLibrary, null, tint = Pal.Cyan, modifier = Modifier.height(40.dp))
                        Text("Todavía no tenés proyectos", color = Pal.Text, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
                        Text("Tocá SUBIR VIDEO para empezar.", color = Pal.Muted)
                    }
                }
            }
        } else {
            item { SectionTitle("Proyectos recientes") }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(projects.take(8), key = { it.id }) { p -> ProjectCard(p, { nav.navigate("project/${p.id}") }, { delete = p }) }
                }
            }
            val done = projects.filter { it.status == ProjectStatus.DONE }
            if (done.isNotEmpty()) {
                item { SectionTitle("Videos procesados") }
                items(done, key = { "d" + it.id }) { p ->
                    Panel(Modifier.fillMaxWidth(), onClick = { nav.navigate("project/${p.id}") }) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(p.name, color = Pal.Text, fontWeight = FontWeight.Bold, maxLines = 1)
                                Text("${p.clipCount} clips · ${TimeFmt.format(p.durationMs)}", color = Pal.Muted, fontSize = 13.sp)
                            }
                            Pill("LISTO", Pal.Ok)
                        }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(8.dp)) }
    }
    delete?.let { p ->
        AlertDialog(onDismissRequest = { delete = null }, containerColor = Pal.Surface,
            title = { Text("¿Borrar proyecto?", color = Pal.Text) },
            text = { Text("Se borran los clips y subtítulos de \"${p.name}\". Tu video original no se toca.", color = Pal.Muted) },
            confirmButton = { TextButton(onClick = { app.store.deleteProject(p.id); delete = null }) { Text("BORRAR", color = Pal.Danger) } },
            dismissButton = { TextButton(onClick = { delete = null }) { Text("Cancelar", color = Pal.Muted) } })
    }
}

@Composable
private fun ProjectCard(p: Project, onOpen: () -> Unit, onDelete: () -> Unit) {
    Panel(Modifier.width(210.dp), onClick = onOpen) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f)) {
                    when (p.status) {
                        ProjectStatus.DONE -> Pill("LISTO", Pal.Ok)
                        ProjectStatus.ANALYZING -> Pill("ANALIZANDO ${(p.progress * 100).toInt()}%", Pal.Cyan)
                        ProjectStatus.ERROR -> Pill("ERROR", Pal.Danger)
                        else -> Pill("IMPORTADO", Pal.Violet)
                    }
                }
                Icon(Icons.Rounded.Delete, "Borrar", tint = Pal.Muted, modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onDelete).padding(2.dp))
            }
            Text(p.name, color = Pal.Text, fontWeight = FontWeight.Bold, maxLines = 2)
            Text("DURACIÓN: ${TimeFmt.format(p.durationMs)}", color = Pal.Cyan, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Text(DateFormat.getDateInstance(DateFormat.SHORT).format(Date(p.createdAt)), color = Pal.Muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun HistoryTab() {
    val ctx = LocalContext.current
    val store = ctx.clipazos.store
    val list by store.exports.collectAsState()
    LazyColumn(Modifier.fillMaxSize().statusBarsPadding(), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { SectionTitle("Historial de exportaciones") }
        if (list.isEmpty()) item { Text("Acá van a aparecer los clips que exportes.", color = Pal.Muted) }
        items(list, key = { it.id }) { r ->
            Panel(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(r.title, color = Pal.Text, fontWeight = FontWeight.Bold, maxLines = 2)
                    Text("${r.label} · ${DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(r.createdAt))}", color = Pal.Muted, fontSize = 13.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        GhostButton("Abrir", { openVideo(ctx, r.uri) }, icon = Icons.Rounded.PlayArrow)
                        GhostButton("Compartir", { shareVideo(ctx, r.uri) }, icon = Icons.Rounded.Share)
                        GhostButton("Quitar", { store.removeExport(r.id) }, danger = true)
                    }
                }
            }
        }
    }
}

private val TIPS = listOf(
    "Gancho en los primeros 3 segundos" to "Lo que más retiene es una frase fuerte al inicio. El título que genera la IA aparece arriba durante 3 s: editalo si podés hacerlo más llamativo.",
    "Subtítulos grandes y en la zona segura" to "TikTok, Reels y Shorts tapan el borde inferior y el lateral derecho con botones. Activá \"Zonas seguras\" en la pestaña Pro del editor y dejá el texto en el centro.",
    "Ritmo: un cambio visual cada 2–4 s" to "El zoom automático hace un \"golpe\" en cada frase nueva. Con \"Quitar silencios\" se eliminan las pausas largas y el clip se siente más rápido.",
    "Elegí 1 o 2 palabras para destacar" to "Los estilos Impacto, Viral XL y Fuego resaltan la palabra que se está diciendo. Evitá estilos con muchas palabras por línea en clips muy emocionales.",
    "La música no debe tapar la voz" to "Dejá la música entre 10% y 20% de volumen. Los efectos de sonido (whoosh/pop) se mezclan solos en los cambios de zoom y en los emojis.",
    "Duración ideal: 30–60 s" to "Clipazos pide clips de 30 s a 1:20. Si el final queda cortado en medio de una frase, ajustá el recorte en la pestaña Formato: los subtítulos se extienden ±40 s.",
    "Un formato por plataforma" to "9:16 para TikTok/Reels/Shorts, 1:1 para feed de Instagram/Facebook, 16:9 para YouTube normal. Exportá en 1080p salvo que tu plataforma pida más.",
    "Revisá siempre los subtítulos" to "La transcripción automática puede fallar con nombres propios o ruido. En la pestaña Subtítulos podés corregir cada frase sin perder la sincronización.",
)

@Composable
private fun HelpTab() {
    var open by remember { mutableIntStateOf(-1) }
    LazyColumn(Modifier.fillMaxSize().statusBarsPadding(), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { SectionTitle("Ayuda y tutoriales") }
        item {
            Panel(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Cómo se usa", color = Pal.Cyan, fontWeight = FontWeight.Bold)
                    Text("1. Subí un video largo desde tu celular.\n2. Verificá que la DURACIÓN coincida con la real.\n3. Elegí cuántos clips (3, 5, 10, 15 o personalizado).\n4. Tocá ANALIZAR: transcribe el audio, elige momentos y genera subtítulos (todo en tu celular, puede tardar en videos largos).\n5. Abrí un clip, ajustá estilo, subtítulos y efectos.\n6. Exportá en MP4 sin marca de agua.", color = Pal.Text)
                }
            }
        }
        item { Text("AYUDAS PRO PARA EDITAR", color = Pal.Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
        items(TIPS.size) { i ->
            Panel(Modifier.fillMaxWidth(), onClick = { open = if (open == i) -1 else i }) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Lightbulb, null, tint = Pal.Warn); Spacer(Modifier.width(10.dp))
                        Text(TIPS[i].first, color = Pal.Text, fontWeight = FontWeight.SemiBold)
                    }
                    if (open == i) Text(TIPS[i].second, color = Pal.Muted, modifier = Modifier.padding(top = 8.dp))
                }
            }
        }
        item {
            Panel(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Qué hace el análisis y sus límites", color = Pal.Cyan, fontWeight = FontWeight.Bold)
                    Text("• La transcripción usa un modelo de voz neuronal (Vosk) que corre en tu celular: sin internet, sin claves, gratis. Es menos precisa que los servicios de pago: no pone puntuación y puede fallar con nombres propios (corregilo en Subtítulos).\n• La elección de momentos NO es un modelo de lenguaje: se basa en señales reales (volumen, picos de voz, velocidad, palabras de emoción, risas, preguntas, pausas y cambios de tema). Los títulos son frases del propio clip.\n• La puntuación viral es una estimación por reglas, no una predicción medida.\n• El seguimiento de rostro sigue a la cara más grande; no sabe quién habla.\n• No se importa desde enlaces de YouTube: va contra sus términos de uso. Descargá tu propio video y subilo.", color = Pal.Muted)
                }
            }
        }
    }
}

@Composable
private fun SettingsTab() {
    val ctx = LocalContext.current
    val app = ctx.clipazos
    var res by remember { mutableStateOf(app.prefs.defaultRes) }
    var aspect by remember { mutableStateOf(app.prefs.defaultAspect) }
    val modelReady = remember { java.io.File(ctx.filesDir, "vosk/model-es-small-0.42/.ok").exists() }
    LazyColumn(Modifier.fillMaxSize().statusBarsPadding(), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { SectionTitle("Configuración") }
        item {
            Panel(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Motor de voz integrado", color = Pal.Cyan, fontWeight = FontWeight.Bold)
                    Text("Clipazos transcribe en español directamente en tu celular (Vosk, código abierto). No usa internet, no pide claves y es gratis.", color = Pal.Muted, fontSize = 13.sp)
                    if (modelReady) Pill("✓ Motor preparado", Pal.Ok) else Pill("Se prepara solo en el primer análisis", Pal.Violet)
                }
            }
        }
        item {
            Panel(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Exportación predeterminada", color = Pal.Cyan, fontWeight = FontWeight.Bold)
                    Label("FORMATO")
                    Chips(listOf("9:16" to "9:16", "16:9" to "16:9", "1:1" to "1:1"), aspect, { aspect = it; app.prefs.defaultAspect = it })
                    Label("CALIDAD")
                    Chips(listOf("720p" to "720p", "1080p" to "1080p", "4K" to "4K"), res, { res = it; app.prefs.defaultRes = it })
                }
            }
        }
        item { Text("Clipazos 1.0.0 · Idioma: español · Sin marca de agua · Sin internet", color = Pal.Muted, fontSize = 12.sp) }
    }
}
