package app.clipazos.edit

import app.clipazos.data.Caption
import app.clipazos.data.Segment
import app.clipazos.data.Transcript
import app.clipazos.data.Word

object CaptionBuilder {
    private val endMarks = ".!?¿¡…"

    private fun spread(seg: Segment): List<Word> {
        val parts = seg.text.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
        if (parts.isEmpty()) return emptyList()
        val total = parts.sumOf { it.length }.coerceAtLeast(1)
        var t = seg.s
        return parts.map { p ->
            val d = ((seg.e - seg.s) * p.length / total.toDouble()).toLong()
            Word(t, t + d, p).also { t += d }
        }
    }

    /** Agrupa las palabras con tiempos reales del transcrito en fragmentos cortos de subtítulo. */
    fun fromTranscript(t: Transcript, fromMs: Long, toMs: Long, maxWords: Int = 3): List<Caption> {
        val out = mutableListOf<Caption>()
        for (seg in t.segments) {
            if (seg.e < fromMs || seg.s > toMs) continue
            val words = (if (seg.words.isNotEmpty()) seg.words else spread(seg))
                .filter { it.w.isNotBlank() && it.s >= fromMs - 50 && it.e <= toMs + 50 }
            var cur = mutableListOf<Word>()
            for (w in words) {
                val brk = cur.isNotEmpty() && (cur.size >= maxWords || w.s - cur.last().e > 700 || cur.last().w.trim().lastOrNull()?.let { it in endMarks } == true)
                if (brk) { out += Caption(cur.first().s, cur.last().e, cur); cur = mutableListOf() }
                cur += w
            }
            if (cur.isNotEmpty()) out += Caption(cur.first().s, cur.last().e, cur)
        }
        return out
    }

    fun text(c: Caption): String = c.words.joinToString(" ") { it.w.trim() }

    /** Cambia el texto de un fragmento conservando la sincronización. */
    fun retext(c: Caption, newText: String): Caption {
        val parts = newText.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
        if (parts.isEmpty()) return c.copy(words = emptyList())
        if (parts.size == c.words.size) return c.copy(words = c.words.mapIndexed { i, w -> w.copy(w = parts[i]) })
        val total = parts.sumOf { it.length }.coerceAtLeast(1)
        var t = c.s
        val dur = (c.e - c.s).coerceAtLeast(parts.size * 120L)
        val ws = parts.map { p ->
            val d = dur * p.length / total
            Word(t, t + d, p).also { t += d }
        }
        return Caption(c.s, ws.last().e, ws)
    }
}
