package app.clipazos.edit

import app.clipazos.data.BoxSpec
import app.clipazos.data.EditSpec

/** Disposiciones de varios recuadros (ej. gameplay arriba + cámara abajo). Matemática pura, compartida por vista previa y exportación. */
object Layouts {
    val presets = listOf(
        "none" to "Uno solo", "stack2" to "2 arriba/abajo", "side2" to "2 lado a lado",
        "pip" to "Cámara redonda", "three" to "3 recuadros", "grid4" to "4 recuadros",
    )

    fun count(layout: String): Int = when (layout) { "stack2", "side2", "pip" -> 2; "three" -> 3; "grid4" -> 4; else -> 1 }

    fun defaultBoxes(layout: String): List<BoxSpec> = when (layout) {
        "stack2", "pip" -> listOf(BoxSpec(0.5f, 0.5f, 1f), BoxSpec(0.88f, 0.82f, 3.5f))   // juego + cámara (esquina inferior derecha)
        "side2" -> listOf(BoxSpec(0.3f, 0.5f, 1f), BoxSpec(0.7f, 0.5f, 1f))
        "three" -> listOf(BoxSpec(0.5f, 0.5f, 1f), BoxSpec(0.25f, 0.5f, 2f), BoxSpec(0.75f, 0.5f, 2f))
        "grid4" -> listOf(BoxSpec(0.25f, 0.25f, 2f), BoxSpec(0.75f, 0.25f, 2f), BoxSpec(0.25f, 0.75f, 2f), BoxSpec(0.75f, 0.75f, 2f))
        else -> listOf(BoxSpec())
    }

    fun boxesOf(spec: EditSpec): List<BoxSpec> =
        if (spec.boxes.size >= count(spec.boxLayout)) spec.boxes.take(count(spec.boxLayout)) else defaultBoxes(spec.boxLayout)

    /** x, y, ancho, alto de cada recuadro en fracciones de la pantalla de salida (origen arriba-izquierda). */
    fun dest(spec: EditSpec, outW: Int, outH: Int): List<FloatArray> {
        val s = spec.boxSplit.coerceIn(0.2f, 0.8f)
        return when (spec.boxLayout) {
            "stack2" -> listOf(floatArrayOf(0f, 0f, 1f, s), floatArrayOf(0f, s, 1f, 1f - s))
            "side2" -> listOf(floatArrayOf(0f, 0f, s, 1f), floatArrayOf(s, 0f, 1f - s, 1f))
            "pip" -> {
                val p = spec.pipSize.coerceIn(0.15f, 0.6f)
                val h = p * outW / outH
                val x = if (spec.pipCorner.endsWith("l")) 0.04f else 1f - p - 0.04f
                val y = if (spec.pipCorner.startsWith("t")) 0.05f else 1f - h - 0.12f
                listOf(floatArrayOf(0f, 0f, 1f, 1f), floatArrayOf(x, y, p, h))
            }
            "three" -> listOf(floatArrayOf(0f, 0f, 1f, s), floatArrayOf(0f, s, 0.5f, 1f - s), floatArrayOf(0.5f, s, 0.5f, 1f - s))
            "grid4" -> listOf(floatArrayOf(0f, 0f, .5f, .5f), floatArrayOf(.5f, 0f, .5f, .5f), floatArrayOf(0f, .5f, .5f, .5f), floatArrayOf(.5f, .5f, .5f, .5f))
            else -> listOf(floatArrayOf(0f, 0f, 1f, 1f))
        }
    }

    fun rounds(spec: EditSpec): List<Float> =
        if (spec.boxLayout == "pip") listOf(0f, if (spec.pipRound) 0.5f else 0.12f) else List(count(spec.boxLayout)) { 0f }

    /** Zona del video original (x, y, ancho, alto en fracciones, origen arriba-izquierda) que se muestra en un recuadro sin deformarse. */
    fun srcRect(b: BoxSpec, d: FloatArray, srcW: Int, srcH: Int, outW: Int, outH: Int): FloatArray {
        val ad = (d[2] * outW) / (d[3] * outH)
        val asrc = srcW.toFloat() / srcH
        var rw: Float
        var rh: Float
        if (ad <= asrc) { rw = ad / asrc; rh = 1f } else { rw = 1f; rh = asrc / ad }
        val z = b.zoom.coerceIn(1f, 8f)
        rw /= z; rh /= z
        val x = (b.cx - rw / 2f).coerceIn(0f, 1f - rw)
        val y = (b.cy - rh / 2f).coerceIn(0f, 1f - rh)
        return floatArrayOf(x, y, rw, rh)
    }
}
