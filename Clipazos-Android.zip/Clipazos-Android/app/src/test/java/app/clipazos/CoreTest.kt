package app.clipazos

import app.clipazos.data.Caption
import app.clipazos.data.Word
import app.clipazos.edit.CaptionBuilder
import app.clipazos.edit.Piece
import app.clipazos.edit.TimeMap
import app.clipazos.util.DurationCandidates
import app.clipazos.util.DurationReconciler
import app.clipazos.util.ExportSize
import app.clipazos.util.TimeFmt
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CoreTest {
    @Test fun formatoDeDuracion_1_5_10_20_60_minutos() {
        assertEquals("01:00", TimeFmt.format(60_000))
        assertEquals("05:00", TimeFmt.format(5 * 60_000L))
        assertEquals("10:00", TimeFmt.format(10 * 60_000L))
        assertEquals("20:00", TimeFmt.format(20 * 60_000L))
        assertEquals("1:00:00", TimeFmt.format(60 * 60_000L))
        assertEquals("00:08", TimeFmt.format(8_000))
    }

    @Test fun medicionRealConfirmaMetadatosCoherentes() {
        val c = DurationCandidates(1_200_000, 1_200_040, 1_199_990)
        val d = DurationReconciler.decide(c, null, 1_200_020)
        assertTrue(d.verified)
        assertEquals("20:00", TimeFmt.format(d.ms))
        assertNull(d.note)
    }

    @Test fun metadatoTruncadoDe8sSeCorrigeConLaLecturaReal() {
        // Caso del error original: el archivo dura 20 min pero la cabecera dice 8 s.
        val c = DurationCandidates(8_000, 8_000, 8_000)
        assertTrue(DurationReconciler.needsFullScan(c, 1_199_000))
        val d = DurationReconciler.decide(c, 1_199_000, 1_200_020)
        assertTrue(d.verified)
        assertEquals("20:00", TimeFmt.format(d.ms))
        assertNotNull(d.note)
    }

    @Test fun fuentesQueNoCoincidenObligaAEscaneo() {
        val c = DurationCandidates(600_000, 8_000, null)
        assertFalse(DurationReconciler.metadataConsistent(c))
        assertTrue(DurationReconciler.needsFullScan(c, 600_000))
    }

    @Test fun tamanosDeExportacion() {
        assertEquals(1080 to 1920, ExportSize.of("9:16", "1080p"))
        assertEquals(1280 to 720, ExportSize.of("16:9", "720p"))
        assertEquals(1080 to 1080, ExportSize.of("1:1", "1080p"))
        assertEquals(2160 to 3840, ExportSize.of("9:16", "4K"))
    }

    @Test fun mapaDeTiempoConVelocidad() {
        val tm = TimeMap(listOf(Piece(10_000, 70_000)), 1f)
        assertEquals(60_000, tm.outDurationMs)
        assertEquals(10_000, tm.sourceAt(0))
        val fast = TimeMap(listOf(Piece(10_000, 70_000)), 2f)
        assertEquals(30_000, fast.outDurationMs)
        assertEquals(40_000, fast.sourceAt(15_000))
    }

    @Test fun quitarSilenciosGeneraSaltos() {
        val words = listOf(Word(0, 500, "a"), Word(600, 1000, "b"), Word(4000, 4500, "c"), Word(4600, 5000, "d"))
        val tm = TimeMap.build(0, 5000, words, true, 1f)
        assertEquals(2, tm.pieces.size)
        assertTrue(tm.outDurationMs < 5000)
        assertNull(tm.outputAt(2000))
        assertNotNull(tm.outputAt(4100))
    }

    @Test fun corregirTextoConservaTiempos() {
        val c = Caption(0, 900, listOf(Word(0, 300, "hola"), Word(300, 600, "mundo"), Word(600, 900, "asi")))
        val r = CaptionBuilder.retext(c, "hola amigos tuyos")
        assertEquals(listOf(0L, 300L, 600L), r.words.map { it.s })
        assertEquals("amigos", r.words[1].w)
    }
}

class ClipScorerTest {
    private fun synthetic(): app.clipazos.data.Transcript {
        val segs = ArrayList<app.clipazos.data.Segment>()
        val energy = ArrayList<Int>()
        var t = 0L
        var i = 0
        while (t < 20 * 60_000L) {
            val d = 3_500L + (i % 4) * 500
            val hot = (i % 40 == 20) || (i % 40 == 21)
            val text = if (hot) "no puede ser increíble jajaja esto es una locura" else "hoy vamos a hablar de un tema normal número $i"
            val words = text.split(" ").mapIndexed { k, w -> Word(t + k * d / 10, t + (k + 1) * d / 10 - 20, w) }
            segs += app.clipazos.data.Segment(t, t + d, text, words)
            val level = if (hot) 160 else 50
            for (k in 0 until (d / 100).toInt()) energy += level
            val gap = 400L
            for (k in 0 until (gap / 100).toInt()) energy += 3
            t += d + gap; i++
        }
        return app.clipazos.data.Transcript(segs, energy)
    }

    @Test fun eligeClipsValidosSinSolapes() {
        val plans = app.clipazos.ai.ClipScorer.plan(synthetic(), 20 * 60_000L, 5)
        assertEquals(5, plans.size)
        plans.forEach { p ->
            val d = p.endMs - p.startMs
            assertTrue("duración fuera de rango: $d", d in 29_000..81_000)
            assertTrue(p.title.isNotBlank())
        }
        for (a in plans.indices) for (b in a + 1 until plans.size) {
            val ov = maxOf(0L, minOf(plans[a].endMs, plans[b].endMs) - maxOf(plans[a].startMs, plans[b].startMs))
            assertTrue("clips solapados", ov < 0.25 * (plans[a].endMs - plans[a].startMs))
        }
    }

    @Test fun losMomentosEmocionantesSePrefieren() {
        val plans = app.clipazos.ai.ClipScorer.plan(synthetic(), 20 * 60_000L, 3)
        assertTrue(plans.all { it.category == "divertido" || it.category == "emocionante" || it.category == "inesperado" })
    }

    @Test fun pideMasClipsDeLosQueCaben() {
        val short = app.clipazos.data.Transcript(synthetic().segments.take(25), synthetic().energy.take(400))
        val plans = app.clipazos.ai.ClipScorer.plan(short, 100_000L, 15)
        assertTrue(plans.size < 15)
    }
}

class LayoutsTest {
    private fun spec(layout: String) = app.clipazos.data.EditSpec(0, 60_000, boxLayout = layout)

    @Test fun cantidadDeRecuadros() {
        assertEquals(2, app.clipazos.edit.Layouts.count("stack2"))
        assertEquals(3, app.clipazos.edit.Layouts.count("three"))
        assertEquals(4, app.clipazos.edit.Layouts.count("grid4"))
        assertEquals(1, app.clipazos.edit.Layouts.count("none"))
    }

    @Test fun juegoArribaYCamaraAbajoSinDeformar() {
        val s = spec("stack2")
        val dst = app.clipazos.edit.Layouts.dest(s, 1080, 1920, 16f / 9f)
        val boxes = app.clipazos.edit.Layouts.boxesOf(s)
        assertEquals(2, dst.size)
        for (i in dst.indices) {
            val r = app.clipazos.edit.Layouts.srcRect(boxes[i], dst[i], 1920, 1080, 1080, 1920)
            // la proporción en píxeles del recorte debe ser igual a la de la zona de destino
            val srcAspect = (r[2] * 1920) / (r[3] * 1080)
            val dstAspect = (dst[i][2] * 1080) / (dst[i][3] * 1920)
            assertEquals(dstAspect.toDouble(), srcAspect.toDouble(), 0.01)
            assertTrue(r[0] >= 0f && r[1] >= 0f && r[0] + r[2] <= 1.001f && r[1] + r[3] <= 1.001f)
        }
    }

    @Test fun camaraRedondaEsCuadrada() {
        val dst = app.clipazos.edit.Layouts.dest(spec("pip"), 1080, 1920, 16f / 9f)
        assertEquals(dst[1][2] * 1080, dst[1][3] * 1920, 1f)
    }

    @Test fun gameplayEs30_70() {
        val s = app.clipazos.edit.Layouts.applyPreset(spec("none"), "gameplay")
        val d = app.clipazos.edit.Layouts.dest(s, 1080, 1920, 16f / 9f)
        assertEquals(0.3f, d[0][3], 0.001f)
        assertEquals(0.7f, d[1][3], 0.001f)
    }

    @Test fun intercambiarOrdenDeRecuadros() {
        val b = app.clipazos.edit.Layouts.defaultBoxes("stack2")
        val sw = app.clipazos.edit.Layouts.swap(b, 0, 1)
        assertEquals(b[0], sw[1])
        assertEquals(b[1], sw[0])
    }

    @Test fun ajustarRostroCentraYHaceZoom() {
        val face = floatArrayOf(0.8f, 0.7f, 0.1f, 0.18f)
        val d = floatArrayOf(0f, 0f, 1f, 0.3f)
        val b = app.clipazos.edit.Layouts.fitFace(face, d, 1920, 1080, 1080, 1920)
        assertEquals(0.85f, b.cx, 0.001f)
        assertEquals(0.79f, b.cy, 0.001f)
        assertTrue(b.zoom > 1f)
    }
}

class NalTest {
    @Test fun detectaFotogramasClave() {
        val idr = byteArrayOf(0, 0, 0, 2, 0x65, 0x88.toByte())
        val p = byteArrayOf(0, 0, 0, 2, 0x41, 0x9a.toByte())
        val annexB = byteArrayOf(0, 0, 0, 1, 0x65, 0x88.toByte(), 0x11)
        val hevcIdr = byteArrayOf(0, 0, 0, 3, 0x26, 0x01, 0x00)
        assertEquals(true, app.clipazos.media.Nal.isKeyFrame("video/avc", idr, idr.size))
        assertEquals(false, app.clipazos.media.Nal.isKeyFrame("video/avc", p, p.size))
        assertEquals(true, app.clipazos.media.Nal.isKeyFrame("video/avc", annexB, annexB.size))
        assertEquals(true, app.clipazos.media.Nal.isKeyFrame("video/hevc", hevcIdr, hevcIdr.size))
    }
}
