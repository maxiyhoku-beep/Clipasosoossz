package app.clipazos.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.serialization.encodeToString
import kotlinx.serialization.decodeFromString
import java.io.File

/** Persistencia en JSON dentro del almacenamiento privado de la app. Todo se guarda al instante. */
class Store(private val ctx: Context) {
    private val root = File(ctx.filesDir, "projects").apply { mkdirs() }
    private val exportsFile = File(ctx.filesDir, "exports.json")

    val projects = MutableStateFlow<List<Project>>(emptyList())
    val clips = MutableStateFlow<Map<String, List<Clip>>>(emptyMap())
    val exports = MutableStateFlow<List<ExportRecord>>(emptyList())

    init { load() }

    private fun atomicWrite(f: File, text: String) {
        f.parentFile?.mkdirs()
        val tmp = File(f.parentFile, f.name + ".tmp")
        tmp.writeText(text)
        if (!tmp.renameTo(f)) { f.writeText(text); tmp.delete() }
    }

    @Synchronized private fun load() {
        val ps = root.listFiles().orEmpty().filter { it.isDirectory }.mapNotNull { d ->
            runCatching { AppJson.decodeFromString<Project>(File(d, "project.json").readText()) }.getOrNull()
        }.sortedByDescending { it.createdAt }
        projects.value = ps
        clips.value = ps.associate { it.id to readClips(it.id) }
        exports.value = runCatching { AppJson.decodeFromString<List<ExportRecord>>(exportsFile.readText()) }.getOrDefault(emptyList())
    }

    fun dir(id: String): File = File(root, id).apply { mkdirs() }

    private fun readClips(id: String): List<Clip> =
        runCatching { AppJson.decodeFromString<List<Clip>>(File(dir(id), "clips.json").readText()) }.getOrDefault(emptyList())

    fun project(id: String): Project? = projects.value.firstOrNull { it.id == id }
    fun clipsOf(projectId: String): List<Clip> = clips.value[projectId].orEmpty()
    fun clip(id: String): Clip? = clips.value.values.firstNotNullOfOrNull { l -> l.firstOrNull { it.id == id } }

    @Synchronized fun saveProject(p: Project) {
        atomicWrite(File(dir(p.id), "project.json"), AppJson.encodeToString(p))
        projects.value = (projects.value.filter { it.id != p.id } + p).sortedByDescending { it.createdAt }
    }

    @Synchronized fun updateProject(id: String, f: (Project) -> Project) {
        project(id)?.let { saveProject(f(it)) }
    }

    @Synchronized fun saveClips(projectId: String, list: List<Clip>) {
        atomicWrite(File(dir(projectId), "clips.json"), AppJson.encodeToString(list))
        clips.value = clips.value + (projectId to list)
    }

    @Synchronized fun updateClip(clip: Clip) {
        val l = clipsOf(clip.projectId).map { if (it.id == clip.id) clip else it }
        saveClips(clip.projectId, l)
    }

    @Synchronized fun saveTranscript(projectId: String, t: Transcript) =
        atomicWrite(File(dir(projectId), "transcript.json"), AppJson.encodeToString(t))

    fun transcript(projectId: String): Transcript? =
        runCatching { AppJson.decodeFromString<Transcript>(File(dir(projectId), "transcript.json").readText()) }.getOrNull()

    @Synchronized fun addExport(r: ExportRecord) {
        exports.value = listOf(r) + exports.value
        atomicWrite(exportsFile, AppJson.encodeToString(exports.value))
    }

    @Synchronized fun removeExport(id: String) {
        exports.value = exports.value.filter { it.id != id }
        atomicWrite(exportsFile, AppJson.encodeToString(exports.value))
    }

    @Synchronized fun deleteProject(id: String) {
        dir(id).deleteRecursively()
        projects.value = projects.value.filter { it.id != id }
        clips.value = clips.value - id
    }
}
