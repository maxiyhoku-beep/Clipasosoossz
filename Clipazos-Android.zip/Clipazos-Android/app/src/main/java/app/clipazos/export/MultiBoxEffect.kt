package app.clipazos.export

import android.content.Context
import android.opengl.GLES20
import androidx.media3.common.util.Size
import androidx.media3.common.VideoFrameProcessingException
import androidx.media3.common.util.GlProgram
import androidx.media3.common.util.GlUtil
import androidx.media3.effect.BaseGlShaderProgram
import androidx.media3.effect.GlEffect
import androidx.media3.effect.GlShaderProgram

/**
 * Dibuja hasta 4 recuadros del MISMO video en una sola pasada (un solo decodificador):
 * cada recuadro toma una zona del original (src) y la coloca en una zona de la pantalla (dst), con esquinas redondeadas opcionales.
 * Se usa igual en la vista previa (ExoPlayer.setVideoEffects) y en la exportación.
 */
class MultiBoxEffect(
    private val dst: List<FloatArray>,
    private val srcFor: (Int, Int) -> List<FloatArray>,
    private val round: List<Float>,
    private val modes: List<Float>,
    private val outW: Int,
    private val outH: Int,
) : GlEffect {
    override fun toGlShaderProgram(context: Context, useHdr: Boolean): GlShaderProgram =
        MultiBoxProgram(useHdr, dst, srcFor, round, modes, outW, outH)
}

private const val VERTEX = """
attribute vec4 aFramePosition;
varying vec2 vTexSamplingCoord;
void main() {
  gl_Position = aFramePosition;
  vTexSamplingCoord = vec2(aFramePosition.x * 0.5 + 0.5, aFramePosition.y * 0.5 + 0.5);
}
"""

private const val FRAGMENT = """
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
uniform sampler2D uTexSampler;
uniform vec4 uDst0; uniform vec4 uDst1; uniform vec4 uDst2; uniform vec4 uDst3;
uniform vec4 uSrc0; uniform vec4 uSrc1; uniform vec4 uSrc2; uniform vec4 uSrc3;
uniform vec4 uRound;
uniform vec4 uMode;
uniform vec2 uOutSize;
varying vec2 vTexSamplingCoord;

vec4 tex(vec2 uvTop) { return texture2D(uTexSampler, vec2(uvTop.x, 1.0 - uvTop.y)); }

vec4 box(vec2 p, vec4 d, vec4 s, float r, float mode, vec4 prev) {
  if (d.z <= 0.0 || p.x < d.x || p.x > d.x + d.z || p.y < d.y || p.y > d.y + d.w) return prev;
  vec2 local = (p - d.xy) / d.zw;
  if (r > 0.0) {
    vec2 sz = d.zw * uOutSize;
    float rad = r * min(sz.x, sz.y);
    vec2 q = abs(local * sz - sz * 0.5) - (sz * 0.5 - vec2(rad));
    if (length(max(q, 0.0)) > rad) return prev;
  }
  vec2 uvTop = s.xy + local * s.zw;
  if (mode > 0.5) {
    vec4 acc = vec4(0.0);
    for (int i = 0; i < 12; i++) {
      float fi = float(i);
      float ang = fi * 2.3999632;
      float rad = 0.04 * sqrt((fi + 0.5) / 12.0);
      acc += tex(clamp(uvTop + vec2(cos(ang), sin(ang)) * rad, 0.0, 1.0));
    }
    return vec4((acc / 12.0).rgb * 0.55, 1.0);
  }
  return tex(uvTop);
}

void main() {
  vec2 p = vec2(vTexSamplingCoord.x, 1.0 - vTexSamplingCoord.y);
  vec4 c = vec4(0.0, 0.0, 0.0, 1.0);
  c = box(p, uDst0, uSrc0, uRound.x, uMode.x, c);
  c = box(p, uDst1, uSrc1, uRound.y, uMode.y, c);
  c = box(p, uDst2, uSrc2, uRound.z, uMode.z, c);
  c = box(p, uDst3, uSrc3, uRound.w, uMode.w, c);
  gl_FragColor = c;
}
"""

private class MultiBoxProgram(
    useHdr: Boolean,
    private val dst: List<FloatArray>,
    private val srcFor: (Int, Int) -> List<FloatArray>,
    private val round: List<Float>,
    private val modes: List<Float>,
    private val outW: Int,
    private val outH: Int,
) : BaseGlShaderProgram(useHdr, 1) {
    private val program: GlProgram
    private var src: List<FloatArray> = emptyList()

    init {
        try {
            program = GlProgram(VERTEX, FRAGMENT)
            program.setBufferAttribute("aFramePosition", GlUtil.getNormalizedCoordinateBounds(), GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE)
        } catch (e: Exception) {
            throw VideoFrameProcessingException(e)
        }
    }

    override fun configure(inputWidth: Int, inputHeight: Int): Size {
        src = srcFor(inputWidth, inputHeight)
        return Size(outW, outH)
    }

    override fun drawFrame(inputTexId: Int, presentationTimeUs: Long) {
        try {
            program.use()
            program.setSamplerTexIdUniform("uTexSampler", inputTexId, 0)
            for (i in 0 until 4) {
                program.setFloatsUniform("uDst$i", dst.getOrNull(i) ?: floatArrayOf(0f, 0f, 0f, 0f))
                program.setFloatsUniform("uSrc$i", src.getOrNull(i) ?: floatArrayOf(0f, 0f, 1f, 1f))
            }
            program.setFloatsUniform("uRound", FloatArray(4) { round.getOrElse(it) { 0f } })
            program.setFloatsUniform("uMode", FloatArray(4) { modes.getOrElse(it) { 0f } })
            program.setFloatsUniform("uOutSize", floatArrayOf(outW.toFloat(), outH.toFloat()))
            program.bindAttributesAndUniforms()
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
            GlUtil.checkGlError()
        } catch (e: Exception) {
            throw VideoFrameProcessingException(e)
        }
    }

    override fun release() {
        super.release()
        try { program.delete() } catch (e: Exception) { throw VideoFrameProcessingException(e) }
    }
}
