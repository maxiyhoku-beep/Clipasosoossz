package app.clipazos.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import app.clipazos.clipazos
import app.clipazos.data.Clip
import app.clipazos.data.ProjectStatus
import app.clipazos.util.TimeFmt
import app.clipazos.work.AnalyzeWorker

fun categoryLabel(c: String) = when (c) {
    "divertido" -> "divertido 😂"; "reaccion" -> "reacción 😮"; "discusion" -> "discusión 🗣️"
    "emocionante" -> "emocionante ⚡"; "frase" -> "frase interesante 💬"; "inesperado" -> "inesperado 🤯"
    "historia" -> "historia 📖"; else -> "potencial viral 🔥"
}

@Composable
fun ProjectScreen(nav: NavHostController, id: String) {
    val ctx = LocalContext.current
    val app = ctx.clipazos
    val projects by app.store.projects.collectAsState()
    val allClips by app.store.clips.collectAsState()
    val p = projects.firstOrNull { it.id == id }
    if (p == null) { LaunchedEffect(Unit) { nav.popBackStack() }; return }

    var count by remember { mutableIntStateOf(p.clipTarget) }
    var customDialog by remember { mutableStateOf(false) }
    var customText by remember { mutableStateOf("") }
    var byScore by remember { mutableStateOf(true) }
    var exportIds by remember { mutableStateOf<List<String>?>(null) }
    var previewClip by remember { mutableStateOf<Clip?>(null) }
    val selected = remember { mutableStateListOf<String>() }
    val clips: List<Clip> = allClips[id].orEmpty().let { l -> if (byScore) l.sortedByDescending { it.score } else l.sortedBy { it.startMs } }

    fun analyze() {
        app.store.updateProject(p.id) { it.copy(status = ProjectStatus.ANALYZING, clipTarget = count, stage = "En cola…", progress = 0f, error = null) }
        val req = OneTimeWorkRequestBuilder<AnalyzeWorker>().setInputData(workDataOf("id" to p.id)).build()
        WorkManager.getInstance(ctx).enqueueUniqueWork("analyze_${p.id}", ExistingWorkPolicy.REPLACE, req)
    }

    Backdrop {
        LazyColumn(Modifier.fillMaxSize().statusBarsPadding(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.Rounded.ArrowBack, "Volver", tint = Pal.Text) }
                    Text(p.name, color = Pal.Text, fontWeight = FontWeight.Bold, fontSize = 18.sp, maxLines = 1, modifier = Modifier.weight(1f))
                }
            }
            item {
                Panel(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("DURACIÓN: ${TimeFmt.format(p.durationMs)}", color = Pal.Cyan, fontSize = 30.sp, fontWeight = FontWeight.Black)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (p.verified) Pill("✓ Duración verificada", Pal.Ok) else Pill("⚠ Sin confirmar", Pal.Warn)
                            Pill("${p.width}×${p.height}", Pal.Violet)
                            if (p.sizeBytes > 0) Pill("${p.sizeBytes / 1_048_576} MB", Pal.Blue)
                        }
                        Text("Medida en milisegundos: ${p.durationMs} ms", color = Pal.Muted, fontSize = 12.sp)
                        p.note?.let { Text(it, color = Pal.Warn, fontSize = 13.sp) }
                    }
                }
            }
            when (p.status) {
                ProjectStatus.IMPORTED, ProjectStatus.ERROR -> {
                    if (p.status == ProjectStatus.ERROR) item {
                        Panel(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) {
                            Text("El análisis no terminó", color = Pal.Danger, fontWeight = FontWeight.Bold)
                            Text(p.error ?: "Error desconocido", color = Pal.Text, modifier = Modifier.padding(top = 4.dp))
                        } }
                    }
                    item {
                        Panel(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(16.dp)) {
                                Text("¿Cuántos clips querés?", color = Pal.Text, fontWeight = FontWeight.Bold)
                                Label("CANTIDAD")
                                val preset = listOf(3, 5, 10, 15)
                                Chips(preset.map { it to "$it" } + (0 to if (count !in preset) "$count (otro)" else "Personalizado"), if (count in preset) count else 0, {
                                    if (it == 0) customDialog = true else count = it
                                })
                                Text("Duración de cada clip: 30 s a 1:20. Todo se analiza en tu celular, sin internet. Evita cortar frases y clips repetidos.", color = Pal.Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp))
                            }
                        }
                    }
                    item { GradientButton(if (p.status == ProjectStatus.ERROR) "REINTENTAR ANÁLISIS" else "ANALIZAR", { analyze() }, Modifier.fillMaxWidth(), icon = Icons.Rounded.AutoAwesome, height = 62.dp) }
                }
                ProjectStatus.ANALYZING -> item {
                    Panel(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text(p.stage.ifBlank { "Analizando…" }, color = Pal.Text, fontWeight = FontWeight.Bold)
                            LinearProgressIndicator(progress = { p.progress }, modifier = Modifier.fillMaxWidth().height(8.dp), color = Pal.Cyan, trackColor = Pal.Surface2)
                            Text("${(p.progress * 100).toInt()} %  ·  Podés salir de la app: el análisis sigue en segundo plano.", color = Pal.Muted, fontSize = 13.sp)
                            GhostButton("Cancelar análisis", {
                                WorkManager.getInstance(ctx).cancelUniqueWork("analyze_${p.id}")
                                app.store.updateProject(p.id) { it.copy(status = ProjectStatus.IMPORTED, stage = "Cancelado", progress = 0f) }
                            }, danger = true)
                        }
                    }
                }
                ProjectStatus.DONE -> {
                    item {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("${clips.size} clips encontrados", color = Pal.Text, fontWeight = FontWeight.Black, fontSize = 20.sp)
                                if (clips.size < p.clipTarget) Text("Pediste ${p.clipTarget}: el video no tiene más momentos que cumplan 30 s – 1:20 sin repetirse.", color = Pal.Muted, fontSize = 12.sp)
                            }
                        }
                    }
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Chips(listOf(true to "Por puntuación", false to "Por posición"), byScore, { byScore = it })
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                GradientButton("Exportar todos", { exportIds = clips.map { it.id } }, Modifier.weight(1f), icon = Icons.Rounded.Download, height = 48.dp)
                                if (selected.isNotEmpty()) GhostButton("Seleccionados (${selected.size})", { exportIds = selected.toList() })
                            }
                            GhostButton("Volver a analizar", { app.store.updateProject(p.id) { it.copy(status = ProjectStatus.IMPORTED) } })
                        }
                    }
                    items(clips, key = { it.id }) { c ->
                        Panel(Modifier.fillMaxWidth(), onClick = { nav.navigate("editor/${c.id}") }) {
                            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
                                ClipThumb(p, c, Modifier.width(78.dp).height(124.dp)) { previewClip = c }
                                Spacer(Modifier.width(10.dp))
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    ScoreBadge(c.score)
                                    Text("viral", color = Pal.Muted, fontSize = 10.sp)
                                }
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text(c.title, color = Pal.Text, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 2)
                                    if (c.description.isNotBlank()) Text(c.description, color = Pal.Muted, fontSize = 13.sp, maxLines = 3)
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Pill(TimeFmt.format(c.endMs - c.startMs), Pal.Cyan)
                                        Pill("${TimeFmt.format(c.startMs)}–${TimeFmt.format(c.endMs)}", Pal.Violet)
                                    }
                                    Text(categoryLabel(c.category), color = Pal.Turq, fontSize = 12.sp)
                                    if (c.exportedUri != null) Text("✓ Exportado", color = Pal.Ok, fontSize = 12.sp)
                                }
                                Checkbox(checked = c.id in selected, onCheckedChange = { if (it) selected.add(c.id) else selected.remove(c.id) },
                                    colors = CheckboxDefaults.colors(checkedColor = Pal.Blue, uncheckedColor = Pal.Muted))
                            }
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
        if (customDialog) AlertDialog(
            onDismissRequest = { customDialog = false }, containerColor = Pal.Surface,
            title = { Text("Cantidad personalizada", color = Pal.Text) },
            text = { OutlinedTextField(value = customText, onValueChange = { customText = it.filter(Char::isDigit).take(2) }, singleLine = true, placeholder = { Text("Entre 1 y 30") }) },
            confirmButton = { TextButton(onClick = { customText.toIntOrNull()?.let { count = it.coerceIn(1, 30) }; customDialog = false }) { Text("OK", color = Pal.Cyan) } },
            dismissButton = { TextButton(onClick = { customDialog = false }) { Text("Cancelar", color = Pal.Muted) } },
        )
        exportIds?.let { ids -> ExportDialog(ids) { exportIds = null } }
        previewClip?.let { c -> ClipPreviewDialog(p, c, onEdit = { previewClip = null; nav.navigate("editor/${c.id}") }, onDismiss = { previewClip = null }) }
        ExportProgressHost()
    }
}
