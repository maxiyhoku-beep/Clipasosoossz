package app.clipazos.media

import android.content.Context
import android.media.MediaCodecList
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import app.clipazos.util.DurationCandidates
import app.clipazos.util.DurationReconciler
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class ProbeException(message: String) : Exception(message)

data class VideoInfo(
    val name: String,
    val sizeBytes: Long,
    val durationMs: Long,
    val width: Int,          // dimensiones de pantalla (ya con la rotación aplicada)
    val height: Int,
    val rotation: Int,
    val fps: Float,
    val videoMime: String,
    val audioMime: String?,
    val audioBitrate: Int,
    val hasAudio: Boolean,
    val verified: Boolean,
    val note: String?,
)

/**
 * Lectura de metadatos y duración REAL en milisegundos, compatible con Storage Access Framework (content://).
 * Fuentes: MediaMetadataRetriever + duración de cada pista (MediaExtractor) + comprobación contra la última
 * muestra real del archivo. Si no coinciden, se recorre el contenido y se usa la duración medida.
 */
object VideoProbe {

    suspend fun probe(ctx: Context, uri: Uri): VideoInfo = withContext(Dispatchers.IO) {
        val (name, size) = queryNameSize(ctx, uri)

        var retrieverMs: Long? = null
        var rotation = 0
        var rw = 0
        var rh = 0
        val mmr = MediaMetadataRetriever()
        try {
            mmr.setDataSource(ctx, uri)
            retrieverMs = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
            rotation = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            rw = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            rh = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
        } catch (_: Exception) {
            // seguimos con MediaExtractor
        } finally {
            runCatching { mmr.release() }
        }

        val ex = MediaExtractor()
        try {
            try {
                ex.setDataSource(ctx, uri, null)
            } catch (e: Exception) {
                throw ProbeException("No se pudo abrir el video (${e.message ?: "formato no compatible"}). Probá con otro archivo.")
            }

            var vIdx = -1
            var aIdx = -1
            var vFmt: MediaFormat? = null
            var aFmt: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("video/") && vIdx < 0) { vIdx = i; vFmt = f }
                else if (mime.startsWith("audio/") && aIdx < 0) { aIdx = i; aFmt = f }
            }
            if (vIdx < 0 || vFmt == null) throw ProbeException("El archivo no contiene una pista de video.")
            val vf: MediaFormat = vFmt

            val vMime = vf.getString(MediaFormat.KEY_MIME) ?: "video/?"
            val decoder = runCatching { MediaCodecList(MediaCodecList.REGULAR_CODECS).findDecoderForFormat(vf) }.getOrNull()
            if (decoder == null) throw ProbeException("Este celular no puede decodificar el video (códec $vMime).")

            if (rotation == 0 && vf.containsKey(MediaFormat.KEY_ROTATION)) rotation = vf.getInteger(MediaFormat.KEY_ROTATION)
            var w = if (vf.containsKey(MediaFormat.KEY_WIDTH)) vf.getInteger(MediaFormat.KEY_WIDTH) else rw
            var h = if (vf.containsKey(MediaFormat.KEY_HEIGHT)) vf.getInteger(MediaFormat.KEY_HEIGHT) else rh
            if (rotation == 90 || rotation == 270) { val t = w; w = h; h = t }
            if (w <= 0 || h <= 0) throw ProbeException("No se pudo leer el tamaño del video.")

            fun trackMs(f: MediaFormat?): Long? =
                if (f != null && f.containsKey(MediaFormat.KEY_DURATION)) f.getLong(MediaFormat.KEY_DURATION) / 1000L else null

            val cand = DurationCandidates(retrieverMs, trackMs(vf), trackMs(aFmt))

            // Siempre se mide recorriendo TODAS las muestras de cada pista (sin decodificar). El "salto al final" no es fiable
            // en archivos fragmentados (grabadores de pantalla/stream): solo ven lo que ya leyeron y confirman una duración falsa.
            var scanMs: Long? = null
            var best = 0L
            for (idx in listOf(vIdx, aIdx).filter { it >= 0 }) {
                val sc = fullScanEndUs(ex, idx)
                if (sc > best) best = sc
            }
            if (best > 0) scanMs = best / 1000L

            val decision = DurationReconciler.decide(cand, null, scanMs)
            if (decision.ms <= 0) throw ProbeException(decision.note ?: "No se pudo leer la duración.")

            val fps = runCatching { vf.getInteger(MediaFormat.KEY_FRAME_RATE).toFloat() }
                .recoverCatching { vf.getFloat(MediaFormat.KEY_FRAME_RATE) }.getOrDefault(30f)
            val aBitrate = if (aFmt != null && aFmt.containsKey(MediaFormat.KEY_BIT_RATE)) aFmt.getInteger(MediaFormat.KEY_BIT_RATE) else 0

            VideoInfo(
                name = name, sizeBytes = size, durationMs = decision.ms, width = w, height = h,
                rotation = rotation, fps = fps, videoMime = vMime, audioMime = aFmt?.getString(MediaFormat.KEY_MIME),
                audioBitrate = aBitrate, hasAudio = aIdx >= 0, verified = decision.verified, note = decision.note,
            )
        } finally {
            runCatching { ex.release() }
        }
    }

    /** Salta al final del archivo y recorre las últimas muestras. Devuelve null si el contenedor no lo permite. */
    private fun quickEndUs(ex: MediaExtractor, idx: Int): Long? {
        ex.selectTrack(idx)
        return try {
            ex.seekTo(Long.MAX_VALUE / 4, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
            var last = -1L
            var guard = 0
            while (guard++ < 200_000) {
                val t = ex.sampleTime
                if (t < 0) break
                last = t
                if (!ex.advance()) break
            }
            if (last > 0) last else null
        } catch (_: Exception) { null } finally { ex.unselectTrack(idx) }
    }

    /** Recorre TODAS las muestras de la pista (sin decodificar) y devuelve fin = última muestra + intervalo medio. */
    private fun fullScanEndUs(ex: MediaExtractor, idx: Int): Long {
        ex.selectTrack(idx)
        return try {
            ex.seekTo(0, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
            var last = 0L
            var count = 0L
            while (true) {
                val t = ex.sampleTime
                if (t < 0) break
                last = t
                count++
                if (!ex.advance()) break
            }
            if (count <= 1) last else last + last / (count - 1)
        } catch (_: Exception) { 0L } finally { ex.unselectTrack(idx) }
    }

    private fun queryNameSize(ctx: Context, uri: Uri): Pair<String, Long> {
        var name = uri.lastPathSegment ?: "video"
        var size = 0L
        runCatching {
            ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val si = c.getColumnIndex(OpenableColumns.SIZE)
                    if (ni >= 0) name = c.getString(ni) ?: name
                    if (si >= 0) size = c.getLong(si)
                }
            }
        }
        return name to size
    }
}
