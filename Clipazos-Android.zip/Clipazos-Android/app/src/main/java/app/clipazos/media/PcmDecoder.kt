package app.clipazos.media

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.nio.ByteOrder

/**
 * Decodifica la pista de audio de cualquier video (SAF incluido) y la entrega como PCM de 16 kHz, mono, 16 bits
 * (lo que necesita el reconocedor de voz). Todo en el dispositivo, sin internet.
 */
object PcmDecoder {
    const val OUT_RATE = 16000

    /** onPcm(buffer, cantidadDeMuestras) -> seguir?. Bloques de 16000 muestras (1 s). Decodifica de startMs a endMs. */
    fun decode(ctx: Context, uri: Uri, startMs: Long, endMs: Long, isCancelled: () -> Boolean, onPcm: (ShortArray, Int) -> Boolean) {
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            ex.setDataSource(ctx, uri, null)
            var track = -1
            var fmt: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if ((f.getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) { track = i; fmt = f; break }
            }
            if (track < 0 || fmt == null) throw IllegalStateException("El video no tiene pista de audio.")
            val format: MediaFormat = fmt
            ex.selectTrack(track)
            if (startMs > 0) ex.seekTo(startMs * 1000L, MediaExtractor.SEEK_TO_CLOSEST_SYNC)

            val mime = format.getString(MediaFormat.KEY_MIME)!!
            val c = try {
                MediaCodec.createDecoderByType(mime).also { it.configure(format, null, null, 0); it.start() }
            } catch (e: Exception) {
                throw IllegalStateException("Este celular no puede decodificar el audio ($mime).")
            }
            codec = c

            var rate = if (format.containsKey(MediaFormat.KEY_SAMPLE_RATE)) format.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 44100
            var ch = if (format.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) format.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 2
            var isFloat = false

            val info = MediaCodec.BufferInfo()
            var inDone = false
            var outDone = false
            val out = ShortArray(OUT_RATE)
            var outN = 0
            var acc = 0.0
            var cnt = 0
            var phase = 0L
            var stop = false
            var emitted = 0L

            fun emit(v: Double) {
                out[outN++] = v.toInt().coerceIn(-32768, 32767).toShort()
                if (outN == out.size) {
                    emitted += outN
                    if (!onPcm(out, outN)) stop = true
                    if (startMs + emitted * 1000L / OUT_RATE >= endMs) stop = true
                    outN = 0
                }
            }
            fun feed(sample: Double) {
                acc += sample; cnt++
                phase += OUT_RATE
                if (phase >= rate) { phase -= rate; emit(acc / cnt); acc = 0.0; cnt = 0 }
            }

            while (!outDone && !stop) {
                if (isCancelled()) break
                if (!inDone) {
                    val ii = c.dequeueInputBuffer(10_000)
                    if (ii >= 0) {
                        val b = c.getInputBuffer(ii)!!
                        val n = ex.readSampleData(b, 0)
                        if (n < 0) { c.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true }
                        else { c.queueInputBuffer(ii, 0, n, ex.sampleTime, 0); ex.advance() }
                    }
                }
                val oi = c.dequeueOutputBuffer(info, 10_000)
                when {
                    oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val f = c.outputFormat
                        if (f.containsKey(MediaFormat.KEY_SAMPLE_RATE)) rate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        if (f.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) ch = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        isFloat = f.containsKey(MediaFormat.KEY_PCM_ENCODING) && f.getInteger(MediaFormat.KEY_PCM_ENCODING) == android.media.AudioFormat.ENCODING_PCM_FLOAT
                    }
                    oi >= 0 -> {
                        val b = c.getOutputBuffer(oi)!!
                        b.position(info.offset); b.limit(info.offset + info.size); b.order(ByteOrder.nativeOrder())
                        if (info.size > 0 && ch > 0) {
                            if (isFloat) {
                                val fb = b.asFloatBuffer()
                                while (fb.remaining() >= ch) { var s = 0.0; for (k in 0 until ch) s += fb.get() * 32767.0; feed(s / ch) }
                            } else {
                                val sb = b.asShortBuffer()
                                while (sb.remaining() >= ch) { var s = 0.0; for (k in 0 until ch) s += sb.get(); feed(s / ch) }
                            }
                        }
                        c.releaseOutputBuffer(oi, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                    }
                }
            }
            if (outN > 0 && !isCancelled() && !stop) onPcm(out, outN)
        } finally {
            runCatching { codec?.stop() }
            runCatching { codec?.release() }
            runCatching { ex.release() }
        }
    }
}
