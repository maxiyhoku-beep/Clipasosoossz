package app.clipazos.work

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import androidx.core.app.NotificationCompat

object Notifs {
    const val CH = "clipazos_work"

    fun createChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Procesos de Clipazos", NotificationManager.IMPORTANCE_LOW))
    }

    fun build(ctx: Context, title: String, text: String, pct: Int, cancel: PendingIntent?): Notification {
        val b = NotificationCompat.Builder(ctx, CH)
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle(title)
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setProgress(100, pct.coerceIn(0, 100), pct <= 0)
        if (cancel != null) b.addAction(android.R.drawable.ic_menu_close_clear_cancel, "Cancelar", cancel)
        return b.build()
    }
}
