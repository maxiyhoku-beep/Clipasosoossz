package app.clipazos.edit

import app.clipazos.data.Caption
import app.clipazos.data.EditSpec
import app.clipazos.util.easeOut
import app.clipazos.util.easeOutBack
import kotlin.math.max

/**
 * Matemática compartida entre la vista previa y la exportación (WYSIWYG):
 * zoom automático/manual, transición de zoom y reencuadre horizontal (seguimiento de rostro o manual).
 * Salida: (zoom, centroX, centroY) en coordenadas NDC del fotograma "natural" (relación de aspecto del original).
 */
class Reframe(
    private val spec: EditSpec,
    private val timeMap: TimeMap,
    srcW: Int, srcH: Int, outW: Int, outH: Int,
    captions: List<Caption>,
) {
    private val sA = srcW.toFloat() / srcH
    private val tA = outW.toFloat() / outH
    val cropX: Float = if (tA <= sA) tA / sA else 1f
    val cropY: Float = if (tA <= sA) 1f else sA / tA

    private val beats: List<Long> = run {
        val list = ArrayList<Long>()
        var last = -10_000L
        for (c in captions.sortedBy { it.s }) {
            val o = timeMap.outputAt(c.s) ?: continue
            if (o >= 800 && o - last >= 2400) { list += o; last = o }
        }
        list
    }
    val beatTimes: List<Long> get() = beats

    private fun level(k: Int): Float = if (k % 2 == 0) 1f + 0.16f * spec.zoomIntensity else 1f

    fun zoomAt(outMs: Long): Float {
        var z = when (spec.zoomMode) {
            "manual" -> spec.zoomLevel
            "auto" -> {
                val k = beats.indexOfLast { it <= outMs }
                if (k < 0) 1f else {
                    val target = level(k)
                    val prev = if (k == 0) 1f else level(k - 1)
                    val p = ((outMs - beats[k]) / 240f).coerceIn(0f, 1f)
                    prev + (target - prev) * easeOutBack(p, 1.2f)
                }
            }
            else -> 1f
        }
        if (spec.transitionIn == "zoom" && outMs < 450) z *= 1f + 0.25f * (1f - easeOut(outMs / 450f))
        return z.coerceIn(1f, 3f)
    }

    private fun faceX(srcMs: Long): Float? {
        val pts = spec.faceTrack
        if (!spec.trackFace || pts.isEmpty()) return null
        if (srcMs <= pts.first().tMs) return pts.first().x
        if (srcMs >= pts.last().tMs) return pts.last().x
        val i = pts.indexOfLast { it.tMs <= srcMs }
        val a = pts[i]; val b = pts[i + 1]
        val f = (srcMs - a.tMs).toFloat() / max(1L, b.tMs - a.tMs)
        return a.x + (b.x - a.x) * f
    }

    fun params(outMs: Long): Triple<Float, Float, Float> {
        val z = zoomAt(outMs)
        val halfX = cropX / z
        val halfY = cropY / z
        val maxX = max(0f, 1f - halfX)
        val maxY = max(0f, 1f - halfY)
        val fx = faceX(timeMap.sourceAt(outMs))
        val cx = (if (fx != null) 2f * fx - 1f else spec.panX * maxX).coerceIn(-maxX, maxX)
        return Triple(z, cx, 0f * maxY)
    }
}
