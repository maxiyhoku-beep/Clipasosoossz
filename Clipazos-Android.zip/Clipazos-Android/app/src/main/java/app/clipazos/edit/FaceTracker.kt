package app.clipazos.edit

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import app.clipazos.data.TrackPoint
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import kotlin.math.abs

/**
 * Seguimiento del rostro principal en el dispositivo (ML Kit, sin enviar nada a internet).
 * Genera una trayectoria suavizada para reencuadrar a vertical siguiendo a la persona.
 * Nota: sigue al rostro más grande; no distingue quién está hablando.
 */
object FaceTracker {
    suspend fun track(
        ctx: Context, uri: Uri, startMs: Long, endMs: Long, srcW: Int, srcH: Int, onProgress: (Float) -> Unit,
    ): List<TrackPoint> = withContext(Dispatchers.Default) {
        val retr = MediaMetadataRetriever()
        val det = FaceDetection.getClient(FaceDetectorOptions.Builder().setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST).build())
        val raw = ArrayList<TrackPoint>()
        try {
            retr.setDataSource(ctx, uri)
            val tw = 320
            val th = (tw * srcH / srcW.toFloat()).toInt().coerceAtLeast(64)
            var t = startMs
            var last = 0.5f
            while (t <= endMs) {
                ensureActive()
                val bmp = retr.getScaledFrameAtTime(t * 1000L, MediaMetadataRetriever.OPTION_CLOSEST, tw, th)
                if (bmp != null) {
                    val faces = det.process(InputImage.fromBitmap(bmp, 0)).await()
                    val f = faces.maxByOrNull { it.boundingBox.width() * it.boundingBox.height() }
                    if (f != null) last = (f.boundingBox.centerX().toFloat() / bmp.width).coerceIn(0f, 1f)
                    bmp.recycle()
                }
                raw += TrackPoint(t, last)
                onProgress(((t - startMs).toFloat() / (endMs - startMs).coerceAtLeast(1)).coerceIn(0f, 1f))
                t += 600
            }
        } finally {
            runCatching { det.close() }
            runCatching { retr.release() }
        }
        smooth(raw)
    }

    /** Rostros de un fotograma, como (x, y, ancho, alto) en fracciones del video, de izquierda a derecha. */
    suspend fun detectFaces(ctx: Context, uri: Uri, atMs: Long, srcW: Int, srcH: Int): List<FloatArray> = withContext(Dispatchers.Default) {
        val retr = MediaMetadataRetriever()
        val det = FaceDetection.getClient(FaceDetectorOptions.Builder().setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE).setMinFaceSize(0.04f).build())
        try {
            retr.setDataSource(ctx, uri)
            val tw = 960
            val th = (tw * srcH / srcW.toFloat()).toInt().coerceAtLeast(64)
            val found = ArrayList<FloatArray>()
            for (dt in longArrayOf(0L, 4000L, -4000L, 8000L)) {
                val bmp = retr.getScaledFrameAtTime(((atMs + dt).coerceAtLeast(0L)) * 1000L, MediaMetadataRetriever.OPTION_CLOSEST, tw, th) ?: continue
                val faces = det.process(InputImage.fromBitmap(bmp, 0)).await()
                for (f in faces) found += floatArrayOf(f.boundingBox.left.toFloat() / bmp.width, f.boundingBox.top.toFloat() / bmp.height, f.boundingBox.width().toFloat() / bmp.width, f.boundingBox.height().toFloat() / bmp.height)
                bmp.recycle()
                if (found.isNotEmpty()) break
            }
            found.sortedBy { it[0] }
        } finally {
            runCatching { det.close() }
            runCatching { retr.release() }
        }
    }

    /** Suavizado con zona muerta: la cámara no se mueve por cambios pequeños (efecto "camarógrafo"). */
    fun smooth(pts: List<TrackPoint>): List<TrackPoint> {
        if (pts.isEmpty()) return pts
        var cur = pts.first().x
        return pts.map { p ->
            if (abs(p.x - cur) > 0.05f) cur += (p.x - cur) * 0.4f
            TrackPoint(p.tMs, cur)
        }
    }
}
