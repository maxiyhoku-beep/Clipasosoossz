package app.clipazos.util

import java.util.Locale
import kotlin.math.abs

/** Formato de tiempo: 20:00, 08:05, 1:00:00 (siempre a partir de milisegundos). */
object TimeFmt {
    fun format(ms: Long): String {
        val total = (ms.coerceAtLeast(0L) + 500L) / 1000L
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
        else String.format(Locale.US, "%02d:%02d", m, s)
    }
}

data class DurationCandidates(val retrieverMs: Long?, val videoTrackMs: Long?, val audioTrackMs: Long?)
data class DurationDecision(val ms: Long, val verified: Boolean, val note: String?)

/**
 * Decide la duración real de un archivo a partir de varias fuentes.
 * Los metadatos pueden mentir (cabeceras truncadas, vistas previas, archivos remuxados):
 * si no coinciden entre sí o con el final real del contenido, se mide recorriendo las muestras.
 */
object DurationReconciler {
    const val TOLERANCE_MS = 2500L

    private fun values(c: DurationCandidates) =
        listOfNotNull(c.retrieverMs, c.videoTrackMs, c.audioTrackMs).filter { it > 0 }

    fun metadataMs(c: DurationCandidates): Long = values(c).maxOrNull() ?: 0L

    fun metadataConsistent(c: DurationCandidates): Boolean {
        val v = values(c)
        return v.isNotEmpty() && (v.max() - v.min()) <= TOLERANCE_MS
    }

    /** quickEndMs = tiempo de la última muestra encontrada saltando al final del archivo (o null). */
    fun needsFullScan(c: DurationCandidates, quickEndMs: Long?): Boolean {
        val meta = metadataMs(c)
        if (meta <= 0) return true
        if (!metadataConsistent(c)) return true
        if (quickEndMs == null || quickEndMs <= 0) return true
        return abs(meta - quickEndMs) > TOLERANCE_MS
    }

    fun decide(c: DurationCandidates, quickEndMs: Long?, scanEndMs: Long?): DurationDecision {
        val meta = metadataMs(c)
        if (scanEndMs != null && scanEndMs > 0) {
            val note = if (meta > 0 && abs(meta - scanEndMs) > TOLERANCE_MS)
                "Los metadatos indicaban ${TimeFmt.format(meta)}, pero el contenido real dura ${TimeFmt.format(scanEndMs)}. Se usa la duración real."
            else null
            return DurationDecision(scanEndMs, true, note)
        }
        if (meta > 0 && metadataConsistent(c) && quickEndMs != null && abs(meta - quickEndMs) <= TOLERANCE_MS)
            return DurationDecision(meta, true, null)
        if (meta > 0) return DurationDecision(meta, false, "No se pudo confirmar la duración con el contenido del archivo.")
        return DurationDecision(0, false, "No se pudo leer la duración del archivo.")
    }
}

object ExportSize {
    private fun even(v: Int) = if (v % 2 == 0) v else v + 1
    fun of(aspect: String, res: String): Pair<Int, Int> {
        val s = when (res) { "720p" -> 720; "4K" -> 2160; else -> 1080 }
        return when (aspect) {
            "16:9" -> even(s * 16 / 9) to s
            "1:1" -> s to s
            else -> s to even(s * 16 / 9)
        }
    }
}

fun easeOut(p: Float): Float { val q = 1f - p.coerceIn(0f, 1f); return 1f - q * q * q }
fun easeOutBack(p: Float, k: Float = 1.70158f): Float {
    val x = p.coerceIn(0f, 1f) - 1f
    return 1f + (k + 1f) * x * x * x + k * x * x
}
