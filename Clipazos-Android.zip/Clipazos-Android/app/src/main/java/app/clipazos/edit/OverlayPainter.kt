package app.clipazos.edit

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import app.clipazos.data.Caption
import app.clipazos.data.Cue
import app.clipazos.data.EditSpec
import app.clipazos.util.easeOut
import app.clipazos.util.easeOutBack
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * Dibuja TODO lo que va sobre el video (subtítulos, gancho, emojis, stickers, imágenes, barra de progreso,
 * viñeta, barras de cine y transiciones). Se usa igual en la vista previa (Canvas de Compose) y en la
 * exportación (Bitmap que Media3 superpone fotograma a fotograma), por eso lo que ves es lo que se exporta.
 */
class OverlayPainter(
    private val spec: EditSpec,
    captions: List<Caption>,
    private val timeMap: TimeMap,
    cues: List<Cue>,
    private val hookText: String,
    private val images: Map<String, Bitmap>,
) {
    private val style = CaptionStyles.get(spec.captionStyleId)
    private val caps: List<Caption> = captions.filter { it.words.isNotEmpty() && it.e > spec.startMs && it.s < spec.endMs }.sortedBy { it.s }
    private val outDur = timeMap.outDurationMs
    private val cueOut: List<Pair<Long, String>> =
        if (spec.emojisOn) cues.mapNotNull { c -> timeMap.outputAt(c.atMs)?.let { it to c.emoji } } else emptyList()

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokeP = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.style = Paint.Style.STROKE; strokeJoin = Paint.Join.ROUND }
    private val rect = Paint(Paint.ANTI_ALIAS_FLAG)
    private val emojiP = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val bmpP = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

    companion object {
        const val CUE_MS = 1500L
        const val HOOK_MS = 3200L
    }

    private fun capIndex(src: Long): Int {
        var lo = 0; var hi = caps.size - 1; var r = -1
        while (lo <= hi) { val m = (lo + hi) ushr 1; if (caps[m].s <= src) { r = m; lo = m + 1 } else hi = m - 1 }
        if (r >= 0 && src > caps[r].e + 350) return -1
        return r
    }

    fun stateKey(outMs: Long): Long {
        val src = timeMap.sourceAt(outMs) - spec.captionOffsetMs
        val ci = if (spec.captionsOn) capIndex(src) else -1
        val wi = if (ci >= 0) caps[ci].words.indexOfLast { it.s <= src } else -1
        var anim = false
        if (spec.hook && hookText.isNotBlank() && outMs < HOOK_MS + 400) anim = true
        if (cueOut.any { outMs >= it.first && outMs < it.first + CUE_MS + 100 }) anim = true
        if (spec.stickers.any { outMs >= it.startMs && outMs < it.endMs + 300 }) anim = true
        if (spec.images.any { outMs >= it.startMs && outMs < it.endMs + 300 }) anim = true
        if (spec.transitionIn != "none" && outMs < 520) anim = true
        if (spec.transitionOut != "none" && outMs > outDur - 520) anim = true
        if (ci >= 0 && style.anim != CapAnim.NONE) {
            if (style.anim == CapAnim.SHAKE || src - caps[ci].s < 320 || (wi >= 0 && src - caps[ci].words[wi].s < 220)) anim = true
        }
        val a = if (anim) outMs / 33 else -1L
        val b = if (spec.progressBar) outMs / 66 else 0L
        return (((ci + 2L) * 1000L + (wi + 2L)) * 1_000_003L + a) * 31L + b
    }

    fun draw(canvas: Canvas, w: Int, h: Int, outMs: Long, safeZones: Boolean = false) {
        val src = timeMap.sourceAt(outMs) - spec.captionOffsetMs
        if (spec.vignette) drawVignette(canvas, w, h)
        if (spec.cinemaBars) {
            rect.shader = null; rect.color = Color.BLACK
            canvas.drawRect(0f, 0f, w.toFloat(), h * 0.09f, rect)
            canvas.drawRect(0f, h * 0.91f, w.toFloat(), h.toFloat(), rect)
        }
        for (im in spec.images) {
            if (outMs < im.startMs || outMs > im.endMs + 300) continue
            val bmp = images[im.id] ?: continue
            val p = easeOutBack(((outMs - im.startMs) / 260f))
            val fade = if (outMs > im.endMs) 1f - (outMs - im.endMs) / 300f else 1f
            val bw = w * im.widthFrac * p
            val bh = bw * bmp.height / bmp.width
            val cx = w * im.xFrac; val cy = h * im.yFrac
            bmpP.alpha = (255 * fade.coerceIn(0f, 1f)).toInt()
            canvas.drawBitmap(bmp, null, RectF(cx - bw / 2, cy - bh / 2, cx + bw / 2, cy + bh / 2), bmpP)
        }
        for (st in spec.stickers) {
            if (outMs < st.startMs || outMs > st.endMs + 300) continue
            drawEmoji(canvas, st.text, w * st.xFrac, h * st.yFrac, min(w, h) * st.sizeFrac, outMs - st.startMs, st.endMs - st.startMs)
        }
        for ((t0, emoji) in cueOut) {
            if (outMs < t0 || outMs > t0 + CUE_MS) continue
            drawEmoji(canvas, emoji, w * 0.80f, h * 0.30f, min(w, h) * 0.2f, outMs - t0, CUE_MS)
        }
        if (spec.captionsOn) {
            val ci = capIndex(src)
            if (ci >= 0) drawCaption(canvas, w, h, caps[ci], src)
        }
        if (spec.hook) drawHook(canvas, w, h, outMs)
        if (spec.progressBar && outDur > 0) {
            val bh = h * 0.008f
            rect.shader = LinearGradient(0f, 0f, w.toFloat(), 0f, 0xFF22D3EE.toInt(), 0xFF7C3AED.toInt(), Shader.TileMode.CLAMP)
            canvas.drawRect(0f, h - bh, w * (outMs.toFloat() / outDur).coerceIn(0f, 1f), h.toFloat(), rect)
            rect.shader = null
        }
        rect.shader = null
        if (spec.transitionIn == "fade" && outMs < 450) { rect.color = Color.argb((255 * (1f - outMs / 450f)).toInt(), 0, 0, 0); canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), rect) }
        if (spec.transitionIn == "flash" && outMs < 280) { rect.color = Color.argb((235 * (1f - outMs / 280f)).toInt(), 255, 255, 255); canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), rect) }
        if (spec.transitionOut == "fade" && outMs > outDur - 450) {
            val a = ((outMs - (outDur - 450)) / 450f).coerceIn(0f, 1f)
            rect.color = Color.argb((255 * a).toInt(), 0, 0, 0); canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), rect)
        }
        if (safeZones) drawSafeZones(canvas, w, h)
    }

    private fun drawVignette(canvas: Canvas, w: Int, h: Int) {
        rect.shader = RadialGradient(w / 2f, h / 2f, maxOf(w, h) * 0.72f,
            intArrayOf(0x00000000, 0x00000000, 0xAA000000.toInt()), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), rect)
        rect.shader = null
    }

    private fun drawEmoji(canvas: Canvas, text: String, cx: Float, cy: Float, size: Float, t: Long, dur: Long) {
        val inP = easeOutBack(t / 240f)
        val out = if (t > dur) 1f - (t - dur) / 300f else 1f
        emojiP.textSize = size
        emojiP.alpha = (255 * out.coerceIn(0f, 1f)).toInt()
        canvas.save()
        canvas.rotate((sin(t / 180.0) * 8.0).toFloat(), cx, cy)
        canvas.scale(inP, inP, cx, cy)
        canvas.drawText(text, cx, cy + size * 0.35f, emojiP)
        canvas.restore()
    }

    private fun drawHook(canvas: Canvas, w: Int, h: Int, outMs: Long) {
        if (hookText.isBlank() || outMs > HOOK_MS + 400) return
        val p = easeOut(outMs / 320f)
        val alpha = if (outMs > HOOK_MS) 1f - (outMs - HOOK_MS) / 400f else 1f
        val base = min(w, h) * 0.055f
        fill.typeface = CaptionStyles.get("hormozi").typeface
        fill.textSize = base; fill.clearShadowLayer()
        val maxW = w * 0.80f
        val words = hookText.trim().take(70).split(Regex("\\s+"))
        val lines = ArrayList<String>(); var cur = ""
        for (wd in words) {
            val t = if (cur.isEmpty()) wd else "$cur $wd"
            if (fill.measureText(t) > maxW && cur.isNotEmpty()) { lines += cur; cur = wd } else cur = t
        }
        if (cur.isNotEmpty()) lines += cur
        val shown = lines.take(3)
        val lh = base * 1.25f
        val bw = (shown.maxOfOrNull { fill.measureText(it) } ?: 0f) + base * 1.2f
        val bh = lh * shown.size + base * 0.7f
        val cx = w / 2f
        val top = h * 0.14f - (1f - p) * h * 0.06f
        val a = (255 * alpha.coerceIn(0f, 1f) * p).toInt()
        rect.shader = null; rect.color = Color.argb(a, 255, 255, 255)
        canvas.drawRoundRect(RectF(cx - bw / 2, top, cx + bw / 2, top + bh), base * 0.6f, base * 0.6f, rect)
        fill.color = Color.argb(a, 10, 12, 30); fill.textAlign = Paint.Align.CENTER
        shown.forEachIndexed { i, l -> canvas.drawText(l, cx, top + base * 0.35f + base + i * lh, fill) }
        fill.textAlign = Paint.Align.LEFT
    }

    private fun drawCaption(canvas: Canvas, w: Int, h: Int, c: Caption, src: Long) {
        val st = style
        val base = min(w, h) * 0.085f * st.sizeEm * spec.captionScale
        fill.typeface = st.typeface; fill.textSize = base; fill.textAlign = Paint.Align.LEFT
        strokeP.typeface = st.typeface; strokeP.textSize = base; strokeP.strokeWidth = base * st.strokeEm
        val words = c.words.map { if (st.uppercase) it.w.trim().uppercase() else it.w.trim() }
        val spaceW = fill.measureText(" ")
        val widths = words.map { fill.measureText(it) }
        val maxW = w * 0.88f
        val lines = ArrayList<IntRange>()
        var start = 0; var cur = 0f
        for (i in words.indices) {
            val add = widths[i] + if (i > start) spaceW else 0f
            if (cur + add > maxW && i > start) { lines += start until i; start = i; cur = widths[i] } else cur += add
        }
        lines += start until words.size
        val lineH = base * 1.2f
        val blockH = lineH * lines.size
        val yc = (if (spec.captionY >= 0f) spec.captionY else st.yFrac) * h
        var y = yc - blockH / 2f + base
        val tIn = (src - c.s).coerceAtLeast(0)
        var alpha = 1f; var dy = 0f
        when (st.anim) {
            CapAnim.FADE -> alpha = min(1f, tIn / 150f)
            CapAnim.BOUNCE -> dy = (1f - easeOutBack(tIn / 260f)) * base * 0.7f
            else -> {}
        }
        val curIdx = c.words.indexOfLast { it.s <= src }
        for (line in lines) {
            val lw = line.sumOf { widths[it].toDouble() }.toFloat() + spaceW * (line.count() - 1)
            var x = (w - lw) / 2f
            if (st.box != 0) {
                rect.shader = null; rect.color = st.box
                val pad = base * 0.3f
                canvas.drawRoundRect(RectF(x - pad, y - base * 0.95f + dy, x + lw + pad, y + base * 0.32f + dy), base * 0.28f, base * 0.28f, rect)
            }
            for (i in line) {
                if (st.anim == CapAnim.TYPE && i > curIdx) { x += widths[i] + spaceW; continue }
                val isCur = i == curIdx
                val col = when {
                    st.mode == HighlightMode.PROGRESSIVE && i <= curIdx -> st.highlight
                    st.mode == HighlightMode.CURRENT && isCur -> st.highlight
                    st.emphasize && words[i].length >= 7 -> st.highlight
                    else -> st.color
                }
                var scale = 1f; var jx = 0f; var jy = 0f
                if (isCur) {
                    val tw = (src - c.words[i].s).coerceAtLeast(0).toFloat()
                    when (st.anim) {
                        CapAnim.POP, CapAnim.BOUNCE -> scale = 1f + 0.18f * sin(PI * (tw / 170f).coerceIn(0f, 1f)).toFloat()
                        CapAnim.SHAKE -> { scale = 1.1f; jx = sin(tw / 38.0).toFloat() * base * 0.05f; jy = cos(tw / 29.0).toFloat() * base * 0.05f }
                        else -> {}
                    }
                }
                val px = x + jx; val py = y + dy + jy
                canvas.save()
                canvas.scale(scale, scale, px + widths[i] / 2f, py - base * 0.3f)
                if (st.strokeEm > 0f) {
                    strokeP.color = st.stroke; strokeP.alpha = (255 * alpha).toInt()
                    canvas.drawText(words[i], px, py, strokeP)
                }
                if (st.shadowEm > 0f) fill.setShadowLayer(base * st.shadowEm, 0f, base * st.shadowEm * 0.5f, st.shadowColor) else fill.clearShadowLayer()
                fill.color = col
                fill.alpha = (Color.alpha(col) * alpha).toInt()
                canvas.drawText(words[i], px, py, fill)
                canvas.restore()
                x += widths[i] + spaceW
            }
            y += lineH
        }
        fill.clearShadowLayer()
    }

    private fun drawSafeZones(canvas: Canvas, w: Int, h: Int) {
        rect.shader = null; rect.color = 0x44FF3B30
        canvas.drawRect(0f, 0f, w.toFloat(), h * 0.10f, rect)
        canvas.drawRect(0f, h * 0.80f, w.toFloat(), h.toFloat(), rect)
        canvas.drawRect(w * 0.84f, h * 0.45f, w.toFloat(), h * 0.80f, rect)
        fill.clearShadowLayer(); fill.typeface = android.graphics.Typeface.DEFAULT_BOLD
        fill.textSize = min(w, h) * 0.035f; fill.color = Color.WHITE; fill.alpha = 220; fill.textAlign = Paint.Align.CENTER
        canvas.drawText("Zona de la app (evitá poner texto acá)", w / 2f, h * 0.9f, fill)
        fill.textAlign = Paint.Align.LEFT
    }

    /** Muestra para las miniaturas de estilo de subtítulos. */
    fun drawSample(canvas: Canvas, w: Int, h: Int, text: String) {
        val c = Caption(0, 1000, text.split(" ").mapIndexed { i, t -> app.clipazos.data.Word(i * 300L, i * 300L + 280, t) })
        canvas.drawColor(0xFF11162B.toInt())
        drawCaption(canvas, w, h, c, 400)
    }
}
