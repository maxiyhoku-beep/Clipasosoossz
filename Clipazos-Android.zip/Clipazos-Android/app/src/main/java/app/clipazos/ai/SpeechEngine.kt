package app.clipazos.ai

import android.content.Context
import android.net.Uri
import app.clipazos.data.AppJson
import app.clipazos.data.Segment
import app.clipazos.data.Transcript
import app.clipazos.data.Word
import app.clipazos.media.PcmDecoder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.Job
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.doubleOrNull
import org.vosk.LibVosk
import org.vosk.LogLevel
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import kotlin.math.sqrt

/**
 * Reconocimiento de voz en español 100 % dentro del celular (Vosk / Kaldi, modelo neuronal incluido en el APK).
 * No usa internet, no usa claves y no tiene costo. También mide el volumen del audio cada 100 ms.
 */
class SpeechEngine(private val ctx: Context) {

    fun modelDir(): File {
        val dir = File(ctx.filesDir, "vosk/model-es-small-0.42")
        val ok = File(dir, ".ok")
        if (ok.exists()) return dir
        val root = "model-es"
        if (ctx.assets.list(root).isNullOrEmpty())
            throw IllegalStateException("Falta el motor de voz dentro de la app. Volvé a compilar con el workflow completo (descarga el modelo de voz).")
        dir.deleteRecursively(); dir.mkdirs()
        copyAssets(root, dir)
        ok.writeText("1")
        return dir
    }

    private fun copyAssets(path: String, dst: File) {
        val list = ctx.assets.list(path)
        if (list.isNullOrEmpty()) {
            ctx.assets.open(path).use { i -> dst.outputStream().use { o -> i.copyTo(o) } }
        } else {
            dst.mkdirs()
            for (n in list) copyAssets("$path/$n", File(dst, n))
        }
    }

    /**
     * Transcribe el audio completo con tiempos por palabra. Si hay un avance guardado ([resume]) continúa desde ahí.
     * [onCheckpoint] se llama cada ~60 s de audio para poder retomar si el proceso se interrumpe.
     */
    suspend fun transcribe(
        uri: Uri, durationMs: Long, resume: Transcript?,
        onProgress: (Float) -> Unit, onCheckpoint: (Transcript) -> Unit,
    ): Transcript = withContext(Dispatchers.Default) {
        val job = currentCoroutineContext()[Job]
        val cancelled = { job?.isActive == false }
        val dir = modelDir()

        val segs = ArrayList<Segment>()
        var resumeMs = 0L
        val energy = ArrayList<Int>()
        if (resume != null && resume.segments.isNotEmpty()) {
            segs += resume.segments
            resumeMs = resume.segments.last().e
            energy += resume.energy.take((resumeMs / 100).toInt())
        }
        // alinear la lista de energía con el punto de reanudación
        while (energy.size < (resumeMs / 100).toInt()) energy += 0

        LibVosk.setLogLevel(LogLevel.WARNINGS)
        Model(dir.absolutePath).use { model ->
            Recognizer(model, PcmDecoder.OUT_RATE.toFloat()).use { rec ->
                rec.setWords(true)
                var fed = 0L
                var lastCk = 0L
                var sumSq = 0.0
                var inWin = 0
                val bytes = ByteArray(PcmDecoder.OUT_RATE * 2)

                fun addResult(json: String) { parseResult(json, resumeMs, segs) }

                PcmDecoder.decode(ctx, uri, resumeMs, cancelled) { buf, n ->
                    for (i in 0 until n) {
                        val v = buf[i].toInt()
                        sumSq += v.toDouble() * v
                        if (++inWin == 1600) {
                            energy += (sqrt(sumSq / 1600) / 32768.0 * 1000.0).toInt().coerceIn(0, 1000)
                            sumSq = 0.0; inWin = 0
                        }
                        bytes[2 * i] = (v and 0xFF).toByte()
                        bytes[2 * i + 1] = (v shr 8).toByte()
                    }
                    if (rec.acceptWaveForm(bytes, n * 2)) addResult(rec.result)
                    fed += n
                    onProgress(((resumeMs + fed * 1000L / PcmDecoder.OUT_RATE).toFloat() / durationMs).coerceIn(0f, 1f))
                    if (fed - lastCk >= PcmDecoder.OUT_RATE * 60L) {
                        lastCk = fed
                        onCheckpoint(Transcript(segs.toList(), energy.toList()))
                    }
                }
                currentCoroutineContext().ensureActive()
                addResult(rec.finalResult)
            }
        }
        Transcript(segs.sortedBy { it.s }, energy)
    }

    /** Convierte el JSON de Vosk en segmentos con palabras (ms absolutos). Parte los segmentos muy largos en las pausas. */
    private fun parseResult(json: String, baseMs: Long, out: MutableList<Segment>) {
        val obj: JsonObject = runCatching { AppJson.parseToJsonElement(json).jsonObject }.getOrNull() ?: return
        val arr: JsonArray = obj["result"]?.jsonArray ?: return
        val words = arr.mapNotNull { e ->
            val o = e.jsonObject
            val w = o["word"]?.jsonPrimitive?.content?.trim().orEmpty()
            val s = o["start"]?.jsonPrimitive?.doubleOrNull ?: return@mapNotNull null
            val en = o["end"]?.jsonPrimitive?.doubleOrNull ?: return@mapNotNull null
            if (w.isEmpty()) null else Word(baseMs + (s * 1000).toLong(), baseMs + (en * 1000).toLong(), w)
        }
        if (words.isEmpty()) return
        for (part in splitLong(words)) {
            val fixed = part.mapIndexed { i, w -> if (i == 0) w.copy(w = w.w.replaceFirstChar { it.uppercase() }) else w }
            out += Segment(fixed.first().s, fixed.last().e, fixed.joinToString(" ") { it.w }, fixed)
        }
    }

    private fun splitLong(words: List<Word>): List<List<Word>> {
        if (words.size < 8 || words.last().e - words.first().s <= 14_000) return listOf(words)
        val lo = words.size / 5
        val hi = words.size * 4 / 5
        var best = -1
        var gap = -1L
        for (i in maxOf(lo, 1) until minOf(hi, words.size)) {
            val g = words[i].s - words[i - 1].e
            if (g > gap) { gap = g; best = i }
        }
        if (best <= 0) return listOf(words)
        return splitLong(words.subList(0, best)) + splitLong(words.subList(best, words.size))
    }
}
