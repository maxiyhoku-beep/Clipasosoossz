package app.clipazos.edit

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.audio.SpeedProvider
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin
import kotlin.random.Random

/** Velocidad constante para EditedMediaItem.setSpeed. */
class ConstantSpeed(private val speed: Float) : SpeedProvider {
    override fun getSpeed(timeUs: Long): Float = speed
    override fun getNextSpeedChangeTimeUs(timeUs: Long): Long = C.TIME_UNSET
}

/** Cambia el volumen (PCM 16 bits). */
class GainProcessor(private val gain: Float) : BaseAudioProcessor() {
    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT) throw AudioProcessor.UnhandledAudioFormatException(inputAudioFormat)
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val out = replaceOutputBuffer(inputBuffer.remaining())
        while (inputBuffer.remaining() >= 2) {
            val s = inputBuffer.short.toInt()
            out.putShort((s * gain).toInt().coerceIn(-32768, 32767).toShort())
        }
        out.flip()
    }
}

/** Efectos de sonido generados por código (sin archivos): whoosh, pop y ding. */
object SfxSynth {
    private const val SR = 44100

    enum class Kind { WHOOSH, POP, DING }

    private fun render(kind: Kind): FloatArray = when (kind) {
        Kind.WHOOSH -> {
            val n = (SR * 0.40).toInt(); val rnd = Random(7); var lp = 0f
            FloatArray(n) { i ->
                val t = i / n.toFloat()
                val env = (sin(PI * t)).toFloat()
                val a = 0.05f + 0.55f * t
                lp += a * ((rnd.nextFloat() * 2f - 1f) - lp)
                lp * env * 0.9f
            }
        }
        Kind.POP -> {
            val n = (SR * 0.14).toInt(); var ph = 0.0
            FloatArray(n) { i ->
                val t = i / SR.toDouble()
                ph += 2 * PI * (900.0 - 4000.0 * t).coerceAtLeast(260.0) / SR
                (sin(ph) * exp(-t * 28.0)).toFloat()
            }
        }
        Kind.DING -> {
            val n = (SR * 0.6).toInt()
            FloatArray(n) { i ->
                val t = i / SR.toDouble()
                ((sin(2 * PI * 1318.5 * t) + 0.5 * sin(2 * PI * 1975.5 * t)) * exp(-t * 6.0) * 0.5).toFloat()
            }
        }
    }

    /** Pista WAV mono de [durationMs] con los sonidos en sus instantes (ms de salida). */
    fun writeTrack(file: File, durationMs: Long, events: List<Pair<Long, Kind>>, volume: Float = 0.35f) {
        val total = (SR * durationMs / 1000L).toInt().coerceAtLeast(SR / 10)
        val mix = FloatArray(total)
        val cache = HashMap<Kind, FloatArray>()
        for ((t, k) in events) {
            val s = cache.getOrPut(k) { render(k) }
            val start = (SR * t / 1000L).toInt()
            for (i in s.indices) { val j = start + i; if (j in 0 until total) mix[j] += s[i] }
        }
        val data = ByteBuffer.allocate(total * 2).order(ByteOrder.LITTLE_ENDIAN)
        for (v in mix) data.putShort((v * volume * 32767f).toInt().coerceIn(-32768, 32767).toShort())
        RandomAccessFile(file, "rw").use { f ->
            f.setLength(0)
            val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
            h.put("RIFF".toByteArray()); h.putInt(36 + total * 2); h.put("WAVE".toByteArray())
            h.put("fmt ".toByteArray()); h.putInt(16); h.putShort(1); h.putShort(1)
            h.putInt(SR); h.putInt(SR * 2); h.putShort(2); h.putShort(16)
            h.put("data".toByteArray()); h.putInt(total * 2)
            f.write(h.array()); f.write(data.array())
        }
    }
}
