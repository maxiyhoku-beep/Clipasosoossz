package app.clipazos.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

object Pal {
    val Bg = Color(0xFF070B1A)
    val Surface = Color(0xFF0F1630)
    val Surface2 = Color(0xFF172042)
    val Blue = Color(0xFF2D6BFF)      // azul eléctrico (botones)
    val Cyan = Color(0xFF22D3EE)      // celeste
    val Violet = Color(0xFF7C3AED)
    val Turq = Color(0xFF14E3C6)
    val Text = Color(0xFFEAF0FF)
    val Muted = Color(0xFF9FB0D8)
    val Danger = Color(0xFFFF5470)
    val Ok = Color(0xFF2EE59D)
    val Warn = Color(0xFFFFC857)
}

val BrandBrush = Brush.linearGradient(listOf(Pal.Blue, Pal.Violet))
val AccentBrush = Brush.linearGradient(listOf(Pal.Cyan, Pal.Turq))
val GlowBrush = Brush.linearGradient(listOf(Pal.Cyan, Pal.Blue, Pal.Violet))

@Composable
fun ClipazosTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Pal.Blue, secondary = Pal.Violet, tertiary = Pal.Turq,
            background = Pal.Bg, surface = Pal.Surface, surfaceVariant = Pal.Surface2,
            onPrimary = Color.White, onSecondary = Color.White, onBackground = Pal.Text, onSurface = Pal.Text,
            onSurfaceVariant = Pal.Muted, error = Pal.Danger,
        ),
        content = content,
    )
}
