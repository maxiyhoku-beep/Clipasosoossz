package app.clipazos.work

import android.app.NotificationManager
import android.content.Context
import android.content.pm.ServiceInfo
import android.net.Uri
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import app.clipazos.ai.ClipPlan
import app.clipazos.ai.ClipScorer
import app.clipazos.ai.SpeechEngine
import app.clipazos.clipazos
import app.clipazos.data.AppJson
import app.clipazos.data.Clip
import app.clipazos.data.EditSpec
import app.clipazos.data.Project
import app.clipazos.data.ProjectStatus
import app.clipazos.data.Transcript
import app.clipazos.edit.CaptionBuilder
import app.clipazos.edit.EditStyles
import app.clipazos.media.VideoProbe
import app.clipazos.util.DurationReconciler
import app.clipazos.util.TimeFmt
import kotlinx.coroutines.CancellationException
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import java.io.File
import java.util.UUID
import kotlin.math.abs
import kotlin.math.min

object ClipFactory {
    /** Los subtítulos se generan para una ventana ampliada (±40 s) para poder ajustar el recorte después. */
    fun make(project: Project, t: Transcript, d: ClipPlan, rank: Int): Clip {
        val start = d.startMs.coerceIn(0, project.durationMs)
        val end = d.endMs.coerceIn(start + 1000, project.durationMs)
        val caps = CaptionBuilder.fromTranscript(t, (start - 40_000).coerceAtLeast(0), min(project.durationMs, end + 40_000))
        val spec = EditStyles.get(EditStyles.forCategory(d.category)).apply(EditSpec(startMs = start, endMs = end, hookText = d.title))
        return Clip(
            id = UUID.randomUUID().toString(), projectId = project.id, rank = rank, startMs = start, endMs = end,
            score = d.score.coerceIn(0, 100), title = d.title.ifBlank { "Clip ${rank + 1}" }, description = d.description,
            category = d.category, captions = caps, cues = d.cues, edit = spec,
        )
    }
}

class AnalyzeWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    private var lastNotify = 0L

    override suspend fun getForegroundInfo(): ForegroundInfo = info("Preparando análisis…", 0)

    private fun notification(text: String, pct: Int) =
        Notifs.build(applicationContext, "Clipazos analizando", text, pct, WorkManager.getInstance(applicationContext).createCancelPendingIntent(id))

    private fun info(text: String, pct: Int) = ForegroundInfo(4101, notification(text, pct), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)

    override suspend fun doWork(): Result {
        val pid = inputData.getString("id") ?: return Result.failure()
        val store = applicationContext.clipazos.store
        val project = store.project(pid) ?: return Result.failure()
        runCatching { setForeground(info("Analizando…", 0)) }
        return try {
            run(project)
            Result.success()
        } catch (e: CancellationException) {
            store.updateProject(pid) { it.copy(status = ProjectStatus.IMPORTED, stage = "Cancelado", progress = 0f) }
            throw e
        } catch (e: Throwable) {
            val msg = if (e is IllegalStateException) e.message else "${e.javaClass.simpleName}: ${e.message}"
            store.updateProject(pid) { it.copy(status = ProjectStatus.ERROR, error = msg ?: "Error desconocido", stage = "Error") }
            Result.failure()
        }
    }

    /** No suspende: se puede llamar desde el bucle de decodificación. Actualiza el proyecto y la notificación. */
    private fun report(pid: String, stage: String, frac: Float) {
        applicationContext.clipazos.store.updateProject(pid) { it.copy(status = ProjectStatus.ANALYZING, stage = stage, progress = frac.coerceIn(0f, 1f)) }
        val now = System.currentTimeMillis()
        if (now - lastNotify > 1000) {
            lastNotify = now
            runCatching { applicationContext.getSystemService(NotificationManager::class.java).notify(4101, notification(stage, (frac * 100).toInt())) }
        }
    }

    private suspend fun run(project: Project) {
        val app = applicationContext.clipazos
        val store = app.store
        val pid = project.id
        val ctx = applicationContext
        val uri = Uri.parse(project.uri)

        report(pid, "Verificando la duración real del video…", 0.01f)
        val info = VideoProbe.probe(ctx, uri)
        if (abs(info.durationMs - project.durationMs) > DurationReconciler.TOLERANCE_MS)
            throw IllegalStateException("La duración leída (${TimeFmt.format(info.durationMs)}) no coincide con la guardada (${TimeFmt.format(project.durationMs)}). Importá el video de nuevo.")
        if (!info.hasAudio) throw IllegalStateException("El video no tiene audio: no hay nada que transcribir.")
        val dur = info.durationMs

        report(pid, "Preparando el motor de voz (solo la primera vez)…", 0.03f)
        val engine = SpeechEngine(ctx)
        engine.modelDir()

        val parts = File(store.dir(pid), "parts")
        val transcript = engine.transcribe(uri, dur, parts) { f, threads ->
            report(pid, "Transcribiendo el audio… ${(f * 100).toInt()} % (en $threads hilos)", 0.05f + 0.82f * f)
        }
        if (transcript.segments.isEmpty())
            throw IllegalStateException("No se detectó voz en español en este video. Si el audio está muy bajo o es en otro idioma, no hay momentos para elegir.")
        store.saveTranscript(pid, transcript)

        report(pid, "Eligiendo los mejores momentos…", 0.9f)
        val plans = ClipScorer.plan(transcript, dur, project.clipTarget)
        if (plans.isEmpty()) throw IllegalStateException("No se encontraron fragmentos de 30 s a 1:20 con sentido completo en este video.")

        report(pid, "Generando clips y subtítulos…", 0.96f)
        val clips = plans.mapIndexed { i, p -> ClipFactory.make(project, transcript, p, i) }
        store.saveClips(pid, clips)
        parts.deleteRecursively()
        store.updateProject(pid) { it.copy(status = ProjectStatus.DONE, stage = "Listo", progress = 1f, clipCount = clips.size, error = null) }
    }
}
