package app.clipazos.media

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import app.clipazos.data.Project
import app.clipazos.data.Store
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.nio.ByteBuffer
import kotlin.math.max
import kotlin.math.min

/**
 * Convierte el video a un MP4 normal (con índice) SIN recodificar: copia las muestras de video y audio tal cual.
 * Arregla grabaciones de pantalla / gameplay "fragmentadas" o sin índice, donde el reproductor no puede saltar a un punto
 * del medio ("Illegal clipping: not seekable to start") y por eso fallan la vista previa y la exportación.
 */
object Remux {
    suspend fun toSeekableMp4(ctx: Context, src: Uri, dest: File, totalBytes: Long, onProgress: (Float) -> Unit) = withContext(Dispatchers.IO) {
        dest.parentFile?.mkdirs()
        val tmp = File(dest.parentFile, dest.name + ".part")
        tmp.delete()
        val ex = MediaExtractor()
        var muxer: MediaMuxer? = null
        var started = false
        try {
            ex.setDataSource(ctx, src, null)
            var vIdx = -1
            var aIdx = -1
            for (i in 0 until ex.trackCount) {
                val m = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
                if (m.startsWith("video/") && vIdx < 0) vIdx = i else if (m.startsWith("audio/") && aIdx < 0) aIdx = i
            }
            if (vIdx < 0) throw IllegalStateException("El archivo no tiene pista de video.")

            var rotation = 0
            runCatching {
                val r = MediaMetadataRetriever()
                try { r.setDataSource(ctx, src); rotation = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0 } finally { r.release() }
            }
            val mux = MediaMuxer(tmp.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            muxer = mux
            if (rotation != 0) mux.setOrientationHint(rotation)

            val map = HashMap<Int, Int>()
            var maxSize = 8 shl 20
            for (i in listOf(vIdx, aIdx).filter { it >= 0 }) {
                val f = ex.getTrackFormat(i)
                map[i] = try { mux.addTrack(f) } catch (e: Exception) {
                    throw IllegalStateException("El códec (${f.getString(MediaFormat.KEY_MIME)}) no se puede convertir en este celular.")
                }
                ex.selectTrack(i)
                if (f.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) maxSize = max(maxSize, f.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE))
            }
            mux.start(); started = true

            val buf = ByteBuffer.allocate(max(maxSize, 12 shl 20))
            val info = MediaCodec.BufferInfo()
            var base = -1L
            var written = 0L
            var lastReport = 0L
            var samples = 0
            while (true) {
                val ti = ex.sampleTrackIndex
                if (ti < 0) break
                val dst = map[ti]
                if (dst == null) { if (!ex.advance()) break else continue }
                buf.clear()
                val size = ex.readSampleData(buf, 0)
                if (size < 0) break
                val t = ex.sampleTime
                if (base < 0) base = max(0L, t)
                info.set(0, size, max(0L, t - base), ex.sampleFlags)
                mux.writeSampleData(dst, buf, info)
                samples++
                written += size
                if (written - lastReport > 8_000_000L) {
                    lastReport = written
                    onProgress(if (totalBytes > 0) (written.toFloat() / totalBytes).coerceIn(0f, 0.99f) else 0f)
                    ensureActive()
                }
                if (!ex.advance()) break
            }
            if (samples == 0) throw IllegalStateException("No se pudieron leer datos del video.")
            mux.stop(); started = false
            mux.release(); muxer = null
            if (dest.exists()) dest.delete()
            if (!tmp.renameTo(dest)) throw IllegalStateException("No se pudo guardar el video convertido.")
            onProgress(1f)
        } catch (e: Throwable) {
            tmp.delete()
            throw e
        } finally {
            runCatching { if (started) muxer?.stop() }
            runCatching { muxer?.release() }
            runCatching { ex.release() }
        }
    }
}

/** Comprueba, con el mismo reproductor que usa la app, si se puede saltar a un punto del medio del video. */
object SeekCheck {
    suspend fun isSeekable(ctx: Context, uri: Uri, durationMs: Long): Boolean = withContext(Dispatchers.Main) {
        val player = ExoPlayer.Builder(ctx).build()
        val result = CompletableDeferred<Boolean>()
        val l = object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) { result.complete(false) }
            override fun onPlaybackStateChanged(playbackState: Int) { if (playbackState == Player.STATE_READY) result.complete(true) }
        }
        try {
            player.addListener(l)
            player.volume = 0f
            player.playWhenReady = false
            val start = (durationMs / 2).coerceAtLeast(0L)
            player.setMediaItem(
                MediaItem.Builder().setUri(uri)
                    .setClippingConfiguration(MediaItem.ClippingConfiguration.Builder().setStartPositionMs(start).setEndPositionMs(min(durationMs, start + 2000L)).build())
                    .build()
            )
            player.prepare()
            withTimeoutOrNull(12_000L) { result.await() } ?: true
        } finally {
            player.release()
        }
    }
}

object Repair {
    /** Convierte el video del proyecto a un MP4 compatible y actualiza el proyecto. Devuelve el proyecto corregido. */
    suspend fun fix(ctx: Context, store: Store, p: Project, onProgress: (Float) -> Unit): Project {
        if (p.sizeBytes > 0 && MediaCopy.freeBytes(ctx.filesDir) < p.sizeBytes + 200_000_000L)
            throw IllegalStateException("No hay espacio libre suficiente para reparar el video.")
        val dest = File(store.dir(p.id), "video_${System.currentTimeMillis()}.mp4")
        Remux.toSeekableMp4(ctx, Uri.parse(p.uri), dest, p.sizeBytes, onProgress)
        val info = VideoProbe.probe(ctx, Uri.fromFile(dest))
        if (p.uri.startsWith("file:")) runCatching { File(Uri.parse(p.uri).path!!).delete() }
        val np = p.copy(
            uri = Uri.fromFile(dest).toString(), durationMs = info.durationMs, width = info.width, height = info.height,
            verified = info.verified, seekable = true, note = "Video convertido a MP4 compatible (sin recodificar).",
        )
        store.saveProject(np)
        return np
    }
}
