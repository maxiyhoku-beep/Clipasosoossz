package app.clipazos.export

import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import androidx.media3.common.MimeTypes
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import app.clipazos.clipazos
import app.clipazos.data.Clip
import app.clipazos.data.ExportRecord
import app.clipazos.data.Project
import app.clipazos.work.Notifs
import kotlinx.coroutines.flow.MutableStateFlow
import java.io.File
import java.util.UUID

data class ExportUi(
    val active: Boolean = false, val total: Int = 0, val index: Int = 0, val title: String = "",
    val progress: Float = 0f, val errors: List<String> = emptyList(), val finished: Boolean = false,
    val savedCount: Int = 0, val cancelled: Boolean = false, val notes: List<String> = emptyList(),
)

object ExportState { val flow = MutableStateFlow(ExportUi()) }

/** Exporta en primer plano (no se corta si salís de la app). Los clips se procesan de a uno. */
class ExportService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private val queue = ArrayDeque<String>()
    private var transformer: Transformer? = null
    private var running = false
    private var total = 0
    private var done = 0
    private var saved = 0
    private val errors = ArrayList<String>()
    private val notes = ArrayList<String>()
    private var cancelled = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CANCEL) { cancelAll(); return START_NOT_STICKY }
        val ids = intent?.getStringArrayListExtra(EXTRA_IDS).orEmpty()
        startForeground(NOTIF, notif("Exportando clips…", 0), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        queue.addAll(ids); total += ids.size
        if (!running) { cancelled = false; done = 0; saved = 0; errors.clear(); notes.clear(); total = ids.size; push(ExportUi(active = true, total = total)); next() }
        return START_NOT_STICKY
    }

    private fun notif(text: String, pct: Int): android.app.Notification {
        val cancel = PendingIntent.getService(this, 1, Intent(this, ExportService::class.java).setAction(ACTION_CANCEL), PendingIntent.FLAG_IMMUTABLE)
        return Notifs.build(this, "Clipazos", text, pct, cancel)
    }

    private fun push(ui: ExportUi) {
        ExportState.flow.value = ui
        if (ui.active) getSystemService(NotificationManager::class.java).notify(NOTIF, notif(ui.title.ifBlank { "Exportando…" }, (ui.progress * 100).toInt()))
    }

    private fun cur(title: String, p: Float) =
        ExportUi(active = true, total = total, index = done + 1, title = title, progress = p, errors = errors.toList(), savedCount = saved, notes = notes.toList())

    private fun next() {
        val id = queue.removeFirstOrNull()
        if (id == null) { finish(); return }
        running = true
        val store = clipazos.store
        val clip = store.clip(id)
        val project = clip?.let { store.project(it.projectId) }
        if (clip == null || project == null) { done++; next(); return }
        startClip(clip, project, 0, "")
    }

    private fun describe(e: ExportException): String {
        val cause = e.cause?.message?.let { " · $it" } ?: ""
        return "código ${e.errorCode}: ${e.message ?: "sin detalle"}$cause"
    }

    private fun startClip(clip: Clip, project: Project, attempt: Int, prevErrors: String) {
        val label = when (attempt) { 0 -> clip.title; 1 -> "${clip.title} (modo seguro)"; else -> "${clip.title} (modo mínimo)" }
        push(cur(label, done.toFloat() / total))
        try {
            val work = File(cacheDir, "export").apply { mkdirs() }
            val out = File(work, "clip_${clip.id}.mp4").also { it.delete() }
            val comp = ExportPlan.build(this, project, clip, clip.edit, work, attempt)
            val bitrate = when (clip.edit.resolution) { "720p" -> 5_000_000; "4K" -> 30_000_000; else -> 10_000_000 }
            val t = Transformer.Builder(this)
                .setVideoMimeType(if (clip.edit.resolution == "4K") MimeTypes.VIDEO_H265 else MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .setEncoderFactory(DefaultEncoderFactory.Builder(this)
                    .setRequestedVideoEncoderSettings(VideoEncoderSettings.Builder().setBitrate(bitrate).build()).build())
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        if (attempt > 0) notes += "${clip.title}: se exportó en " + (if (attempt == 1) "modo seguro (sin música ni sonidos extra)" else "modo mínimo (sin subtítulos, recuadros ni efectos)") + " porque el modo completo falló."
                        onDone(clip, project, out)
                    }
                    override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                        out.delete()
                        val d = describe(exportException)
                        if (attempt < 2 && !cancelled) { transformer = null; startClip(clip, project, attempt + 1, "$prevErrors[$attempt] $d\n") }
                        else fail(clip, "$prevErrors[$attempt] $d")
                    }
                }).build()
            transformer = t
            t.start(comp, out.absolutePath)
            poll(t, label)
        } catch (e: Exception) {
            if (attempt < 2 && !cancelled) startClip(clip, project, attempt + 1, "$prevErrors[$attempt] ${e.javaClass.simpleName}: ${e.message}\n")
            else fail(clip, "$prevErrors[$attempt] ${e.javaClass.simpleName}: ${e.message}")
        }
    }

    private fun poll(t: Transformer, title: String) {
        handler.postDelayed({
            if (transformer !== t) return@postDelayed
            val h = ProgressHolder()
            val st = t.getProgress(h)
            if (st != Transformer.PROGRESS_STATE_NOT_STARTED) push(cur(title, (done + h.progress / 100f) / total))
            poll(t, title)
        }, 400)
    }

    private fun fail(clip: Clip, msg: String) {
        transformer = null
        errors += "${clip.title}: $msg"
        done++
        if (cancelled) finish() else next()
    }

    private fun onDone(clip: Clip, project: Project, out: File) {
        transformer = null
        Thread {
            val uri = saveToGallery(this, out, "Clipazos_${project.name.take(20).replace(Regex("[^A-Za-z0-9_-]"), "_")}_${clip.rank + 1}_${System.currentTimeMillis() / 1000}.mp4")
            out.delete()
            handler.post {
                if (uri != null) {
                    saved++
                    val store = clipazos.store
                    store.clip(clip.id)?.let { store.updateClip(it.copy(exportedUri = uri.toString())) }
                    store.addExport(ExportRecord(UUID.randomUUID().toString(), clip.id, project.id, clip.title, uri.toString(),
                        System.currentTimeMillis(), "${clip.edit.aspect} · ${clip.edit.resolution}"))
                } else errors += "${clip.title}: no se pudo guardar en la galería"
                done++
                if (cancelled) finish() else next()
            }
        }.start()
    }

    private fun cancelAll() {
        cancelled = true
        queue.clear()
        val t = transformer
        transformer = null
        runCatching { t?.cancel() }
        finish()
    }

    private fun finish() {
        running = false
        transformer = null
        handler.removeCallbacksAndMessages(null)
        ExportState.flow.value = ExportUi(active = false, total = total, finished = true, errors = errors.toList(), savedCount = saved, cancelled = cancelled, notes = notes.toList())
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    companion object {
        const val NOTIF = 4201
        const val EXTRA_IDS = "ids"
        const val ACTION_CANCEL = "app.clipazos.CANCEL_EXPORT"

        fun start(ctx: Context, ids: List<String>) {
            val i = Intent(ctx, ExportService::class.java).putStringArrayListExtra(EXTRA_IDS, ArrayList(ids))
            ctx.startForegroundService(i)
        }
        fun cancel(ctx: Context) { ctx.startService(Intent(ctx, ExportService::class.java).setAction(ACTION_CANCEL)) }

        fun saveToGallery(ctx: Context, file: File, name: String): Uri? = runCatching {
            val v = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/Clipazos")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val uri = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v) ?: return@runCatching null
            ctx.contentResolver.openOutputStream(uri)?.use { o -> file.inputStream().use { it.copyTo(o) } }
            v.clear(); v.put(MediaStore.Video.Media.IS_PENDING, 0)
            ctx.contentResolver.update(uri, v, null, null)
            uri
        }.getOrNull()
    }
}
