package app.clipazos.ui
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.PlayArrow

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun Backdrop(content: @Composable () -> Unit) {
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF0C1438), Pal.Bg, Pal.Bg)))) { content() }
}

@Composable
fun Logo(size: Int = 28) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size((size + 8).dp).clip(RoundedCornerShape(10.dp)).background(GlowBrush), contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.PlayArrow, null, tint = Color.White, modifier = Modifier.size(size.dp))
        }
        Spacer(Modifier.width(10.dp))
        Text("CLIPAZOS", style = TextStyle(brush = GlowBrush, fontSize = (size - 2).sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp))
    }
}

@Composable
fun GradientButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, icon: ImageVector? = null, enabled: Boolean = true, height: Dp = 54.dp) {
    Box(
        modifier.height(height).alpha(if (enabled) 1f else 0.45f).clip(RoundedCornerShape(28.dp)).background(BrandBrush)
            .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 22.dp),
        contentAlignment = Alignment.Center,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            if (icon != null) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(22.dp)); Spacer(Modifier.width(8.dp)) }
            Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp, textAlign = TextAlign.Center)
        }
    }
}

@Composable
fun GhostButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, icon: ImageVector? = null, danger: Boolean = false) {
    val c = if (danger) Pal.Danger else Pal.Cyan
    Box(
        modifier.height(44.dp).clip(RoundedCornerShape(22.dp)).border(BorderStroke(1.2.dp, c.copy(alpha = 0.7f)), RoundedCornerShape(22.dp))
            .clickable(onClick = onClick).padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (icon != null) { Icon(icon, null, tint = c, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)) }
            Text(text, color = c, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
        }
    }
}

@Composable
fun Panel(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable () -> Unit) {
    val m = modifier.clip(RoundedCornerShape(20.dp)).background(Pal.Surface).border(1.dp, Color(0x22FFFFFF), RoundedCornerShape(20.dp))
    Box(if (onClick != null) m.clickable(onClick = onClick) else m) { content() }
}

@Composable
fun Pill(text: String, color: Color = Pal.Cyan, modifier: Modifier = Modifier) {
    Box(modifier.clip(RoundedCornerShape(50)).background(color.copy(alpha = 0.16f)).padding(horizontal = 10.dp, vertical = 4.dp)) {
        Text(text, color = color, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun ScoreBadge(score: Int, size: Dp = 52.dp) {
    val col = when { score >= 80 -> Pal.Ok; score >= 60 -> Pal.Cyan; score >= 40 -> Pal.Warn; else -> Pal.Danger }
    Box(Modifier.size(size).clip(CircleShape).background(col.copy(alpha = 0.15f)).border(2.dp, col, CircleShape), contentAlignment = Alignment.Center) {
        Text("$score", color = col, fontWeight = FontWeight.Black, fontSize = (size.value * 0.38f).sp)
    }
}

@Composable
fun <T> Chips(options: List<Pair<T, String>>, selected: T, onSelect: (T) -> Unit, modifier: Modifier = Modifier) {
    LazyRow(modifier, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(options) { (v, label) ->
            val sel = v == selected
            Box(
                Modifier.clip(RoundedCornerShape(50)).then(if (sel) Modifier.background(BrandBrush) else Modifier.background(Pal.Surface2))
                    .clickable { onSelect(v) }.padding(horizontal = 16.dp, vertical = 9.dp),
            ) { Text(label, color = if (sel) Color.White else Pal.Muted, fontWeight = if (sel) FontWeight.Bold else FontWeight.Medium, fontSize = 14.sp) }
        }
    }
}

@Composable
fun SliderRow(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit, valueText: String = "") {
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = Pal.Muted, fontSize = 13.sp)
            Text(valueText, color = Pal.Cyan, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
        Slider(value = value.coerceIn(range.start, range.endInclusive), onValueChange = onChange, valueRange = range,
            colors = SliderDefaults.colors(thumbColor = Pal.Cyan, activeTrackColor = Pal.Blue, inactiveTrackColor = Pal.Surface2))
    }
}

@Composable
fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit, sub: String? = null) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(label, color = Pal.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            if (sub != null) Text(sub, color = Pal.Muted, fontSize = 12.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = Pal.Blue, checkedThumbColor = Color.White, uncheckedTrackColor = Pal.Surface2))
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(text, modifier = modifier.padding(top = 6.dp, bottom = 2.dp), color = Pal.Text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
}

@Composable
fun Label(text: String) = Text(text, color = Pal.Muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 10.dp, bottom = 6.dp))

fun openVideo(ctx: android.content.Context, uri: String) {
    val i = android.content.Intent(android.content.Intent.ACTION_VIEW).setDataAndType(android.net.Uri.parse(uri), "video/mp4")
        .addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
    runCatching { ctx.startActivity(i) }
}

fun shareVideo(ctx: android.content.Context, uri: String) {
    val i = android.content.Intent(android.content.Intent.ACTION_SEND).setType("video/mp4")
        .putExtra(android.content.Intent.EXTRA_STREAM, android.net.Uri.parse(uri))
        .addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
    runCatching { ctx.startActivity(android.content.Intent.createChooser(i, "Compartir clip").addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)) }
}
