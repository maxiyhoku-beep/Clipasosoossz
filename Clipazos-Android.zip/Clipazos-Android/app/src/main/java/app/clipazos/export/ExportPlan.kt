package app.clipazos.export

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.media.MediaCodecList
import android.net.Uri
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.Brightness
import androidx.media3.effect.Contrast
import androidx.media3.effect.HslAdjustment
import androidx.media3.effect.MatrixTransformation
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.Presentation
import androidx.media3.effect.RgbAdjustment
import androidx.media3.effect.RgbFilter
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import app.clipazos.data.Clip
import app.clipazos.data.EditSpec
import app.clipazos.data.Project
import app.clipazos.edit.ConstantSpeed
import app.clipazos.edit.Filters
import app.clipazos.edit.GainProcessor
import app.clipazos.edit.ImageLoader
import app.clipazos.edit.OverlayPainter
import app.clipazos.edit.Reframe
import app.clipazos.edit.SfxSynth
import app.clipazos.edit.TimeMap
import app.clipazos.util.ExportSize
import com.google.common.collect.ImmutableList
import java.io.File

/** Superpone el overlay (subtítulos, emojis, etc.) como un bitmap por fotograma, solo redibuja si cambia el estado. */
class FrameOverlay(private val painter: OverlayPainter, private val w: Int, private val h: Int) : BitmapOverlay() {
    private val bmps = arrayOf(Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888), Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888))
    private val canvases = arrayOf(Canvas(bmps[0]), Canvas(bmps[1]))
    private var idx = 0
    private var lastKey = 0L
    private var has = false

    override fun getBitmap(presentationTimeUs: Long): Bitmap {
        val ms = presentationTimeUs / 1000L
        val key = painter.stateKey(ms)
        if (has && key == lastKey) return bmps[idx]
        idx = 1 - idx
        bmps[idx].eraseColor(Color.TRANSPARENT)
        painter.draw(canvases[idx], w, h, ms)
        lastKey = key; has = true
        return bmps[idx]
    }
}

/** Zoom y reencuadre variables en el tiempo. */
class ReframeEffect(private val reframe: Reframe) : MatrixTransformation {
    override fun getMatrix(presentationTimeUs: Long): Matrix {
        val (z, cx, cy) = reframe.params(presentationTimeUs / 1000L)
        val m = Matrix()
        m.setTranslate(-cx, -cy)
        m.postScale(z, z)
        return m
    }
}

object FilterEffects {
    fun build(id: String): List<Effect> {
        val f = Filters.get(id)
        val l = ArrayList<Effect>()
        if (f.gray) l += RgbFilter.createGrayscaleFilter()
        if (!f.gray && f.sat != 1f) l += HslAdjustment.Builder().adjustSaturation((f.sat - 1f) * 100f).build()
        if (f.r != 1f || f.g != 1f || f.b != 1f) l += RgbAdjustment.Builder().setRedScale(f.r).setGreenScale(f.g).setBlueScale(f.b).build()
        if (f.contrast != 0f) l += Contrast(f.contrast)
        if (f.bright != 0f) l += Brightness(f.bright)
        return l
    }
}

object ExportPlan {
    private fun even(v: Float): Int { val i = v.toInt(); return if (i % 2 == 0) i else i + 1 }

    fun supports(w: Int, h: Int): Boolean = runCatching {
        MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.any { info ->
            info.isEncoder && info.supportedTypes.any { it.equals("video/avc", true) || it.equals("video/hevc", true) } &&
                info.supportedTypes.any { t ->
                    (t.equals("video/avc", true) || t.equals("video/hevc", true)) &&
                        info.getCapabilitiesForType(t).videoCapabilities?.isSizeSupported(w, h) == true
                }
        }
    }.getOrDefault(false)

    fun build(ctx: Context, project: Project, clip: Clip, spec: EditSpec, work: File): Composition {
        val (outW, outH) = ExportSize.of(spec.aspect, spec.resolution)
        val tm = TimeMap.build(spec.startMs, spec.endMs, clip.captions.flatMap { it.words }, spec.removeSilences, spec.speed)
        val uri = Uri.parse(project.uri)

        val items = tm.pieces.map { p ->
            val mi = MediaItem.Builder().setUri(uri)
                .setClippingConfiguration(MediaItem.ClippingConfiguration.Builder().setStartPositionMs(p.srcStart).setEndPositionMs(p.srcEnd).build())
                .build()
            val b = EditedMediaItem.Builder(mi)
            val audio = if (spec.originalVolume != 1f) listOf<AudioProcessor>(GainProcessor(spec.originalVolume)) else emptyList()
            b.setEffects(Effects(audio, emptyList()))
            if (spec.speed != 1f) b.setSpeed(ConstantSpeed(spec.speed))
            b.build()
        }
        val sequences = ArrayList<EditedMediaItemSequence>()
        sequences += EditedMediaItemSequence.withAudioAndVideoFrom(items)

        spec.musicUri?.let { m ->
            val music = EditedMediaItem.Builder(MediaItem.fromUri(Uri.parse(m))).setRemoveVideo(true)
                .setEffects(Effects(listOf<AudioProcessor>(GainProcessor(spec.musicVolume)), emptyList())).build()
            sequences += EditedMediaItemSequence.withAudioFrom(listOf(music)).buildUpon().setIsLooping(true).build()
        }

        val reframe = Reframe(spec, tm, project.width, project.height, outW, outH, clip.captions)
        if (spec.sfxOn) {
            val ev = ArrayList<Pair<Long, SfxSynth.Kind>>()
            if (spec.transitionIn != "none") ev += 0L to SfxSynth.Kind.WHOOSH
            reframe.beatTimes.filterIndexed { i, _ -> i % 2 == 0 }.take(10).forEach { ev += it to SfxSynth.Kind.WHOOSH }
            if (spec.emojisOn) clip.cues.mapNotNull { c -> tm.outputAt(c.atMs) }.forEach { ev += it to SfxSynth.Kind.POP }
            spec.stickers.forEach { ev += it.startMs to SfxSynth.Kind.POP }
            if (ev.isNotEmpty()) {
                val wav = File(work, "sfx_${clip.id}.wav")
                SfxSynth.writeTrack(wav, (tm.outDurationMs - 150).coerceAtLeast(500), ev)
                val sfx = EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(wav))).setRemoveVideo(true).build()
                sequences += EditedMediaItemSequence.withAudioFrom(listOf(sfx))
            }
        }

        val fill = spec.layout == "fill"
        val sA = project.width.toFloat() / project.height
        val tA = outW.toFloat() / outH
        val vfx = ArrayList<Effect>()
        if (fill) {
            val (iw, ih) = if (tA <= sA) even(outH * sA) to outH else outW to even(outW / sA)
            vfx += Presentation.createForWidthAndHeight(iw, ih, Presentation.LAYOUT_STRETCH_TO_FIT)
            vfx += ReframeEffect(reframe)
        }
        vfx += FilterEffects.build(spec.filterId)
        vfx += Presentation.createForWidthAndHeight(outW, outH, if (fill) Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP else Presentation.LAYOUT_SCALE_TO_FIT)
        val painter = OverlayPainter(spec, clip.captions, tm, clip.cues, spec.hookText.ifBlank { clip.title }, ImageLoader.loadAll(ctx, spec))
        vfx += OverlayEffect(ImmutableList.of(FrameOverlay(painter, outW, outH)))

        return Composition.Builder(*sequences.toTypedArray())
            .setEffects(Effects(emptyList(), vfx))
            .setHdrMode(Composition.HDR_MODE_TONE_MAP_HDR_TO_SDR_USING_OPEN_GL)
            .build()
    }
}
