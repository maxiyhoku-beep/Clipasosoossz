package app.clipazos.ai

import app.clipazos.data.Cue
import app.clipazos.data.Segment
import app.clipazos.data.Transcript
import java.text.Normalizer
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

data class ClipPlan(
    val startMs: Long, val endMs: Long, val score: Int,
    val title: String, val description: String, val category: String, val cues: List<Cue>,
)

object Lexicon {
    val emotion = setOf(
        "increible", "brutal", "tremendo", "tremenda", "impresionante", "genial", "espectacular", "terrible", "horrible",
        "locura", "loco", "loca", "imposible", "wow", "guau", "dios", "alucinante", "asombroso", "epico", "miedo", "terror",
        "amor", "odio", "rabia", "triste", "feliz", "sorpresa", "secreto", "mentira", "verdad", "nunca", "jamas", "millones",
        "dinero", "gratis", "error", "peligro", "cuidado", "urgente", "importante", "descubri", "descubrimos", "increibles",
    )
    val phrases = listOf(
        "no puede ser", "no lo puedo creer", "de repente", "de pronto", "no me lo esperaba", "que fuerte", "madre mia",
        "te lo juro", "no te lo vas a creer", "escucha esto", "mira esto", "imaginate", "te voy a contar", "lo mas importante",
    )
    val question = setOf("que", "como", "cuando", "donde", "quien", "cual", "cuanto", "cuantos", "cuantas")
    val fillers = setOf("eh", "em", "mm", "este", "bueno", "pues", "digamos", "tipo", "ah", "uh", "ehh", "mmm")
    val story = listOf("un dia", "resulta que", "cuando era", "hace anos", "me acuerdo", "la primera vez", "te cuento", "fue asi")
    val surprise = listOf("de repente", "de pronto", "no me lo esperaba", "sorpresa", "nunca imagine", "de la nada")
    val stop = setOf(
        "de", "la", "que", "el", "en", "y", "a", "los", "se", "del", "las", "un", "por", "con", "no", "una", "su", "para", "es",
        "al", "lo", "como", "mas", "pero", "sus", "le", "ya", "o", "este", "si", "porque", "esta", "entre", "cuando", "muy",
        "sin", "sobre", "tambien", "me", "hasta", "hay", "donde", "quien", "desde", "todo", "nos", "durante", "todos", "uno",
        "les", "ni", "contra", "otros", "ese", "eso", "ante", "ellos", "e", "esto", "mi", "antes", "algunos", "que", "unos",
        "yo", "otro", "otras", "otra", "el", "tanto", "esa", "estos", "mucho", "quienes", "nada", "muchos", "cual", "poco",
        "ella", "estar", "estas", "algunas", "algo", "nosotros", "tu", "te", "tus", "es", "son", "ser", "eso", "esta", "fue",
        "asi", "bien", "aqui", "alli", "tengo", "tiene", "tienes", "puedo", "puede", "voy", "va", "vamos", "dice", "digo",
    )
    val emoji = mapOf(
        "increible" to "😮", "wow" to "😮", "guau" to "😮", "impresionante" to "😮", "dinero" to "💰", "millones" to "💰",
        "plata" to "💰", "amor" to "❤️", "quiero" to "❤️", "fuego" to "🔥", "brutal" to "🔥", "tremendo" to "🔥", "epico" to "🔥",
        "miedo" to "😱", "terror" to "😱", "locura" to "🤯", "loco" to "🤯", "mentira" to "🤥", "gracias" to "🙏",
        "felicidades" to "🎉", "idea" to "💡", "golpe" to "💥", "genial" to "👏", "triste" to "😢", "risa" to "😂",
    )
}

/**
 * Elige los mejores momentos con señales reales del audio y del texto (NO es un modelo de lenguaje):
 * volumen y picos de voz, velocidad de habla, palabras de emoción y sorpresa, risas, preguntas, reacciones cortas,
 * cambios de tema y pausas naturales. Funciona 100 % en el celular, sin internet ni claves.
 */
object ClipScorer {
    private fun norm(s: String): String = Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")
    private fun tokens(s: String): List<String> = norm(s).split(Regex("[^a-z0-9]+")).filter { it.isNotEmpty() }
    private fun clamp01(x: Float) = if (x < 0f) 0f else if (x > 1f) 1f else x

    private class Feat(val score: Float, val laugh: Int, val emo: Int, val q: Int, val story: Int, val surprise: Int, val reaction: Boolean, val eRatio: Float)

    private fun cosine(a: Map<String, Int>, b: Map<String, Int>): Float {
        if (a.isEmpty() || b.isEmpty()) return 0f
        var dot = 0.0
        for ((k, v) in a) b[k]?.let { dot += v.toDouble() * it }
        val na = sqrt(a.values.sumOf { it.toDouble() * it })
        val nb = sqrt(b.values.sumOf { it.toDouble() * it })
        return if (na == 0.0 || nb == 0.0) 0f else (dot / (na * nb)).toFloat()
    }

    fun plan(t: Transcript, durationMs: Long, count: Int, minMs: Long = 30_000, maxMs: Long = 80_000): List<ClipPlan> {
        val segs: List<Segment> = t.segments.filter { it.words.isNotEmpty() && it.e > it.s }.sortedBy { it.s }
        val n = segs.size
        if (n == 0 || count <= 0) return emptyList()
        val en = t.energy

        // --- estadísticas globales de volumen y velocidad ---
        val voiced = en.filter { it > 8 }.sorted()
        val p50 = if (voiced.isEmpty()) 1f else max(1f, voiced[voiced.size / 2].toFloat())
        val p90 = if (voiced.isEmpty()) 1f else max(1f, voiced[min(voiced.size - 1, voiced.size * 9 / 10)].toFloat())
        val rates = segs.map { it.words.size / ((it.e - it.s) / 1000f) }.sorted()
        val medRate = max(1f, rates[n / 2])

        fun segEnergy(sg: Segment): Pair<Float, Float> {
            if (en.isEmpty()) return 0f to 0f
            val a = (sg.s / 100).toInt().coerceIn(0, en.size - 1)
            val b = min(en.size, max(a + 1, (sg.e / 100).toInt() + 1))
            var sum = 0f; var mx = 0f
            for (i in a until b) { sum += en[i]; mx = max(mx, en[i].toFloat()) }
            return sum / (b - a) to mx
        }

        val toks = segs.map { tokens(it.text) }
        val feats = ArrayList<Feat>(n)
        for (i in 0 until n) {
            val sg = segs[i]
            val tk = toks[i]
            val tn = norm(sg.text)
            val dur = (sg.e - sg.s) / 1000f
            val (meanE, maxE) = segEnergy(sg)
            val laugh = tk.count { it.startsWith("jaj") || it.startsWith("jej") } + if (tn.contains("ja ja")) 1 else 0
            val emo = tk.count { it in Lexicon.emotion } + Lexicon.phrases.count { tn.contains(it) } * 2
            val q = if ((tk.firstOrNull() in Lexicon.question) || (tk.size >= 2 && tk[0] == "por" && tk[1] == "que")) 1 else 0
            val story = Lexicon.story.count { tn.contains(it) }
            val surprise = Lexicon.surprise.count { tn.contains(it) }
            val fill = (tk.count { it in Lexicon.fillers } + if (tn.contains("o sea")) 2 else 0).toFloat() / max(1, tk.size)
            val eRatio = if (en.isEmpty()) 1f else meanE / p50
            val energyScore = if (en.isEmpty()) 0f else 0.5f * clamp01((meanE / p50 - 1f) / 1.2f) + 0.5f * clamp01((maxE / p90 - 1f) / 1.0f)
            val rateScore = clamp01((sg.words.size / max(0.5f, dur) / medRate - 1f) / 0.6f)
            val emoScore = clamp01(emo * 0.35f + laugh * 0.5f + surprise * 0.3f)
            val qScore = if (q > 0) 0.5f else 0f
            val lenScore = min(1f, sg.words.size / 6f)
            val prevDur = if (i > 0) (segs[i - 1].e - segs[i - 1].s) / 1000f else 0f
            val reaction = i > 0 && dur < 3f && prevDur > 6f && eRatio >= 1.2f
            val s = 0.34f * energyScore + 0.24f * emoScore + 0.14f * rateScore + 0.10f * qScore + 0.08f * lenScore +
                (if (reaction) 0.25f else 0f) - 0.3f * min(0.6f, fill * 2f)
            feats += Feat(max(0f, s), laugh, emo, q, story, surprise, reaction, eRatio)
        }

        // --- cambios de tema (vocabulario antes vs. después de cada frase) ---
        fun tf(from: Int, to: Int): Map<String, Int> {
            val m = HashMap<String, Int>()
            for (i in max(0, from) until min(n, to)) for (w in toks[i]) if (w.length >= 4 && w !in Lexicon.stop) m[w] = (m[w] ?: 0) + 1
            return m
        }
        val boundary = FloatArray(n) { i -> if (i < 3 || i > n - 3) 0.3f else 1f - cosine(tf(i - 6, i), tf(i, i + 6)) }

        // --- ventanas candidatas: empiezan donde hay pausa, terminan en frase completa ---
        data class Cand(val a: Int, val b: Int, val raw: Float)
        val cands = ArrayList<Cand>()
        for (a in 0 until n) {
            val gapBefore = if (a == 0) 1000L else segs[a].s - segs[a - 1].e
            if (!(gapBefore >= 300 || boundary[a] > 0.6f)) continue
            var sum = 0f; var peak = 0f; var words = 0
            for (b in a until n) {
                val dur = segs[b].e - segs[a].s
                if (dur > maxMs - 500) break
                sum += feats[b].score; peak = max(peak, feats[b].score); words += segs[b].words.size
                if (dur < minMs - 400) continue
                val len = b - a + 1
                val avg = sum / len
                val gapAfter = if (b < n - 1) segs[b + 1].s - segs[b].e else 2000L
                val endQ = clamp01(gapAfter / 1200f)
                val hookQ = 0.6f * feats[a].score + 0.4f * boundary[a]
                val durSec = dur / 1000f
                val lenQ = 1f - clamp01(abs(durSec - 50f) / 40f) * 0.35f
                val dens = words / (durSec * medRate)
                val raw = (0.55f * avg + 0.25f * peak + 0.10f * hookQ + 0.10f * endQ) * lenQ * min(1f, dens + 0.2f)
                cands += Cand(a, b, raw)
            }
        }
        if (cands.isEmpty()) return emptyList()

        // --- selección sin solapes (no repite momentos) ---
        val sorted = cands.sortedByDescending { it.raw }
        val kept = ArrayList<Cand>()
        for (c in sorted) {
            val cs = segs[c.a].s; val ce = segs[c.b].e
            val clash = kept.any { k ->
                val ks = segs[k.a].s; val ke = segs[k.b].e
                val ov = max(0L, min(ce, ke) - max(cs, ks))
                ov > 0.2 * min(ce - cs, ke - ks)
            }
            if (!clash) kept += c
            if (kept.size >= count) break
        }

        val raws = cands.map { it.raw }.sorted()
        val lo = raws[raws.size / 10]
        val hi = raws[min(raws.size - 1, raws.size * 99 / 100)]

        return kept.map { c ->
            val ws = segs.subList(c.a, c.b + 1)
            val start = max(0L, ws.first().s - 150)
            val end = min(durationMs, ws.last().e + 300)
            val score = (35f + 62f * ((c.raw - lo) / (hi - lo + 1e-6f))).coerceIn(15f, 98f).toInt()

            val fs = (c.a..c.b).map { feats[it] }
            val laugh = fs.sumOf { it.laugh }
            val emo = fs.sumOf { it.emo }
            val q = fs.sumOf { it.q }
            val story = fs.sumOf { it.story }
            val surprise = fs.sumOf { it.surprise }
            val reaction = fs.any { it.reaction }
            val avgDur = ws.sumOf { it.e - it.s } / ws.size / 1000f
            val density = ws.size / ((end - start) / 10_000f)
            val category = when {
                laugh > 0 -> "divertido"
                reaction -> "reaccion"
                surprise > 0 -> "inesperado"
                density >= 3.5f && avgDur < 2.8f -> "discusion"
                emo >= 2 -> "emocionante"
                story > 0 -> "historia"
                q >= 2 -> "frase"
                else -> "viral"
            }

            // título: la frase con más fuerza dentro del clip (extractivo, sin inventar texto)
            var bestI = c.a; var bestS = -1f
            for (i in c.a..c.b) {
                val len = segs[i].text.length
                val s = feats[i].score + (if (len in 18..70) 0.2f else 0f) + (if (i - c.a < (c.b - c.a) / 2 + 1) 0.1f else 0f)
                if (s > bestS) { bestS = s; bestI = i }
            }
            var title = segs[bestI].text.trim()
            if (title.length > 64) title = title.take(64).substringBeforeLast(' ') + "…"
            title = title.replaceFirstChar { it.uppercase() }

            val tfm = HashMap<String, Int>()
            for (i in c.a..c.b) for (w in toks[i]) if (w.length >= 5 && w !in Lexicon.stop && w !in Lexicon.fillers) tfm[w] = (tfm[w] ?: 0) + 1
            val keys = tfm.entries.sortedByDescending { it.value }.take(3).map { it.key }
            val signals = buildList {
                if (laugh > 0) add("con risas")
                if (fs.maxOf { it.eRatio } >= 1.6f) add("voz enérgica")
                if (boundary[c.a] > 0.7f) add("cambio de tema")
                if (reaction) add("reacción")
            }
            val desc = buildString {
                if (keys.isNotEmpty()) append("Palabras clave: ${keys.joinToString(", ")}.")
                if (signals.isNotEmpty()) append(" Señales: ${signals.joinToString(", ")}.")
            }.trim()

            // emojis según las palabras reales del clip
            val cues = ArrayList<Cue>()
            var lastAt = -10_000L
            for (sg in ws) for (w in sg.words) {
                val k = norm(w.w).replace(Regex("[^a-z0-9]"), "")
                val em = Lexicon.emoji[k] ?: if (k.startsWith("jaj")) "😂" else null
                if (em != null && cues.size < 3 && w.s - lastAt >= 6000 && w.s >= start + 1500) { cues += Cue(w.s, em); lastAt = w.s }
            }
            ClipPlan(start, end, score, title, desc, category, cues)
        }.sortedByDescending { it.score }
    }
}
