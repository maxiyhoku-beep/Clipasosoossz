package app.clipazos.ui

import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import app.clipazos.data.Clip
import app.clipazos.data.Project
import app.clipazos.edit.TimeMap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object ThumbCache {
    private val cache = LruCache<String, Bitmap>(48)
    fun get(k: String): Bitmap? = cache.get(k)
    fun put(k: String, b: Bitmap) { cache.put(k, b) }
}

/** Miniatura del clip (fotograma real del video, recortado al formato del clip). Al tocarla se abre la vista previa. */
@Composable
fun ClipThumb(project: Project, clip: Clip, modifier: Modifier, onClick: () -> Unit) {
    val ctx = LocalContext.current
    val key = "${clip.id}@${clip.edit.startMs}"
    val bmp by produceState<Bitmap?>(ThumbCache.get(key), key) {
        if (value == null) {
            value = withContext(Dispatchers.IO) {
                runCatching {
                    val r = MediaMetadataRetriever()
                    try {
                        r.setDataSource(ctx, Uri.parse(project.uri))
                        val w = 360
                        val h = (w * project.height / project.width.toFloat()).toInt().coerceAtLeast(64)
                        r.getScaledFrameAtTime((clip.edit.startMs + 1500) * 1000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, w, h)
                    } finally { r.release() }
                }.getOrNull()?.also { ThumbCache.put(key, it) }
            }
        }
    }
    Box(modifier.clip(RoundedCornerShape(12.dp)).background(Pal.Surface2).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        bmp?.let { Image(it.asImageBitmap(), "Miniatura", Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
        Box(Modifier.size(34.dp).clip(CircleShape).background(Color(0x99000000)), contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.PlayArrow, "Ver", tint = Color.White)
        }
    }
}

/** Vista previa rápida a pantalla completa, con subtítulos, efectos y recuadros tal como se van a exportar. */
@Composable
fun ClipPreviewDialog(project: Project, clip: Clip, onEdit: () -> Unit, onDismiss: () -> Unit) {
    val spec = clip.edit
    val tm = remember(clip) { TimeMap.build(spec.startMs, spec.endMs, clip.captions.flatMap { it.words }, spec.removeSilences, spec.speed) }
    val player = rememberClipPlayer(project, tm)
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Pal.Bg)) {
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onDismiss) { Icon(Icons.Rounded.Close, "Cerrar", tint = Pal.Text) }
                    Text(clip.title, color = Pal.Text, fontWeight = FontWeight.Bold, maxLines = 1, modifier = Modifier.weight(1f))
                    GradientButton("EDITAR", onEdit, height = 40.dp)
                }
                PreviewArea(player, project, clip, tm, false, Modifier.weight(1f).fillMaxWidth())
            }
        }
    }
}
