package app.clipazos.media

import android.content.Context
import android.net.Uri
import android.os.StatFs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Copia el video a la carpeta privada de la app. Así la reproducción, el análisis y la exportación leen un archivo local
 * normal (rápido, buscable y sin depender de permisos del selector de archivos, que se pierden al reiniciar la app).
 * La copia se borra junto con el proyecto.
 */
object MediaCopy {
    fun freeBytes(dir: File): Long = runCatching { StatFs(dir.absolutePath).availableBytes }.getOrDefault(0L)

    suspend fun copyInto(ctx: Context, src: Uri, dest: File, totalBytes: Long, onProgress: (Float) -> Unit) = withContext(Dispatchers.IO) {
        dest.parentFile?.mkdirs()
        val tmp = File(dest.parentFile, dest.name + ".part")
        try {
            val input = ctx.contentResolver.openInputStream(src) ?: throw IllegalStateException("No se pudo abrir el video para copiarlo.")
            input.use { i ->
                tmp.outputStream().use { o ->
                    val buf = ByteArray(1 shl 20)
                    var done = 0L
                    var last = 0L
                    while (true) {
                        val n = i.read(buf)
                        if (n < 0) break
                        o.write(buf, 0, n)
                        done += n
                        if (done - last > 8_000_000L) {
                            last = done
                            if (totalBytes > 0) onProgress((done.toFloat() / totalBytes).coerceIn(0f, 1f))
                            ensureActive()
                        }
                    }
                }
            }
            if (dest.exists()) dest.delete()
            if (!tmp.renameTo(dest)) throw IllegalStateException("No se pudo guardar la copia del video.")
        } catch (e: Throwable) {
            tmp.delete()
            throw e
        }
    }
}
